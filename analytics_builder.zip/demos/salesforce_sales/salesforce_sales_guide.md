# Salesforce — Sales Performance Demo Guide

**Persona:** VP of Sales
**Story:** Rep in-person activities declining over 6 months, driving a measurable drop in deals closed
**Built:** 2026-05-08 05:23

## The Story

Rep in-person activities have declined significantly over the past 6 months.
Because in-person engagement is the leading indicator of deal closure, deals closed
are now falling in turn — with the impact most visible in Enterprise.
Win rates are softening, sales cycles are lengthening, and pipeline coverage is thinning.

## Key Metrics

| Metric | Role | Trend |
|--------|------|-------|
| In-Person Activities | PRIMARY (leading) | ↓ Down ~38% |
| Deals Closed | PRIMARY (outcome) | ↓ Down ~30% |
| Win Rate | Supporting | ↓ Softening |
| Avg Sales Cycle Days | Supporting | ↑ Lengthening |
| Pipeline Coverage | Supporting | ↓ Thinning |
| Revenue Closed | Supporting | ↓ Declining |

## Demo Talking Points

1. **Open In-Person Activities** — show the 6-month decline first. This is the "uh oh" leading indicator.
2. **Show Deals Closed** — confirm the lag effect. Activities drop first, then deals follow.
3. **Segment breakdown** — Enterprise hit hardest; their in-person cadence matters most.
4. **Win rate + cycle days** — softer signals that corroborate the story.
5. **The ask**: if we restore in-person engagement targets, what does the model predict for deals in Q+1?

## Concierge Prompts

- "What's happening with in-person activities?"
- "Which segment has seen the biggest drop in deals closed?"
- "How has our win rate changed over the last 6 months?"
- "Which region is most at risk for missing quota this quarter?"
- "What should the VP of Sales focus on to recover deals closed?"

## Assets

- Workspace: `salesforce_sales`
- SDM: `Salesforce_Sales_Performance_0a2`
- Dashboard: Salesforce_Sales_Dashboard
- CSV: salesforce_sales_20260508.csv

## Workspace URL

https://trailsignup-3acbf019270a22.my.salesforce.com/tableau/workspace/salesforce_sales

## Post-Build Step

Enable Analytics Agent Readiness: Data 360 → Semantic Model → Salesforce_Sales_Performance_0a2 → Settings → Analytics Agent Readiness → ON
