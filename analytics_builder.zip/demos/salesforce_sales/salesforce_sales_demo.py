#!/usr/bin/env python3
"""
Salesforce — Sales Performance Demo
Persona: VP of Sales
Story: Fewer deals being closed as rep in-person activities decline — a leading indicator story.
"""

import json, sys, uuid, os, requests, subprocess, tempfile, shutil, time as _time
import pandas as pd
import numpy as np
from datetime import date, datetime as _dt
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "../.."))

# ── Demo parameters ────────────────────────────────────────────────────────────
COMPANY_NAME  = "Salesforce"
USE_CASE      = "Sales Performance"
PERSONA       = "VP of Sales"
STORY         = "Rep in-person activities declining over 6 months, driving a measurable drop in deals closed"
SIGNAL_ONSET  = -6

company_slug  = "salesforce"
use_case_slug = "sales"
WORKSPACE_NAME = f"{company_slug}_{use_case_slug}"
TODAY         = date.today()
START_DATE    = date(TODAY.year - 2, TODAY.month, 1)
TIMESTAMP     = _dt.now().strftime("%Y-%m-%d %H:%M")

BUILD_PULSE = True
BUILD_NEXT  = True
BUILD_CSV   = True

# ── Diagnostics ────────────────────────────────────────────────────────────────
_SCRIPT_START = _time.time()
def _ts(): return _dt.now().strftime("%H:%M:%S")
def ok(m):   print(f"  [{_ts()}] ✅ {m}")
def info(m): print(f"  [{_ts()}] ℹ️  {m}")
def warn(m): print(f"  [{_ts()}] ⚠️  {m}")
def die(m, r=None):
    print(f"\n  ❌ FAILED: {m}")
    if r is not None: print(f"  HTTP {r.status_code}: {r.text[:600]}")
    sys.exit(1)

_phase_counter = [0]
TOTAL_PHASES = 4 + 11 + 1  # pulse + next (incl. business prefs) + csv
def phase(label):
    _phase_counter[0] += 1
    print(f"\n[{_phase_counter[0]}/{TOTAL_PHASES}] {label}...")

def mac_notify(title, message):
    try:
        script = f'display notification "{message}" with title "{title}" sound name "Glass"'
        with tempfile.NamedTemporaryFile(mode="w", suffix=".applescript", delete=False) as f:
            f.write(script); fpath = f.name
        subprocess.run(["osascript", fpath], check=False, capture_output=True)
        os.unlink(fpath)
    except Exception:
        pass

# ── Auth ───────────────────────────────────────────────────────────────────────
from connections import load_config, get_all_tokens, get_tableau_token, tableau_headers, sf_headers, dc_headers
import tableauserverclient as TSC

config_next  = load_config()   # active profile = analytics_demo_builder_test_1
sf           = config_next["salesforce"]
sf_token, sf_instance, dc_token, dc_domain = get_all_tokens(config_next)
SF_HDRS      = sf_headers(sf_token)
DC_HDRS      = dc_headers(dc_token)
BASE_SF      = f"{sf_instance}/services/data/v62.0"
BASE_SEM     = f"{sf_instance}/services/data/v65.0"
BASE_SEM66   = f"{sf_instance}/services/data/v66.0"
CONN_SF_ID   = sf["connector_sf_id"]
CONN_UUID    = sf.get("connector_uuid_name", sf.get("ingestion_connector_name", ""))

config_pulse  = load_config("torpey_demo_org")
tc            = config_pulse["tableau"]
TC_SERVER_URL = tc["server_url"].rstrip("/")

print(f"\n{'='*66}")
print(f"  SALESFORCE SALES DEMO BUILDER")
print(f"  Story: {STORY}")
print(f"  Persona: {PERSONA}")
print(f"  Outputs: Pulse + Tableau Next + CSV")
print(f"{'='*66}\n")

# ── PHASE 1: Generate synthetic data ──────────────────────────────────────────
phase("Generating synthetic data")

np.random.seed(99)
months = pd.date_range(START_DATE, TODAY, freq="MS")

# Salesforce operates across these real geographic regions and named segments
regions  = ["Americas West", "Americas East", "EMEA", "APAC"]
segments = ["Enterprise", "Commercial", "SMB"]

rep_rows = []
for i, region in enumerate(regions):
    for j, seg in enumerate(segments):
        rep_rows.append({
            "team_id":    f"T{i+1}{j+1}",
            "region":     region,
            "segment":    seg,
            # Quotas sized to match realistic deal volume × deal size
            # Enterprise: ~2 deals/mo × $220K = $440K/mo → $5.3M/yr for team of 8
            # Commercial: ~6 deals/mo × $55K  = $330K/mo → $4.0M/yr for team of 6
            # SMB:        ~18 deals/mo × $14K = $252K/mo → $3.0M/yr for team of 5
            "team_quota": [5_300_000, 4_000_000, 3_000_000][j],
            "team_size":  [8, 6, 5][j],
        })
df_teams = pd.DataFrame(rep_rows)

def signal_ramp(d, onset=SIGNAL_ONSET, duration=6):
    mft = (d.year - TODAY.year) * 12 + (d.month - TODAY.month)
    if mft <= onset: return 0.0
    return min(1.0, (mft - onset) / duration)

fact_rows = []
for month in months:
    for _, team in df_teams.iterrows():
        signal = signal_ramp(month)
        tid    = team["team_id"]

        # PRIMARY: In-person activities — strong clean decline (leading indicator)
        base_activities = {"Enterprise": 42, "Commercial": 28, "SMB": 18}[team["segment"]]
        inperson_activities = max(1, int(base_activities * (1 - signal * 0.38) + np.random.randint(-3, 3)))

        # PRIMARY: Deals closed — strong decline, lags activities by ~1 month
        # Calibrated so deals × avg_deal_size ≈ 95% of monthly quota in healthy periods
        # Enterprise: ~2 deals × $220K = $440K vs $442K/mo quota
        # Commercial: ~6 deals × $55K  = $330K vs $333K/mo quota
        # SMB:        ~18 deals × $14K = $252K vs $250K/mo quota
        base_deals = {"Enterprise": 2, "Commercial": 6, "SMB": 18}[team["segment"]]
        lag_signal = signal_ramp(month, onset=SIGNAL_ONSET - 1)
        deals_closed = max(0, int(base_deals * (1 - lag_signal * 0.30) + np.random.randint(-1, 2)))

        # SUPPORTING: Win rate — moderate decline
        # Industry benchmarks: Enterprise 20–28%, Commercial 28–36%, SMB 35–45%
        base_win_rate = {"Enterprise": 0.24, "Commercial": 0.33, "SMB": 0.40}[team["segment"]]
        win_rate = round(max(0.05, base_win_rate - signal * 0.07 + np.random.uniform(-0.02, 0.02)), 3)

        # SUPPORTING: Pipeline coverage — softening
        base_coverage = {"Enterprise": 3.8, "Commercial": 3.2, "SMB": 2.9}[team["segment"]]
        pipeline_coverage = round(max(1.0, base_coverage - signal * 0.6 + np.random.uniform(-0.15, 0.15)), 2)

        # SUPPORTING: Average deal size — slight erosion (discounting pressure)
        # Salesforce ACV benchmarks: Enterprise $180–250K, Commercial $40–70K, SMB $10–18K
        base_deal_size = {"Enterprise": 220_000, "Commercial": 55_000, "SMB": 14_000}[team["segment"]]
        avg_deal_size = round(base_deal_size * (1 - signal * 0.08) + np.random.uniform(-5_000, 5_000), 0)

        # SUPPORTING: Sales cycle days — increasing
        # Salesforce benchmarks: Enterprise 90–120d, Commercial 30–60d, SMB 14–30d
        base_cycle = {"Enterprise": 105, "Commercial": 45, "SMB": 21}[team["segment"]]
        avg_cycle_days = round(base_cycle + signal * 18 + np.random.uniform(-5, 5), 1)

        # SUPPORTING: Remote activities (inverse — going up as in-person drops)
        base_remote = {"Enterprise": 18, "Commercial": 24, "SMB": 30}[team["segment"]]
        remote_activities = int(base_remote * (1 + signal * 0.20) + np.random.randint(-2, 2))

        # Revenue attainment — should land ~90–100% healthy, declining to ~65–75%
        monthly_quota = team["team_quota"] / 12
        revenue_closed = round(deals_closed * avg_deal_size, 0)
        quota_attainment = round(revenue_closed / monthly_quota, 3) if monthly_quota > 0 else 0.0

        fact_rows.append({
            "record_id":         f"{tid}_{month.strftime('%Y%m')}",
            "date":              str(month.date()),
            "month_key":         int(month.strftime("%Y%m")),
            "year":              month.year,
            "quarter":           ((month.month - 1) // 3) + 1,
            "month_name":        month.strftime("%B"),
            "team_id":           tid,
            "region":            team["region"],
            "segment":           team["segment"],
            "inperson_activities": inperson_activities,
            "remote_activities": remote_activities,
            "deals_closed":      deals_closed,
            "win_rate":          win_rate,
            "avg_deal_size":     avg_deal_size,
            "avg_cycle_days":    avg_cycle_days,
            "pipeline_coverage": pipeline_coverage,
            "revenue_closed":    revenue_closed,
            "quota_attainment":  quota_attainment,
        })

df_fact = pd.DataFrame(fact_rows)
ok(f"Fact table: {len(df_fact)} rows ({len(df_teams)} teams × {len(months)} months)")
ok(f"Dimension table: {len(df_teams)} teams")

# ── CSV export ─────────────────────────────────────────────────────────────────
phase("Exporting CSV")
DEMO_DIR = Path(__file__).parent
csv_path = DEMO_DIR / f"{company_slug}_{use_case_slug}_{TODAY.strftime('%Y%m%d')}.csv"

# ── Checkpoint helpers ─────────────────────────────────────────────────────────
_CKPT_PATH = DEMO_DIR / f"{company_slug}_{use_case_slug}_checkpoint.json"

def _load_ckpt():
    if _CKPT_PATH.exists():
        try:
            c = json.loads(_CKPT_PATH.read_text())
            info(f"Checkpoint loaded — resuming from last completed phase")
            return c
        except Exception:
            pass
    return {}

def _save_ckpt(updates):
    c = _load_ckpt() if _CKPT_PATH.exists() else {}
    c.update(updates)
    _CKPT_PATH.write_text(json.dumps(c, indent=2))

_ckpt = _load_ckpt()

if BUILD_CSV and not _ckpt.get("csv_done"):
    df_fact.to_csv(csv_path, index=False)
    _save_ckpt({"csv_done": True})
    ok(f"CSV exported: {csv_path.name}")
else:
    ok(f"CSV skipped (already exported)")

# ── PULSE PHASES ───────────────────────────────────────────────────────────────
pulse_project_name = None
pulse_group_name   = None
pulse_metric_count = 0

if BUILD_PULSE and not _ckpt.get("pulse_done"):
    from tableauhyperapi import HyperProcess, Telemetry, Connection, TableDefinition, SqlType, TableName, Inserter, CreateMode, Date, NOT_NULLABLE

    phase("Publishing datasource to Tableau Cloud")

    tc_server, tc_auth_token, tc_site_id = get_tableau_token(config_pulse)
    tc_pulse_base  = f"{TC_SERVER_URL}/api/-/pulse"
    tc_base_url    = f"{TC_SERVER_URL}/api/{tc_server.version}/sites/{tc_site_id}"
    tc_hdrs        = {"X-Tableau-Auth": tc_auth_token, "Accept": "application/json"}
    tc_hdrs_create = {**tc_hdrs, "Content-Type": "application/vnd.tableau.metricqueryservice.v1.CreateDefinitionRequest+json"}
    tc_hdrs_xml    = {**tc_hdrs, "Content-Type": "application/xml", "Accept": "application/xml"}

    # Clean up previous projects + definitions
    all_projects, _ = tc_server.projects.get()
    for p in all_projects:
        if p.name.startswith("Salesforce Sales |"):
            tc_server.projects.delete(p.id)
            info(f"Deleted old project: {p.name}")

    existing_defs = []
    _p = {"page_size": 100}
    while True:
        _r = requests.get(f"{tc_pulse_base}/definitions", headers=tc_hdrs, params=_p)
        _batch = _r.json().get("definitions", [])
        existing_defs.extend(_batch)
        _npt = _r.json().get("next_page_token", "")
        if not _npt or not _batch: break
        _p = {"page_size": 100, "page_token": _npt}
    for d in existing_defs:
        if d.get("metadata", {}).get("name", "").startswith("Salesforce Sales"):
            requests.delete(f"{tc_pulse_base}/definitions/{d['metadata']['id']}", headers=tc_hdrs)
            info(f"Deleted old definition: {d['metadata']['name']}")

    # Clean up old groups created by this script (identified by name prefix)
    r_grps = requests.get(f"{tc_base_url}/groups?pageSize=100", headers=tc_hdrs_xml)
    if r_grps.ok:
        root_g = ET.fromstring(r_grps.content)
        ns = "{http://tableau.com/api}"
        old_groups = root_g.findall(f".//{ns}group") or root_g.findall(".//group")
        for g in old_groups:
            gname = g.get("name", "")
            gid   = g.get("id", "")
            if gname.startswith("Salesforce Sales |") and gid:
                rd = requests.delete(f"{tc_base_url}/groups/{gid}", headers=tc_hdrs)
                info(f"Deleted old group: {gname} ({'OK' if rd.ok else rd.status_code})")

    pulse_project_name = f"Salesforce Sales | {TIMESTAMP}"
    proj = tc_server.projects.create(TSC.ProjectItem(name=pulse_project_name))
    ok(f"Project created: {pulse_project_name}")

    PULSE_DS_NAME = "Salesforce - Sales Performance"
    hyper_path = Path(tempfile.mkdtemp()) / "salesforce_sales.hyper"

    with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hyper:
        with Connection(hyper.endpoint, str(hyper_path), CreateMode.CREATE_AND_REPLACE) as conn:
            conn.catalog.create_schema_if_not_exists("Extract")
            tbl = TableDefinition(TableName("Extract", "Extract"), [
                TableDefinition.Column("Record ID",            SqlType.text(),   NOT_NULLABLE),
                TableDefinition.Column("Date",                 SqlType.date(),   NOT_NULLABLE),
                TableDefinition.Column("Region",               SqlType.text(),   NOT_NULLABLE),
                TableDefinition.Column("Segment",              SqlType.text(),   NOT_NULLABLE),
                TableDefinition.Column("Team ID",              SqlType.text(),   NOT_NULLABLE),
                TableDefinition.Column("In-Person Activities", SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Remote Activities",    SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Deals Closed",         SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Win Rate",             SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Avg Deal Size",        SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Avg Cycle Days",       SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Pipeline Coverage",    SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Revenue Closed",       SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Quota Attainment",     SqlType.double(), NOT_NULLABLE),
            ])
            conn.catalog.create_table(tbl)
            with Inserter(conn, tbl) as ins:
                for _, row in df_fact.iterrows():
                    d = row["date"] if hasattr(row["date"], "year") else _dt.strptime(str(row["date"]), "%Y-%m-%d").date()
                    ins.add_row([
                        str(row["record_id"]),
                        Date(d.year, d.month, d.day),
                        str(row["region"]),
                        str(row["segment"]),
                        str(row["team_id"]),
                        float(row["inperson_activities"]),
                        float(row["remote_activities"]),
                        float(row["deals_closed"]),
                        float(row["win_rate"]),
                        float(row["avg_deal_size"]),
                        float(row["avg_cycle_days"]),
                        float(row["pipeline_coverage"]),
                        float(row["revenue_closed"]),
                        float(row["quota_attainment"]),
                    ])
                ins.execute()

    ds_item = TSC.DatasourceItem(project_id=proj.id, name=PULSE_DS_NAME)
    ds_item = tc_server.datasources.publish(ds_item, str(hyper_path), mode=TSC.Server.PublishMode.Overwrite)
    PULSE_DS_LUID = ds_item.id
    ok(f"Datasource published: {PULSE_DS_NAME} (luid: {PULSE_DS_LUID})")

    phase("Creating Pulse metrics + group")

    PULSE_METRICS = [
        ("Salesforce In-Person Activities",  "Avg in-person rep activities per team per month.",               "In-Person Activities", "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_NUMBER",  "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Salesforce Deals Closed",          "Total deals closed per month.",                                   "Deals Closed",         "AGGREGATION_SUM",     "NUMBER_FORMAT_TYPE_NUMBER",  "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Salesforce Win Rate",              "% of opportunities won. Healthy above 30%.",                      "Win Rate",             "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_PERCENT", "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Salesforce Avg Deal Size",         "Average closed deal value.",                                      "Avg Deal Size",        "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_NUMBER",  "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Salesforce Avg Sales Cycle Days",  "Days from opp creation to close. Over 100 days is slow.",        "Avg Cycle Days",       "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_NUMBER",  "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Salesforce Pipeline Coverage",     "Pipeline-to-quota ratio. Healthy above 3x.",                     "Pipeline Coverage",    "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_NUMBER",  "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Salesforce Revenue Closed",        "Total revenue closed per month.",                                 "Revenue Closed",       "AGGREGATION_SUM",     "NUMBER_FORMAT_TYPE_NUMBER",  "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Salesforce Quota Attainment",      "Revenue closed as % of monthly quota.",                          "Quota Attainment",     "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_PERCENT", "SENTIMENT_TYPE_UP_IS_GOOD"),
    ]

    pulse_metric_ids = []
    for name, desc, field, agg, fmt, sentiment in PULSE_METRICS:
        payload = {
            "name": name,
            "specification": {
                "datasource": {"id": PULSE_DS_LUID},
                "basic_specification": {
                    "measure": {"field": field, "aggregation": agg},
                    "time_dimension": {"field": "Date"},
                    "filters": [],
                },
                "is_running_total": False,
            },
            "extension_options": {
                "allowed_dimensions": ["Segment", "Region"],
                "allowed_granularities": ["GRANULARITY_BY_MONTH", "GRANULARITY_BY_QUARTER", "GRANULARITY_BY_YEAR"],
                "offset_from_today": 1,
                "correlation_candidate_definition_ids": [],
                "use_dynamic_offset": False,
            },
            "representation_options": {"type": fmt, "sentiment_type": sentiment},
            "insights_options": {"show_insights": True},
            "comparisons": {"comparisons": [{"compare_config": {"comparison": "TIME_COMPARISON_PREVIOUS_PERIOD"}, "index": 0}]},
            "certification": {"is_certified": False},
            "datasource_goals": [],
            "related_links": [],
        }
        r = requests.post(f"{tc_pulse_base}/definitions", headers=tc_hdrs_create, json=payload)
        if r.status_code in (200, 201):
            def_id = r.json()["definition"]["metadata"]["id"]
            r2 = requests.get(f"{tc_pulse_base}/definitions/{def_id}/metrics", headers=tc_hdrs)
            ml = r2.json().get("metrics", []) if r2.ok else []
            if ml:
                pulse_metric_ids.append({"name": name, "metric_id": ml[0]["id"]})
                ok(f"Pulse metric: {name}")
            else:
                warn(f"Pulse metric created but no metric_id: {name}")
        else:
            warn(f"Pulse metric failed: {name} — {r.status_code} {r.text[:200]}")

    pulse_metric_count = len(pulse_metric_ids)

    pulse_group_name = f"Salesforce Sales | {TIMESTAMP}"
    from xml.etree import ElementTree as ET
    r = requests.post(
        f"{tc_base_url}/groups", headers=tc_hdrs_xml,
        data=f'<?xml version="1.0" encoding="UTF-8"?><tsRequest><group name="{pulse_group_name}"/></tsRequest>'.encode()
    )
    if r.ok:
        root = ET.fromstring(r.content)
        grp = root.find(".//{http://tableau.com/api}group")
        if grp is None:
            grp = root.find(".//group")
        tc_group_id = grp.get("id") if grp is not None else None
        if not tc_group_id:
            die(f"Group created but ID not found in response: {r.text[:400]}")
        ok(f"Group created: {pulse_group_name} ({tc_group_id})")
        sub_ok = sub_fail = 0
        for m in pulse_metric_ids:
            sub = {"metric_id": m["metric_id"], "followers": [{"group_id": tc_group_id}]}
            rs = requests.post(f"{tc_pulse_base}/subscriptions:batchCreate", headers=tc_hdrs, json=sub)
            if rs.ok:
                sub_ok += 1
            else:
                sub_fail += 1
                warn(f"Subscription failed for {m['name']}: {rs.status_code} {rs.text[:120]}")
        ok(f"Group subscribed to {sub_ok}/{pulse_metric_count} metrics" + (f" ({sub_fail} failed)" if sub_fail else ""))
    else:
        warn(f"Group creation failed: {r.status_code} {r.text[:200]}")

    tc_server.auth.sign_out()
    _save_ckpt({"pulse_done": True, "pulse_project_name": pulse_project_name,
                "pulse_group_name": pulse_group_name, "pulse_metric_count": pulse_metric_count,
                "pulse_metric_names": [m["name"] for m in pulse_metric_ids]})
elif BUILD_PULSE:
    info("Pulse skipped (checkpoint found)")
    pulse_project_name = _ckpt.get("pulse_project_name", "")
    pulse_group_name   = _ckpt.get("pulse_group_name", "")
    pulse_metric_count = _ckpt.get("pulse_metric_count", 0)
    pulse_metric_ids   = [{"name": n, "metric_id": None} for n in _ckpt.get("pulse_metric_names", [])]

# ── NEXT PHASES ────────────────────────────────────────────────────────────────
workspace_name = WORKSPACE_NAME
sdm_api_name   = None
dashboard_id   = None
dashboard_name = "Salesforce_Sales_Dashboard"

if BUILD_NEXT and not _ckpt.get("next_done"):

    FACT_SCHEMA_NAME = "salesforce_Fact_Sales_Activity"
    DIM_SCHEMA_NAME  = "salesforce_Dim_Team"

    phase("Registering Data Cloud schema + streams")

    r = requests.get(f"{BASE_SF}/ssot/connections/{CONN_SF_ID}/schema", headers=SF_HDRS)
    if not r.ok:
        die("Failed to fetch existing schema", r)

    def clean_schema(s):
        clean = {k: s[k] for k in ("name", "label", "schemaType") if k in s}
        clean["fields"] = [{k: f[k] for k in ("name", "label", "dataType") if k in f} for f in s.get("fields", [])]
        return clean

    cleaned_existing = [clean_schema(s) for s in r.json().get("schemas", [])]

    new_schemas = [
        {
            "name": FACT_SCHEMA_NAME, "label": FACT_SCHEMA_NAME, "schemaType": "IngestApi",
            "fields": [
                {"name": "record_id",            "label": "record_id",            "dataType": "Text"},
                {"name": "date",                 "label": "date",                 "dataType": "Date"},
                {"name": "month_key",            "label": "month_key",            "dataType": "Number"},
                {"name": "year",                 "label": "year",                 "dataType": "Number"},
                {"name": "quarter",              "label": "quarter",              "dataType": "Number"},
                {"name": "month_name",           "label": "month_name",           "dataType": "Text"},
                {"name": "team_id",              "label": "team_id",              "dataType": "Text"},
                {"name": "region",               "label": "region",               "dataType": "Text"},
                {"name": "segment",              "label": "segment",              "dataType": "Text"},
                {"name": "inperson_activities",  "label": "inperson_activities",  "dataType": "Number"},
                {"name": "remote_activities",    "label": "remote_activities",    "dataType": "Number"},
                {"name": "deals_closed",         "label": "deals_closed",         "dataType": "Number"},
                {"name": "win_rate",             "label": "win_rate",             "dataType": "Number"},
                {"name": "avg_deal_size",        "label": "avg_deal_size",        "dataType": "Number"},
                {"name": "avg_cycle_days",       "label": "avg_cycle_days",       "dataType": "Number"},
                {"name": "pipeline_coverage",    "label": "pipeline_coverage",    "dataType": "Number"},
                {"name": "revenue_closed",       "label": "revenue_closed",       "dataType": "Number"},
                {"name": "quota_attainment",     "label": "quota_attainment",     "dataType": "Number"},
            ]
        },
        {
            "name": DIM_SCHEMA_NAME, "label": DIM_SCHEMA_NAME, "schemaType": "IngestApi",
            "fields": [
                {"name": "team_id",    "label": "team_id",    "dataType": "Text"},
                {"name": "region",     "label": "region",     "dataType": "Text"},
                {"name": "segment",    "label": "segment",    "dataType": "Text"},
                {"name": "team_quota", "label": "team_quota", "dataType": "Number"},
                {"name": "team_size",  "label": "team_size",  "dataType": "Number"},
            ]
        },
    ]

    merged = {s["name"]: s for s in cleaned_existing}
    for s in new_schemas:
        merged[s["name"]] = s

    r = requests.put(f"{BASE_SF}/ssot/connections/{CONN_SF_ID}/schema", headers=SF_HDRS, json={"schemas": list(merged.values())})
    if not r.ok:
        die("Failed to register schema", r)
    ok(f"Schema registered: {[s['name'] for s in new_schemas]}")

    created_streams = {}
    for schema in new_schemas:
        obj_name  = schema["name"]
        stream_name = f"demo_{obj_name.lower()}"[:40]
        pk_field  = "record_id" if "Fact" in obj_name else "team_id"
        payload = {
            "name": stream_name, "label": stream_name.replace("_", " ").title(),
            "datasource": sf.get("ingestion_connector_name", "analytics_builder_demo")[:10],
            "datastreamType": "INGESTAPI",
            "connectorInfo": {"connectorType": "IngestApi", "connectorDetails": {"name": CONN_UUID, "events": [obj_name]}},
            "dataLakeObjectInfo": {
                "label": stream_name.replace("_", " ").title(), "category": "Other",
                "dataspaceInfo": [{"name": "default"}],
                "dataLakeFieldInputRepresentations": [{"name": pk_field, "label": pk_field, "dataType": "Text", "isPrimaryKey": True}],
                "eventDateTimeFieldName": "", "recordModifiedFieldName": ""
            },
            "mappings": []
        }
        r = requests.post(f"{BASE_SF}/ssot/data-streams", headers=SF_HDRS, json=payload)
        if r.status_code in (200, 201):
            created_streams[obj_name] = r.json().get("name")
            ok(f"Stream created: {created_streams[obj_name]}")
        elif "already in use" in r.text.lower() or "already exists" in r.text.lower():
            info(f"Stream exists for {obj_name} — discovering...")
            r2 = requests.get(f"{BASE_SF}/ssot/data-streams", headers=SF_HDRS, params={"connectorId": CONN_SF_ID, "limit": 200})
            for ds_item in r2.json().get("dataStreams", []):
                if obj_name.lower() in ds_item.get("name", "").lower():
                    created_streams[obj_name] = ds_item["name"]
                    ok(f"Found existing: {ds_item['name']}")
                    break
            if obj_name not in created_streams:
                die(f"Stream exists but could not be found for {obj_name}")
        else:
            die(f"Failed to create stream for {obj_name}", r)

    phase("Waiting for DLO ACTIVE")

    def wait_dlo_active(stream_name, timeout=300):
        start = _time.time()
        while _time.time() < start + timeout:
            r = requests.get(f"{BASE_SF}/ssot/data-streams/{stream_name}", headers=SF_HDRS)
            if r.ok:
                dlo_info = r.json().get("dataLakeObjectInfo", {})
                if dlo_info.get("status", "").upper() == "ACTIVE" and dlo_info.get("name"):
                    ok(f"DLO ACTIVE: {dlo_info['name']}  ({int(_time.time()-start)}s)")
                    return dlo_info["name"]
            elapsed = int(_time.time() - start)
            print(f"\r  ⏳ Waiting for DLO ACTIVE ({stream_name})... {elapsed}s", end="", flush=True)
            _time.sleep(10)
        die(f"Timeout waiting for DLO ACTIVE: {stream_name}")

    FACT_DLO = wait_dlo_active(created_streams[FACT_SCHEMA_NAME])
    DIM_DLO  = wait_dlo_active(created_streams[DIM_SCHEMA_NAME])

    info("Waiting 30s for bulk API to recognize new schemas...")
    _time.sleep(30)

    phase("Submitting bulk ingest jobs")

    DC_INGEST_BASE = f"https://{dc_domain}"

    def _find_open_job(schema_name):
        r = requests.get(f"{DC_INGEST_BASE}/api/v1/ingest/jobs", headers={"Authorization": f"Bearer {dc_token}", "Content-Type": "application/json"})
        if not r.ok: return None
        for j in r.json().get("data", []):
            if j.get("object") == schema_name and j.get("state") in ("Open", "UploadComplete", "InProgress"):
                return j
        return None

    def bulk_ingest(df, schema_name, label, max_retries=10):
        csv_data = df.to_csv(index=False)
        hdrs_json = {"Authorization": f"Bearer {dc_token}", "Content-Type": "application/json"}
        hdrs_csv  = {"Authorization": f"Bearer {dc_token}", "Content-Type": "text/csv"}
        for attempt in range(1, max_retries + 1):
            r = requests.post(f"{DC_INGEST_BASE}/api/v1/ingest/jobs", headers=hdrs_json,
                json={"object": schema_name, "sourceName": sf.get("ingestion_connector_name", "analytics_builder_demo"), "operation": "upsert"})
            if r.ok: break
            if r.status_code == 404:
                wait = 15 * attempt
                print(f"\r  ⏳ {label}: schema not ready (attempt {attempt}/{max_retries}), waiting {wait}s...", end="", flush=True)
                _time.sleep(wait)
            elif r.status_code == 409:
                existing = _find_open_job(schema_name)
                if existing and existing["state"] == "Open":
                    requests.put(f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{existing['id']}/batches", headers=hdrs_csv, data=csv_data.encode())
                    requests.patch(f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{existing['id']}", headers=hdrs_json, json={"state": "UploadComplete"})
                    return existing["id"]
                elif existing:
                    return existing["id"]
                _time.sleep(15 * attempt)
            else:
                die(f"Failed to create ingest job for {label}", r)
        else:
            die(f"Schema never became available for {label} after {max_retries} retries")
        resp   = r.json()
        job_id = resp.get("id") or resp.get("data", {}).get("id")
        info(f"{label}: job created ({job_id})")
        r = requests.put(f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{job_id}/batches", headers=hdrs_csv, data=csv_data.encode())
        if not r.ok: die(f"Failed to upload data for {label}", r)
        ok(f"{label}: {len(df)} rows uploaded")
        r = requests.patch(f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{job_id}", headers=hdrs_json, json={"state": "UploadComplete"})
        if not r.ok: die(f"Failed to close ingest job for {label}", r)
        ok(f"{label}: job closed")
        return job_id

    fact_job_id = bulk_ingest(df_fact,   FACT_SCHEMA_NAME, "Fact_Sales_Activity")
    dim_job_id  = bulk_ingest(df_teams,  DIM_SCHEMA_NAME,  "Dim_Team")

    phase("Waiting for ingest jobs to complete")

    def wait_job(job_id, label, timeout=900):
        hdrs  = {"Authorization": f"Bearer {dc_token}", "Content-Type": "application/json"}
        start = _time.time()
        while _time.time() < start + timeout:
            r = requests.get(f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{job_id}", headers=hdrs)
            if r.ok:
                resp  = r.json()
                state = resp.get("state") or resp.get("data", {}).get("state", "")
                elapsed = int(_time.time() - start)
                print(f"\r  ⏳ {label}: {state} ({elapsed}s)", end="", flush=True)
                if state == "JobComplete":
                    print(); ok(f"{label}: JobComplete ({elapsed}s)"); return True
                if state in ("Failed", "Aborted"):
                    print(); warn(f"Ingest job {label} ended: {state} — continuing anyway"); return False
            _time.sleep(10)
        warn(f"Timeout waiting for ingest job: {label} — continuing anyway")
        return False

    wait_job(fact_job_id, "Fact_Sales_Activity")
    wait_job(dim_job_id,  "Dim_Team")

    phase("Creating workspace")

    r = requests.get(f"{BASE_SEM}/tableau/workspaces", headers=SF_HDRS)
    existing_ws = {w["name"]: w["id"] for w in r.json().get("workspaces", [])}
    if WORKSPACE_NAME in existing_ws:
        info(f"Workspace '{WORKSPACE_NAME}' exists — deleting and recreating")
        requests.delete(f"{BASE_SEM}/tableau/workspaces/{WORKSPACE_NAME}", headers=SF_HDRS)
        _time.sleep(3)

    r = requests.post(f"{BASE_SEM}/tableau/workspaces", headers=SF_HDRS, json={
        "label": WORKSPACE_NAME,
        "description": f"Demo: {COMPANY_NAME} {USE_CASE} — {PERSONA}"
    })
    if not r.ok: die("Failed to create workspace", r)
    workspace_name = r.json()["name"]
    workspace_id   = r.json()["id"]
    ok(f"Workspace created: {workspace_name}")

    phase("Building Semantic Data Model")

    SDM_LABEL = f"{COMPANY_NAME} {USE_CASE}"
    r = requests.get(f"{BASE_SEM}/ssot/semantic/models", headers=SF_HDRS, params={"limit": 200})
    for sdm in r.json().get("items", []):
        if sdm.get("label", "") == SDM_LABEL:
            info(f"SDM '{sdm['apiName']}' exists — deleting")
            requests.delete(f"{BASE_SEM}/ssot/semantic/models/{sdm['apiName']}", headers=SF_HDRS)
            _time.sleep(3)

    r = requests.post(f"{BASE_SEM}/ssot/semantic/models", headers=SF_HDRS, json={
        "label": SDM_LABEL, "description": f"{USE_CASE} metrics for {COMPANY_NAME}",
        "agentEnabled": True, "dataspace": "default",
    })
    if not r.ok: die("Failed to create SDM", r)
    sdm_api_name = r.json().get("apiName")
    ok(f"SDM created: {sdm_api_name}")

    r = requests.post(f"{BASE_SEM}/ssot/semantic/models/{sdm_api_name}/data-objects", headers=SF_HDRS, json={
        "dataObjectName": FACT_DLO, "label": "Sales Activity", "dataObjectType": "dlo",
    })
    if not r.ok: die("Failed to add fact DLO to SDM", r)
    fact_do_api = r.json().get("apiName")
    ok(f"DLO added to SDM: Sales Activity ({fact_do_api})")

    phase("Configuring measurements and metrics")

    r = requests.get(f"{BASE_SEM}/ssot/semantic/models/{sdm_api_name}/data-objects/{fact_do_api}", headers=SF_HDRS)
    detected_measurements = {}
    field_map = {}
    if r.ok:
        do_data = r.json()
        for m in do_data.get("semanticMeasurements", []):
            base = m["dataObjectFieldName"].replace("__c", "")
            detected_measurements[base] = (m["apiName"], m["dataObjectFieldName"])
            field_map[base] = m["apiName"]
        for d in do_data.get("semanticDimensions", []):
            dof  = d.get("dataObjectFieldName", "")
            base = dof.replace("__c", "") if dof else d["apiName"].rstrip("0123456789")
            if base: field_map[base] = d["apiName"]
        info(f"Field map preview: {dict(list(field_map.items())[:6])}")

    MEASUREMENT_CONFIG = [
        ("inperson_activities", "In-Person Activities", "Sum"),
        ("remote_activities",   "Remote Activities",    "Sum"),
        ("deals_closed",        "Deals Closed",         "Sum"),
        ("win_rate",            "Win Rate",             "Average"),
        ("avg_deal_size",       "Avg Deal Size",        "Average"),
        ("avg_cycle_days",      "Avg Cycle Days",       "Average"),
        ("pipeline_coverage",   "Pipeline Coverage",    "Average"),
        ("revenue_closed",      "Revenue Closed",       "Sum"),
        ("quota_attainment",    "Quota Attainment",     "Average"),
    ]

    configured = 0
    for base_field, label, agg in MEASUREMENT_CONFIG:
        if base_field not in detected_measurements:
            warn(f"Measurement not found: {base_field} (skipping)"); continue
        api_name, field_name = detected_measurements[base_field]
        r = requests.put(
            f"{BASE_SEM}/ssot/semantic/models/{sdm_api_name}/data-objects/{fact_do_api}/measurements/{api_name}",
            headers=SF_HDRS,
            json={"apiName": api_name, "label": label, "dataObjectFieldName": field_name, "aggregationType": agg},
        )
        if r.ok: configured += 1
        else: warn(f"Measurement config failed for {label}: {r.status_code} {r.text[:120]}")
    ok(f"Measurements configured: {configured}/{len(MEASUREMENT_CONFIG)}")

    def _fapi(base): return field_map.get(base, base)

    # (clc_api, clc_label, agg_fn, meas_base, metric_api, metric_label, sentiment, singular, plural)
    METRIC_CONFIG = [
        ("SF_InPerson_Activities_clc", "In-Person Activities", "SUM", "inperson_activities", "SF_InPerson_Activities_mtc", "In-Person Activities", "SentimentTypeUpIsGood", "in-person sales activity",  "in-person sales activities"),
        ("SF_Deals_Closed_clc",        "Deals Closed",         "SUM", "deals_closed",        "SF_Deals_Closed_mtc",        "Deals Closed",         "SentimentTypeUpIsGood", "deal closed",               "deals closed"),
        ("SF_Win_Rate_clc",            "Win Rate",             "AVG", "win_rate",            "SF_Win_Rate_mtc",            "Win Rate",             "SentimentTypeUpIsGood", "win rate",                  "win rates"),
        ("SF_Revenue_Closed_clc",      "Revenue Closed",       "SUM", "revenue_closed",      "SF_Revenue_Closed_mtc",      "Revenue Closed",       "SentimentTypeUpIsGood", "revenue dollar closed",     "revenue dollars closed"),
        ("SF_Quota_Attainment_clc",    "Quota Attainment",     "AVG", "quota_attainment",    "SF_Quota_Attainment_mtc",    "Quota Attainment",     "SentimentTypeUpIsGood", "quota attainment",          "quota attainment"),
        ("SF_Avg_Cycle_Days_clc",      "Avg Sales Cycle Days", "AVG", "avg_cycle_days",      "SF_Avg_Cycle_Days_mtc",      "Avg Sales Cycle Days", "SentimentTypeUpIsBad",  "sales cycle day",           "sales cycle days"),
    ]

    clc_map = {}
    for clc_api, clc_label, agg_fn, meas_base, *_ in METRIC_CONFIG:
        if meas_base not in detected_measurements:
            warn(f"Skipping _clc for {clc_label} — measurement not found"); continue
        meas_api, _ = detected_measurements[meas_base]
        expr = f"{agg_fn}([{fact_do_api}].[{meas_api}])"
        r = requests.post(f"{BASE_SEM}/ssot/semantic/models/{sdm_api_name}/calculated-measurements", headers=SF_HDRS, json={
            "apiName": clc_api, "label": clc_label,
            "aggregationType": "UserAgg", "dataType": "Number", "decimalPlace": 2,
            "directionality": "Up", "displayCategory": "Continuous", "expression": expr,
            "filters": [], "isOverrideBase": False, "isVisible": True, "level": "AggregateFunction",
            "overriddenProperties": [], "semanticDataType": "None", "sentiment": "SentimentTypeUpIsGood",
            "shouldTreatNullsAsZeros": False, "sortOrder": "None", "totalAggregationType": "Sum",
        })
        if r.status_code in (200, 201):
            clc_map[clc_api] = r.json().get("apiName", clc_api)
        else:
            warn(f"_clc failed for {clc_label}: {r.status_code} {r.text[:150]}")

    metric_names = []
    for clc_api, _, __, ___, metric_api, metric_label, sentiment, singular, plural in METRIC_CONFIG:
        actual_clc = clc_map.get(clc_api)
        if not actual_clc:
            warn(f"Skipping metric {metric_label} — no _clc field"); continue
        r = requests.post(f"{BASE_SEM66}/ssot/semantic/models/{sdm_api_name}/metrics", headers=SF_HDRS, json={
            "apiName": metric_api, "label": metric_label,
            "aggregationType": "UserAgg",
            "measurementReference": {"calculatedFieldApiName": actual_clc},
            "timeDimensionReference": {"tableFieldReference": {"fieldApiName": _fapi("date"), "tableApiName": fact_do_api}},
            "timeGrains": ["Day", "Week", "Month", "Quarter", "Year"],
            "filters": [], "isCumulative": False, "isGoalEditingBlocked": False,
            "additionalDimensions": [
                {"tableFieldReference": {"fieldApiName": _fapi("segment"), "tableApiName": fact_do_api}},
                {"tableFieldReference": {"fieldApiName": _fapi("region"),  "tableApiName": fact_do_api}},
            ],
            "insightsSettings": {
                "insightTypes": [
                    {"enabled": False, "type": "TopContributors"},
                    {"enabled": True,  "type": "TrendChangeAlert"},
                    {"enabled": True,  "type": "BottomContributors"},
                    {"enabled": True,  "type": "ConcentratedContributionAlert"},
                    {"enabled": True,  "type": "TopDrivers"},
                    {"enabled": True,  "type": "TopDetractors"},
                    {"enabled": True,  "type": "CurrentTrend"},
                    {"enabled": False, "type": "OutlierDetection"},
                    {"enabled": False, "type": "RecordLevelTable"},
                ],
                "insightsDimensionsReferences": [
                    {"tableFieldReference": {"fieldApiName": _fapi("segment"), "tableApiName": fact_do_api}},
                    {"tableFieldReference": {"fieldApiName": _fapi("region"),  "tableApiName": fact_do_api}},
                ],
                "singularNoun": singular, "pluralNoun": plural, "sentiment": sentiment,
            },
        })
        if r.status_code in (200, 201):
            actual = r.json().get("apiName", metric_api)
            ok(f"Metric created: {metric_label} ({actual})")
            metric_names.append(actual)
        else:
            warn(f"Metric failed: {metric_label} — {r.status_code} {r.text[:150]}")

    ok(f"Semantic metrics: {len(metric_names)}/{len(METRIC_CONFIG)}")

    phase("Updating business preferences")

    bp_ok = bp_fail = 0
    for clc_api, _, __, ___, metric_api, metric_label, sentiment, singular, plural in METRIC_CONFIG:
        actual_api = next((n for n in metric_names if n == metric_api), None)
        if not actual_api:
            continue
        # GET current metric state then PUT back with nouns filled in
        rg = requests.get(f"{BASE_SEM66}/ssot/semantic/models/{sdm_api_name}/metrics/{actual_api}",
                          headers=SF_HDRS, params={"minorVersion": "12"})
        if not rg.ok:
            warn(f"Could not fetch metric for BP update: {metric_label}"); bp_fail += 1; continue
        m = rg.json()
        for k in ("id", "createdBy", "createdDate", "lastModifiedBy", "lastModifiedDate"):
            m.pop(k, None)
        m.setdefault("insightsSettings", {})
        m["insightsSettings"]["singularNoun"] = singular
        m["insightsSettings"]["pluralNoun"]   = plural
        m["insightsSettings"]["sentiment"]    = sentiment
        rp = requests.put(f"{BASE_SEM66}/ssot/semantic/models/{sdm_api_name}/metrics/{actual_api}",
                          headers=SF_HDRS, params={"minorVersion": "12"}, json=m)
        if rp.ok:
            ok(f"Business prefs: {metric_label} — '{singular}' / '{plural}'")
            bp_ok += 1
        else:
            warn(f"BP update failed for {metric_label}: {rp.status_code} {rp.text[:120]}")
            bp_fail += 1

    ok(f"Business preferences updated: {bp_ok}/{len(metric_names)}")

    phase("Creating visualizations")

    VIZ_BASE   = f"{sf_instance}/services/data/v66.0"
    VIZ_PARAMS = {"minorVersion": "12"}
    OBJ        = fact_do_api
    FM         = field_map

    FONTS = {
        "actionableHeaders": {"color": "#0250D9", "size": 13},
        "axisTickLabels":    {"color": "#2E2E2E", "size": 13},
        "fieldLabels":       {"color": "#2E2E2E", "size": 13},
        "headers":           {"color": "#2E2E2E", "size": 13},
        "legendLabels":      {"color": "#2E2E2E", "size": 13},
        "markLabels":        {"color": "#2E2E2E", "size": 13},
        "marks":             {"color": "#2E2E2E", "size": 13},
    }
    LINES = {
        "axisLine": {"color": "#C9C9C9"}, "fieldLabelDividerLine": {"color": "#C9C9C9"},
        "separatorLine": {"color": "#C9C9C9"}, "zeroLine": {"color": "#C9C9C9"},
    }

    def _vizql_mark_headers():
        return {"encodings": [], "isAutomatic": True, "stack": {"isAutomatic": True, "isStacked": False}, "type": "Text"}

    def _marks_headers_style():
        return {"color": {"color": ""}, "isAutomaticSize": True,
                "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                "range": {"reverse": False}, "size": {"isAutomatic": True, "type": "Pixel", "value": 13}}

    def make_viz(name, label, fields, vis_spec):
        payload = {
            "name": name, "label": label,
            "dataSource": {"name": sdm_api_name, "label": SDM_LABEL, "type": "SemanticModel"},
            "workspace": {"name": workspace_name, "label": workspace_name},
            "interactions": [], "fields": fields, "visualSpecification": vis_spec,
            "view": {"label": "default", "name": f"{name}_default",
                     "viewSpecification": {"sortOrders": {"columns": [], "fields": {}, "rows": []}}}
        }
        r = requests.post(f"{VIZ_BASE}/tableau/visualizations", headers=SF_HDRS, params=VIZ_PARAMS, json=payload)
        if r.status_code in (200, 201):
            vname = r.json().get("name", name)
            ok(f"Viz created: {label} ({vname})")
            return vname
        warn(f"Viz failed: {label} — {r.status_code} {r.text[:200]}")
        return None

    viz_names = []

    # 1. In-Person Activities Trend by Segment (line)
    v = make_viz("SF_InPerson_Activities_Trend", "In-Person Activities Trend",
        fields={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("date", "date"), "function": "DatePartMonth"},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": FM.get("inperson_activities", "inperson_activities"), "function": "Sum"},
            "F3": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("segment", "segment")},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {"F3": {"isVisible": True, "position": "Right", "title": {"isVisible": True}}},
            "marks": {"fields": {}, "headers": _vizql_mark_headers(),
                      "panes": {"encodings": [{"fieldKey": "F3", "type": "Color"}],
                                "isAutomatic": False, "type": "Line", "stack": {"isAutomatic": True, "isStacked": False}}},
            "style": {
                "axis": {"fields": {"F2": {"isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": False, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 0, "displayUnits": "Auto",
                        "includeThousandSeparator": True, "negativeValuesFormat": "Auto", "prefix": "", "suffix": "", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}}}},
                "encodings": {"fields": {"F2": {"defaults": {"format": {"numberFormatInfo": {
                    "decimalPlaces": 0, "displayUnits": "Auto", "includeThousandSeparator": True,
                    "negativeValuesFormat": "Auto", "prefix": "", "suffix": "", "type": "Number"}}}}}},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True}, "rows": {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {"columns": {"mergeRepeatedCells": True, "showIndex": False},
                            "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                            "rows": {"mergeRepeatedCells": True, "showIndex": False}},
                "lines": LINES,
                "marks": {"fields": {}, "headers": _marks_headers_style(),
                          "panes": {"color": {"color": ""}, "isAutomaticSize": False,
                                    "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                                    "range": {"reverse": False}, "size": {"isAutomatic": False, "type": "Pixel", "value": 3}}},
                "referenceLines": {}, "shading": {"backgroundColor": "#FFFFFF", "banding": {}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        })
    if v: viz_names.append(v)

    # 2. Deals Closed Trend (line)
    v = make_viz("SF_Deals_Closed_Trend", "Deals Closed Trend",
        fields={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("date", "date"), "function": "DatePartMonth"},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": FM.get("deals_closed", "deals_closed"), "function": "Sum"},
            "F3": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("segment", "segment")},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {"F3": {"isVisible": True, "position": "Right", "title": {"isVisible": True}}},
            "marks": {"fields": {}, "headers": _vizql_mark_headers(),
                      "panes": {"encodings": [{"fieldKey": "F3", "type": "Color"}],
                                "isAutomatic": False, "type": "Line", "stack": {"isAutomatic": True, "isStacked": False}}},
            "style": {
                "axis": {"fields": {"F2": {"isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": False, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 0, "displayUnits": "Auto",
                        "includeThousandSeparator": True, "negativeValuesFormat": "Auto", "prefix": "", "suffix": "", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}}}},
                "encodings": {"fields": {"F2": {"defaults": {"format": {"numberFormatInfo": {
                    "decimalPlaces": 0, "displayUnits": "Auto", "includeThousandSeparator": True,
                    "negativeValuesFormat": "Auto", "prefix": "", "suffix": "", "type": "Number"}}}}}},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True}, "rows": {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {"columns": {"mergeRepeatedCells": True, "showIndex": False},
                            "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                            "rows": {"mergeRepeatedCells": True, "showIndex": False}},
                "lines": LINES,
                "marks": {"fields": {}, "headers": _marks_headers_style(),
                          "panes": {"color": {"color": ""}, "isAutomaticSize": False,
                                    "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                                    "range": {"reverse": False}, "size": {"isAutomatic": False, "type": "Pixel", "value": 3}}},
                "referenceLines": {}, "shading": {"backgroundColor": "#FFFFFF", "banding": {}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        })
    if v: viz_names.append(v)

    # 3. Win Rate by Region (bar)
    v = make_viz("SF_Win_Rate_By_Region", "Win Rate by Region",
        fields={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("region", "region")},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": FM.get("win_rate", "win_rate"), "function": "Avg"},
            "F3": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("segment", "segment")},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {"F3": {"isVisible": True, "position": "Right", "title": {"isVisible": True}}},
            "marks": {"fields": {}, "headers": {**_vizql_mark_headers(), "stack": {"isAutomatic": True, "isStacked": True}},
                      "panes": {"encodings": [{"fieldKey": "F3", "type": "Color"}],
                                "isAutomatic": False, "type": "Bar", "stack": {"isAutomatic": True, "isStacked": False}}},
            "style": {
                "axis": {"fields": {"F2": {"isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": True, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 1, "displayUnits": "Auto",
                        "includeThousandSeparator": False, "negativeValuesFormat": "Auto", "prefix": "", "suffix": "%", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}}}},
                "encodings": {"fields": {"F2": {"defaults": {"format": {"numberFormatInfo": {
                    "decimalPlaces": 1, "displayUnits": "Auto", "includeThousandSeparator": False,
                    "negativeValuesFormat": "Auto", "prefix": "", "suffix": "%", "type": "Number"}}}}}},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True}, "rows": {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {"columns": {"mergeRepeatedCells": True, "showIndex": False},
                            "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                            "rows": {"mergeRepeatedCells": True, "showIndex": False}},
                "lines": LINES,
                "marks": {"fields": {}, "headers": _marks_headers_style(),
                          "panes": {"color": {"color": ""}, "isAutomaticSize": True,
                                    "isStackingAxisCentered": False,
                                    "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": True},
                                    "range": {"reverse": False}, "size": {"isAutomatic": True, "type": "Percentage", "value": 75}}},
                "referenceLines": {}, "shading": {"backgroundColor": "#FFFFFF", "banding": {"rows": {"color": "#E5E5E5"}}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        })
    if v: viz_names.append(v)

    # 4. Avg Sales Cycle Days by Segment (bar)
    v = make_viz("SF_Sales_Cycle_Days", "Avg Sales Cycle Days by Segment",
        fields={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("segment", "segment")},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": FM.get("avg_cycle_days", "avg_cycle_days"), "function": "Avg"},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {}, "legends": {},
            "marks": {"fields": {}, "headers": _vizql_mark_headers(),
                      "panes": {"encodings": [], "isAutomatic": True, "type": "Bar", "stack": {"isAutomatic": True, "isStacked": False}}},
            "style": {
                "axis": {"fields": {"F2": {"isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": True, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 1, "displayUnits": "Auto",
                        "includeThousandSeparator": False, "negativeValuesFormat": "Auto", "prefix": "", "suffix": "d", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}}}},
                "encodings": {"fields": {"F2": {"defaults": {"format": {"numberFormatInfo": {
                    "decimalPlaces": 1, "displayUnits": "Auto", "includeThousandSeparator": False,
                    "negativeValuesFormat": "Auto", "prefix": "", "suffix": "d", "type": "Number"}}}}}},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True}, "rows": {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {"columns": {"mergeRepeatedCells": True, "showIndex": False},
                            "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                            "rows": {"mergeRepeatedCells": True, "showIndex": False}},
                "lines": LINES,
                "marks": {"fields": {}, "headers": _marks_headers_style(),
                          "panes": {"color": {"color": ""}, "isAutomaticSize": True,
                                    "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": True},
                                    "range": {"reverse": True}, "size": {"isAutomatic": True, "type": "Percentage", "value": 75}}},
                "referenceLines": {}, "shading": {"backgroundColor": "#FFFFFF", "banding": {"rows": {"color": "#E5E5E5"}}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        })
    if v: viz_names.append(v)

    ok(f"Visualizations created: {len(viz_names)}/4")

    phase("Building dashboard")

    dashboard_name  = "Salesforce_Sales_Dashboard"
    dashboard_label = "Salesforce Sales Performance Dashboard"
    requests.delete(f"{VIZ_BASE}/tableau/dashboards/{dashboard_name}", headers=SF_HDRS, params=VIZ_PARAMS)
    _time.sleep(1)

    COL_COUNT = 72
    METRICS_PER_ROW = 3
    metric_col_width = COL_COUNT // METRICS_PER_ROW
    widgets = {}
    n_metrics = len(metric_names)

    def _metric_widget_style():
        return {"borderColor": "#C9C9C9", "borderEdges": ["all"], "borderRadius": 20}

    def _viz_widget_style():
        return {"borderColor": "#C9C9C9", "borderEdges": [], "borderRadius": 16}

    def _container_widget_style():
        return {"borderColor": "#c9c9c9", "borderEdges": ["all"], "borderRadius": 16}

    for i, mn in enumerate(metric_names):
        k = f"metric_{i+1}"
        widgets[k] = {
            "actions": [], "name": k, "type": "metric",
            "source": {"name": mn},
            "parameters": {
                "metricOption": {"sdmApiName": sdm_api_name,
                    "layout": {"componentVisibility": {"title": True, "value": True, "comparison": True, "chart": True, "insights": True, "details": True}}},
                "receiveFilterSource": {"filterMode": "all", "widgetIds": []},
                "widgetStyle": _metric_widget_style(),
            }
        }

    widgets["text_title"] = {
        "actions": [], "name": "text_title", "type": "text",
        "parameters": {
            "content": [
                {"attributes": {"size": "20px", "color": "#03234d"}, "insert": f"{COMPANY_NAME} {USE_CASE}"},
                {"insert": "\n"},
                {"attributes": {"color": "#5c5c5c", "size": "14px"}, "insert": STORY},
                {"attributes": {"align": "left"}, "insert": "\n"},
            ],
            "widgetStyle": {"borderColor": "#C9C9C9", "borderEdges": []},
        }
    }

    for i, vn in enumerate(viz_names):
        k  = f"visualization_{i+1}"
        ck = f"container_{i+1}"
        widgets[k]  = {"actions": [], "name": k,  "type": "visualization", "source": {"name": vn},
                       "parameters": {"legendPosition": "Right", "receiveFilterSource": {"filterMode": "all", "widgetIds": []}, "widgetStyle": _viz_widget_style()}}
        widgets[ck] = {"actions": [], "name": ck, "type": "container",
                       "parameters": {"widgetStyle": _container_widget_style()}}

    page_widgets = []
    layout_row   = 0
    n_rows = (n_metrics + METRICS_PER_ROW - 1) // METRICS_PER_ROW
    for i in range(n_metrics):
        page_widgets.append({
            "name": f"metric_{i+1}",
            "column": (i % METRICS_PER_ROW) * metric_col_width,
            "row": layout_row + (i // METRICS_PER_ROW) * 15,
            "colspan": metric_col_width, "rowspan": 15,
        })
    layout_row += n_rows * 15
    page_widgets.append({"name": "text_title", "column": 1, "row": layout_row, "colspan": 45, "rowspan": 5})
    layout_row += 5
    VIZ_W, VIZ_H = 35, 28
    for i in range(len(viz_names)):
        col_start = i * (VIZ_W + 2)
        page_widgets.append({"name": f"container_{i+1}", "column": col_start, "row": layout_row, "colspan": VIZ_W, "rowspan": VIZ_H})
        page_widgets.append({"name": f"visualization_{i+1}", "column": col_start + 1, "row": layout_row + 1, "colspan": VIZ_W - 2, "rowspan": VIZ_H - 2})
    layout_row += VIZ_H

    dash_payload = {
        "name": dashboard_name, "label": dashboard_label,
        "workspaceIdOrApiName": workspace_name,
        "widgets": widgets,
        "layouts": [{"name": "default", "columnCount": COL_COUNT, "rowHeight": 10, "maxWidth": 1200,
            "style": {"backgroundColor": "#f3f3f3", "cellSpacingX": 8, "cellSpacingY": 8, "gutterColor": "#f3f3f3"},
            "pages": [{"name": str(uuid.uuid4()), "label": "Overview", "widgets": page_widgets}]}],
    }

    r = requests.post(f"{VIZ_BASE}/tableau/dashboards", headers=SF_HDRS, params=VIZ_PARAMS, json=dash_payload)
    if r.status_code in (200, 201):
        dashboard_id = r.json().get("id") or r.json().get("name")
        ok(f"Dashboard created: {dashboard_name} (id: {dashboard_id})")
    else:
        warn(f"Dashboard creation failed: {r.status_code} {r.text[:300]}")
        info("You can build the dashboard manually in the Tableau Next UI.")
        dashboard_id = None

    _save_ckpt({"next_done": True, "workspace_name": workspace_name, "sdm_api_name": sdm_api_name,
                "dashboard_id": dashboard_id, "dashboard_name": dashboard_name})

elif BUILD_NEXT:
    info("Tableau Next skipped (checkpoint found)")
    workspace_name = _ckpt.get("workspace_name", WORKSPACE_NAME)
    sdm_api_name   = _ckpt.get("sdm_api_name", "")
    dashboard_id   = _ckpt.get("dashboard_id")
    dashboard_name = _ckpt.get("dashboard_name", "Salesforce_Sales_Dashboard")

# ── Final summary + docs ───────────────────────────────────────────────────────
elapsed = int(_time.time() - _SCRIPT_START)
W = 66
print(f"\n{'='*W}")
print(f"  ✅ {COMPANY_NAME} {USE_CASE} Demo — BUILD COMPLETE ({elapsed}s)")
if BUILD_PULSE:
    print(f"  {'─'*62}")
    print(f"  TABLEAU PULSE")
    print(f"  Project:     {pulse_project_name}")
    print(f"  Group:       {pulse_group_name}")
    print(f"  Datasource:  {PULSE_DS_NAME}")
    print(f"  Metrics ({pulse_metric_count}):")
    for m in pulse_metric_ids:
        print(f"    • {m['name']}")
    print(f"  🔗 {TC_SERVER_URL}/pulse")
if BUILD_NEXT:
    print(f"  {'─'*62}")
    print(f"  TABLEAU NEXT")
    print(f"  Workspace:   {workspace_name}")
    print(f"  SDM:         {sdm_api_name}")
    print(f"  Dashboard:   {dashboard_id or dashboard_name}")
    if 'metric_names' in dir() and metric_names:
        print(f"  Metrics ({len(metric_names)}):")
        for mn in metric_names:
            print(f"    • {mn}")
    if 'viz_names' in dir() and viz_names:
        print(f"  Visualizations ({len(viz_names)}):")
        for vn in viz_names:
            print(f"    • {vn}")
    print(f"  🔗 {sf_instance}/tableau/workspace/{workspace_name}")
    print(f"  ⚡ Enable Analytics Agent Readiness:")
    print(f"     Data 360 → {sdm_api_name} → Settings → Analytics Agent Readiness → ON")
if BUILD_CSV:
    print(f"  {'─'*62}")
    print(f"  CSV")
    print(f"  File:        {csv_path.name}")
    print(f"  Rows:        {len(df_fact)}")
print(f"{'='*W}\n")

# Write guide
guide_path = DEMO_DIR / f"{company_slug}_{use_case_slug}_guide.md"
guide_path.write_text(f"""# {COMPANY_NAME} — {USE_CASE} Demo Guide

**Persona:** {PERSONA}
**Story:** {STORY}
**Built:** {_dt.now().strftime("%Y-%m-%d %H:%M")}

## The Story

Rep in-person activities have declined significantly over the past 6 months.
Because in-person engagement is the leading indicator of deal closure, deals closed
are now falling in turn — with the impact most visible in Enterprise.
Win rates are softening, sales cycles are lengthening, and pipeline coverage is thinning.

## Key Metrics

| Metric | Role | Trend |
|--------|------|-------|
| In-Person Activities | PRIMARY (leading) | ↓ Down ~38% |
| Deals Closed | PRIMARY (outcome) | ↓ Down ~30% |
| Win Rate | Supporting | ↓ Softening |
| Avg Sales Cycle Days | Supporting | ↑ Lengthening |
| Pipeline Coverage | Supporting | ↓ Thinning |
| Revenue Closed | Supporting | ↓ Declining |

## Demo Talking Points

1. **Open In-Person Activities** — show the 6-month decline first. This is the "uh oh" leading indicator.
2. **Show Deals Closed** — confirm the lag effect. Activities drop first, then deals follow.
3. **Segment breakdown** — Enterprise hit hardest; their in-person cadence matters most.
4. **Win rate + cycle days** — softer signals that corroborate the story.
5. **The ask**: if we restore in-person engagement targets, what does the model predict for deals in Q+1?

## Concierge Prompts

- "What's happening with in-person activities?"
- "Which segment has seen the biggest drop in deals closed?"
- "How has our win rate changed over the last 6 months?"
- "Which region is most at risk for missing quota this quarter?"
- "What should the VP of Sales focus on to recover deals closed?"

## Assets

- Workspace: `{workspace_name if BUILD_NEXT else "N/A"}`
- SDM: `{sdm_api_name if BUILD_NEXT else "N/A"}`
- Dashboard: {dashboard_name if BUILD_NEXT else "N/A"}
- CSV: {csv_path.name if BUILD_CSV else "N/A"}

## Workspace URL

{sf_instance + "/tableau/workspace/" + workspace_name if BUILD_NEXT else "N/A"}

## Post-Build Step

{"Enable Analytics Agent Readiness: Data 360 → Semantic Model → " + sdm_api_name + " → Settings → Analytics Agent Readiness → ON" if BUILD_NEXT else "N/A"}
""")
ok(f"Demo guide written: {guide_path.name}")

# Write walkthrough docx
from docx import Document
from docx.shared import Pt, RGBColor

def _add_heading(doc, text, level=1, color=None):
    p = doc.add_heading(text, level=level)
    if color:
        for run in p.runs: run.font.color.rgb = RGBColor(*color)
    return p

def _add_para(doc, text, bold=False, italic=False):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold; run.italic = italic
    return p

def _add_question(doc, question, expected):
    p = doc.add_paragraph()
    p.add_run("Ask: ").bold = True
    p.add_run(f'"{question}"').italic = True
    _add_para(doc, expected)
    doc.add_paragraph()

docx_path = DEMO_DIR / f"{company_slug}_{use_case_slug}_demo_walkthrough.docx"
doc = Document()

t = doc.add_heading(f"{COMPANY_NAME} — {USE_CASE}", 0)
for run in t.runs: run.font.color.rgb = RGBColor(2, 35, 77)
t2 = doc.add_heading("Demo Walkthrough", 1)
for run in t2.runs: run.font.color.rgb = RGBColor(80, 80, 80)
doc.add_paragraph(f"Output: Pulse + Tableau Next + CSV  |  Persona: {PERSONA}  |  Built: {_dt.now().strftime('%Y-%m-%d %H:%M')}")
doc.add_paragraph(f"Story: {STORY}")
doc.add_paragraph()

if BUILD_PULSE:
    _add_heading(doc, "Tableau Pulse", 1, color=(2, 35, 77))
    _add_heading(doc, "Setup", 2)
    for item in [
        f"Navigate to Tableau Pulse: {TC_SERVER_URL}/pulse",
        f'Find the group "{pulse_group_name}"',
        "Confirm all 8 metrics are visible on the overview screen",
        "Set time range to Last 6 months to make the signal visible",
    ]: doc.add_paragraph(item, style="List Bullet")

    _add_heading(doc, "Part 1 — Orient (30 seconds)", 2)
    _add_para(doc, "Briefly name the metrics. Land on In-Person Activities and Deals Closed immediately — these two tell the full story.")
    for m in [
        "In-Person Activities ← PRIMARY LEADING INDICATOR. This is the cause.",
        "Deals Closed ← PRIMARY OUTCOME. This is the effect.",
        "Win Rate — supporting. Shows efficiency is also degrading.",
        "Avg Sales Cycle Days — supporting. Deals taking longer to close.",
        "Pipeline Coverage — supporting. Thinning pipeline = less cushion.",
        "Revenue Closed — supporting. The financial impact.",
    ]: doc.add_paragraph(f"• {m}")

    _add_heading(doc, "Part 2 — The leading indicator story", 2)
    _add_para(doc, "Click on In-Person Activities. Show the decline over 6 months.", bold=True)
    for step in [
        "Confirm the downtrend — approx 38% decline over 6 months.",
        "Expand by Segment — Enterprise shows the sharpest drop.",
        "Now switch to Deals Closed — show the same downtrend with a ~1 month lag.",
        'Talking point: "The data is telling us this was predictable. Activity dropped first. Deals followed. This is a leading indicator story."',
    ]: doc.add_paragraph(f"• {step}")

    _add_heading(doc, "Part 3 — Pulse Discover questions", 2)
    for q, e in [
        ("How have in-person activities trended over the last 6 months?", "Time-series confirming the 38% decline. Enterprise segment highlighted."),
        ("Which region has the lowest in-person activity?", "Surfaces the region to investigate first."),
        ("How does deals closed correlate with in-person activities?", "Pulse cross-references the two metrics and confirms the lag relationship."),
        ("Show me win rate by segment this quarter vs last quarter", "Period-over-period showing degrading conversion — Enterprise most affected."),
        ("What should the VP of Sales focus on to recover deals closed?", "Recommendation surfaces: restore in-person cadence in Enterprise, particularly in the lagging region."),
    ]: _add_question(doc, q, f"What to expect: {e}")

    doc.add_page_break()

if BUILD_NEXT:
    _add_heading(doc, "Tableau Next — Concierge", 1, color=(2, 35, 77))
    _add_heading(doc, "Setup", 2)
    for item in [
        f"Open workspace: {sf_instance}/tableau/workspace/{workspace_name}",
        "Open the Salesforce Sales Performance Dashboard",
        "Open the Concierge panel (chat icon, top right)",
        f"Confirm SDM shown is {sdm_api_name}",
        "Analytics Agent Readiness must be ON in Data 360 → Semantic Model → Settings",
    ]: doc.add_paragraph(item, style="List Bullet")

    _add_heading(doc, "Part 1 — Orient (30 seconds)", 2)
    _add_para(doc, "Name the metric tiles quickly. The sparklines on In-Person Activities and Deals Closed tell the story before you speak.")

    _add_heading(doc, "Part 2 — Open on the leading indicator", 2)
    for q, e in [
        ("What's happening with rep in-person activities?",
         "Time-series confirming the 6-month decline with magnitude. Enterprise segment called out as most affected."),
        ("Is this affecting deals closed?",
         "Concierge confirms the lag relationship — activities dropped 6 months ago, deals started falling 5 months ago."),
    ]: _add_question(doc, q, f"What to expect: {e}")

    _add_heading(doc, "Part 3 — Dig into the why", 2)
    for q, e in [
        ("Which segment is most at risk?",
         "Enterprise surfaces — highest value, biggest drop in both activities and deals closed."),
        ("What does the sales cycle look like for Enterprise right now?",
         "Avg cycle days increasing — deals that are closing are taking longer, compounding the volume drop."),
        ("How is pipeline coverage trending?",
         "Coverage ratio below 3x — not enough pipeline to make up for the close rate decline."),
    ]: _add_question(doc, q, f"What to expect: {e}")

    _add_heading(doc, "Part 4 — Quantify and close", 2)
    for q, e in [
        ("What is our quota attainment trending toward this quarter?",
         "Projection based on current trajectory — shows the gap to quota if nothing changes."),
        ("What should the VP of Sales prioritize to recover deals closed next quarter?",
         "Three-part recommendation: (1) restore in-person cadence in Enterprise, (2) focus on the lagging region, (3) reduce cycle days through faster qualification."),
    ]: _add_question(doc, q, f"What to expect: {e}")

    _add_heading(doc, "Key Talking Points", 2)
    for pt in [
        '"The dashboard shows the what. Concierge shows the why and the so what."',
        '"In-person activities is a leading indicator — this was a predictable outcome. The data gave us the warning 6 months ago."',
        '"Concierge doesn\'t just describe the problem — it tells the VP what to do about it and why."',
        '"Every answer is grounded in the same governed metrics your analysts use. No shadow spreadsheets."',
    ]: doc.add_paragraph(pt, style="List Bullet")

    _add_heading(doc, "Suggested Live Audience Prompts", 2)
    for prompt in [
        '"Ask it which rep team you should investigate first."',
        '"Ask it to compare this quarter\'s win rate to the same quarter last year."',
        '"Ask it what happens to revenue if we improve in-person activities by 20%."',
        '"Ask it something you\'d normally ask your head of sales ops on a Monday morning."',
    ]: doc.add_paragraph(prompt, style="List Bullet")

doc.save(str(docx_path))
ok(f"Demo walkthrough saved: {docx_path.name}")

mac_notify("Analytics Builder", f"{COMPANY_NAME} {USE_CASE} demo ready! ({elapsed}s)")

W2 = 66
print(f"\n{'='*W2}")
print(f"  📁 Demo files")
print(f"  {'─'*62}")
print(f"  Guide:       {guide_path}")
print(f"  Walkthrough: {docx_path}")
if BUILD_CSV:
    print(f"  CSV:         {csv_path}")
print(f"{'='*W2}\n")
