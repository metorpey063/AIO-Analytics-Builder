"""
BI Worldwide — Sales Incentive Program Engagement Demo
Outputs: Tableau Pulse + Tableau Next (Data Cloud)
"""

import os, sys, json, time, uuid, csv, math, random, requests
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from connections import (
    load_config, get_tableau_token, tableau_headers, tableau_pulse_headers,
    get_all_tokens
)

# ── Advanced settings ─────────────────────────────────────────────────────────
HISTORY_MONTHS        = 24       # 6 / 12 / 24 / 36
GRAIN                 = "weekly" # daily / weekly / monthly
SIGNAL_MAGNITUDE      = 0.25    # primary metric decline (fraction)
SIGNAL_ONSET          = -3      # months before today when decline starts
SIGNAL_SHAPE          = "accelerating"  # ramp / accelerating / step
SUPPORTING_MAGNITUDE  = 0.18    # supporting metric movement (fraction)

print("=" * 70)
print("BI Worldwide — Sales Incentive Program Engagement Demo")
print("=" * 70)
print(f"  History:              {HISTORY_MONTHS} months")
print(f"  Grain:                {GRAIN}")
print(f"  Primary signal:       -{SIGNAL_MAGNITUDE*100:.0f}% ({SIGNAL_SHAPE})")
print(f"  Signal onset:         {SIGNAL_ONSET} months ago")
print(f"  Supporting signal:    -{SUPPORTING_MAGNITUDE*100:.0f}%")
print("=" * 70)

# ── Config ────────────────────────────────────────────────────────────────────
config = load_config()
TODAY  = date.today()
SLUG   = "bi_worldwide_sales_incentive"
COMPANY = "BI Worldwide"
DEMO_DIR = os.path.dirname(os.path.abspath(__file__))
CHECKPOINT_FILE = os.path.join(DEMO_DIR, f"{SLUG}_checkpoint.json")

# ── Checkpoint ────────────────────────────────────────────────────────────────
def load_checkpoint():
    if os.path.exists(CHECKPOINT_FILE):
        with open(CHECKPOINT_FILE) as f:
            return json.load(f)
    return {
        "all_ws_apis": [], "all_sdm_apis": [],
        "all_viz_apis": [], "all_dash_apis": []
    }

def save_checkpoint(cp):
    with open(CHECKPOINT_FILE, "w") as f:
        json.dump(cp, f, indent=2)

cp = load_checkpoint()

# ── Signal ramp ───────────────────────────────────────────────────────────────
def signal_ramp(d, onset=SIGNAL_ONSET, shape=SIGNAL_SHAPE, duration=3):
    if isinstance(d, pd.Timestamp):
        d = d.date()
    months_from_today = (d.year - TODAY.year) * 12 + (d.month - TODAY.month)
    months_from_onset = months_from_today - onset
    if months_from_onset <= 0:
        return 0.0
    progress = min(1.0, months_from_onset / duration)
    if shape == "ramp":
        return progress
    elif shape == "accelerating":
        return progress ** 2
    elif shape == "step":
        return 1.0 if progress >= 0.3 else 0.0
    return progress

# ── Dimension definitions ─────────────────────────────────────────────────────
VERTICALS  = ["Financial Services", "Automotive", "Technology", "Insurance",
               "Manufacturing", "Life Sciences", "Retail"]
REGIONS    = ["West", "Northeast", "Midwest", "South", "Southwest"]
SIZE_BANDS = ["Small Enterprise", "Mid-Market", "Large Enterprise", "Global"]
PROGRAM_TYPES = ["Sales Contest", "Quota Attainment", "Channel Partner", "President's Club"]

# ── Signal multipliers — differentiated so filtering reveals a culprit ────────
# Logic: separate multiplier paths per program type to create dramatic spread.
# Channel Partner = essentially zero (counter-trend, masks overall average).
# President's Club = 2D compound (region × size) to enable nested drill story.
# Sales Contest / Quota Attainment = simple moderate multipliers.

SIGNAL_MAGNITUDE = 0.52   # override — needs to be higher to punch through accelerating avg

# President's Club 2D compound: region × size band
# Northeast + Mid-Market is the deepest cut (~40% drop); South + Global barely moves (~8%)
PC_COMPOUND = {
    ("Northeast", "Mid-Market"):       2.2,
    ("Northeast", "Small Enterprise"): 1.9,
    ("Northeast", "Large Enterprise"): 1.5,
    ("Northeast", "Global"):           1.1,
    ("West",      "Mid-Market"):       1.8,
    ("West",      "Small Enterprise"): 1.6,
    ("West",      "Large Enterprise"): 1.2,
    ("West",      "Global"):           0.9,
    ("Midwest",   "Mid-Market"):       1.0,
    ("Midwest",   "Small Enterprise"): 0.9,
    ("Midwest",   "Large Enterprise"): 0.7,
    ("Midwest",   "Global"):           0.5,
    ("South",     "Mid-Market"):       0.6,
    ("South",     "Small Enterprise"): 0.5,
    ("South",     "Large Enterprise"): 0.4,
    ("South",     "Global"):           0.3,
    ("Southwest", "Mid-Market"):       0.7,
    ("Southwest", "Small Enterprise"): 0.6,
    ("Southwest", "Large Enterprise"): 0.5,
    ("Southwest", "Global"):           0.4,
}

# Noise scale per size: smaller clients look noisier
NOISE_SCALE = {
    "Small Enterprise": 0.022,
    "Mid-Market":       0.016,
    "Large Enterprise": 0.011,
    "Global":           0.007,
}

random.seed(42)
np.random.seed(42)

# ── Client roster ─────────────────────────────────────────────────────────────
CLIENTS = []
client_id = 1
for vertical in VERTICALS:
    for region in REGIONS:
        for size in SIZE_BANDS:
            for _ in range(2):  # 2 clients per combo = 280 clients
                CLIENTS.append({
                    "client_id":    f"BIW-{client_id:04d}",
                    "client_name":  f"{vertical[:4]}-{region[:2]}-{size[:2]}-{client_id:04d}",
                    "vertical":     vertical,
                    "region":       region,
                    "size_band":    size,
                    "program_type": random.choice(PROGRAM_TYPES),
                    "base_participation": random.uniform(0.62, 0.82),
                    "base_goal_achievement": random.uniform(0.58, 0.76),
                    "base_points_per_rep":   random.uniform(900, 1800),
                    "base_redemption_rate":  random.uniform(0.64, 0.80),
                    "base_active_reps":      random.randint(50, 600),
                })
                client_id += 1

# ── Date range ────────────────────────────────────────────────────────────────
if GRAIN == "weekly":
    freq = "W-MON"
elif GRAIN == "daily":
    freq = "D"
else:
    freq = "MS"

start_date = TODAY - relativedelta(months=HISTORY_MONTHS)
dates = pd.date_range(start=start_date, end=TODAY, freq=freq)

# ── Data generation ───────────────────────────────────────────────────────────
print(f"\nGenerating {len(CLIENTS)} clients × {len(dates)} {GRAIN} periods...")

rows = []
for client in CLIENTS:
    prog = client["program_type"]
    if prog == "President's Club":
        combined_mult = PC_COMPOUND.get((client["region"], client["size_band"]), 1.0)
    elif prog == "Sales Contest":
        combined_mult = 0.55
    elif prog == "Quota Attainment":
        combined_mult = 0.35
    else:  # Channel Partner — counter-trend, near zero
        combined_mult = -0.10  # slight upward drift

    for d in dates:
        ramp   = signal_ramp(d)
        p_ramp = ramp * combined_mult  # primary
        s_ramp = ramp * combined_mult * 0.7  # supporting (lags)

        ns = NOISE_SCALE[client["size_band"]]
        noise = lambda scale=None: np.random.normal(0, scale if scale is not None else ns)

        participation    = max(0.05, client["base_participation"]    * (1 - SIGNAL_MAGNITUDE    * p_ramp) + noise())
        goal_achievement = max(0.05, client["base_goal_achievement"] * (1 - SIGNAL_MAGNITUDE    * p_ramp) + noise())
        points_per_rep   = max(50,   client["base_points_per_rep"]   * (1 - SUPPORTING_MAGNITUDE * s_ramp) + noise() * client["base_points_per_rep"])
        redemption_rate  = max(0.10, client["base_redemption_rate"]  * (1 - SUPPORTING_MAGNITUDE * s_ramp) + noise())
        active_reps      = max(5,    int(client["base_active_reps"]  * (1 - SUPPORTING_MAGNITUDE * 0.5 * s_ramp) + np.random.normal(0, 3)))

        total_eligible_reps = max(active_reps, int(active_reps / max(0.01, participation)))
        points_total        = round(points_per_rep * active_reps)

        rows.append({
            "Record ID":            f"{client['client_id']}_{d.strftime('%Y%m%d')}",
            "Client ID":            client["client_id"],
            "Client Name":          client["client_name"],
            "Date":                 d.strftime("%Y-%m-%d"),
            "Vertical":             client["vertical"],
            "Region":               client["region"],
            "Size Band":            client["size_band"],
            "Program Type":         client["program_type"],
            "Participation Rate":   round(participation, 4),
            "Goal Achievement Rate": round(goal_achievement, 4),
            "Points Per Rep":       round(points_per_rep, 1),
            "Redemption Rate":      round(redemption_rate, 4),
            "Active Reps":          active_reps,
            "Total Eligible Reps":  total_eligible_reps,
            "Points Total":         points_total,
        })

df = pd.DataFrame(rows)
print(f"  Generated {len(df):,} rows")
print(f"\n  Participation Rate  — min:{df['Participation Rate'].min():.3f}  max:{df['Participation Rate'].max():.3f}  mean:{df['Participation Rate'].mean():.3f}")
print(f"  Goal Achievement    — min:{df['Goal Achievement Rate'].min():.3f}  max:{df['Goal Achievement Rate'].max():.3f}  mean:{df['Goal Achievement Rate'].mean():.3f}")
print(f"  Redemption Rate     — min:{df['Redemption Rate'].min():.3f}  max:{df['Redemption Rate'].max():.3f}  mean:{df['Redemption Rate'].mean():.3f}")
print(f"  Points Per Rep      — min:{df['Points Per Rep'].min():.0f}  max:{df['Points Per Rep'].max():.0f}  mean:{df['Points Per Rep'].mean():.0f}")

# Save CSV
csv_path = os.path.join(DEMO_DIR, f"{SLUG}_{TODAY.strftime('%Y%m%d')}.csv")
df.to_csv(csv_path, index=False)
print(f"\n  CSV saved: {csv_path}")
cp["csv_done"] = True
cp["csv_path"] = csv_path
save_checkpoint(cp)

# ── Metric config ─────────────────────────────────────────────────────────────
METRIC_CONFIG = [
    {
        "label":          "Participation Rate",
        "field":          "participation_rate",
        "agg":            "Average",
        "is_rate":        True,
        "description":    "Percentage of eligible sales reps who actively engaged with the incentive program in the period. PRIMARY KPI — a sustained decline signals the program is losing its motivational effect. Use this as the first metric when opening the demo.",
        "why_it_matters": "Participation Rate is the health score of your incentive program. If reps aren't engaging, they're not being motivated — and no amount of reward budget will drive revenue if the program is invisible to the field. A sustained decline here is an early warning that clients may churn or reduce their BI Worldwide contract.",
        "singular":       "participation rate",
        "plural":         "participation rates",
        "sentiment":      "SentimentTypeUpIsGood",
        "pulse_agg":      "AGGREGATION_AVERAGE",
        "pulse_time":     "TIME_COMPARISON_TYPE_LAST_COMPLETE_PERIOD",
    },
    {
        "label":          "Goal Achievement Rate",
        "field":          "goal_achievement_rate",
        "agg":            "Average",
        "is_rate":        True,
        "description":    "Percentage of reps who hit or exceeded their incentive targets in the period.",
        "why_it_matters": "Reps can participate without winning. When Goal Achievement Rate drops while Participation Rate holds, it means reps are showing up but not succeeding — a design problem with the program targets, not a motivational problem. This distinction determines whether the fix is a communications campaign (engagement) or a program redesign (targets).",
        "singular":       "goal achievement rate",
        "plural":         "goal achievement rates",
        "sentiment":      "SentimentTypeUpIsGood",
        "pulse_agg":      "AGGREGATION_AVERAGE",
        "pulse_time":     "TIME_COMPARISON_TYPE_LAST_COMPLETE_PERIOD",
    },
    {
        "label":          "Redemption Rate",
        "field":          "redemption_rate",
        "agg":            "Average",
        "is_rate":        True,
        "description":    "Percentage of earned points that participants have actually redeemed for rewards.",
        "why_it_matters": "Redemption Rate is the leading indicator — it drops before participation does. When reps stop cashing out their rewards, they're signaling they no longer believe the program is worth their effort. Catching this signal 2–4 weeks early gives BI Worldwide time to intervene before participation craters and the client notices.",
        "singular":       "redemption rate",
        "plural":         "redemption rates",
        "sentiment":      "SentimentTypeUpIsGood",
        "pulse_agg":      "AGGREGATION_AVERAGE",
        "pulse_time":     "TIME_COMPARISON_TYPE_LAST_COMPLETE_PERIOD",
    },
    {
        "label":          "Points Per Rep",
        "field":          "points_per_rep",
        "agg":            "Average",
        "is_rate":        False,
        "description":    "Average points earned per active sales rep per period.",
        "why_it_matters": "Points Per Rep measures how actively reps are chasing program milestones. A decline means reps are clocking in but not pursuing rewards aggressively — a behavioral signal that typically precedes a participation drop by 1–2 weeks. It's the earliest quantitative warning in the system.",
        "singular":       "points per rep",
        "plural":         "points per rep",
        "sentiment":      "SentimentTypeUpIsGood",
        "pulse_agg":      "AGGREGATION_AVERAGE",
        "pulse_time":     "TIME_COMPARISON_TYPE_LAST_COMPLETE_PERIOD",
    },
    {
        "label":          "Active Reps",
        "field":          "active_reps",
        "agg":            "Sum",
        "is_rate":        False,
        "description":    "Total number of sales reps who recorded at least one program activity in the period.",
        "why_it_matters": "Active Reps is the volume baseline. It separates disengagement from headcount changes — if Participation Rate drops but Active Reps holds steady, the problem is motivational. If both drop together, the client may have reduced their sales team, which is a different conversation. Always check this before drawing conclusions from rate metrics.",
        "singular":       "active rep",
        "plural":         "active reps",
        "sentiment":      "SentimentTypeUpIsGood",
        "pulse_agg":      "AGGREGATION_SUM",
        "pulse_time":     "TIME_COMPARISON_TYPE_YEAR_TO_DATE",
    },
]

# ── Demo walkthrough prompts (question + which metric to query for the answer) ─
# "metrics" lists the METRIC_CONFIG labels whose context to include in the brief call.
# The first metric listed is the primary one for the question.
DEMO_PROMPTS = [
    {
        "title":        "Opening",
        "question":     "Show me how participation rates have trended over the last 12 weeks.",
        "alt_question": "What is the current participation rate trend?",
        "metrics":      ["Participation Rate"],
    },
    {
        "title":        "Drill 1 — Program Type",
        "question":     "Which program type has the worst participation rate decline?",
        "alt_question": "How does participation rate compare across program types?",
        "metrics":      ["Participation Rate"],
    },
    {
        "title":        "Reveal — Concentration",
        "question":     "Is every program type declining, or is it concentrated in one?",
        "alt_question": "What is the participation rate for the last 3 months?",
        "metrics":      ["Participation Rate"],
    },
    {
        "title":        "Drill 2 — Region",
        "question":     "For President's Club programs, which region is driving the drop?",
        "alt_question": "What is the participation rate trend across regions?",
        "metrics":      ["Participation Rate"],
    },
    {
        "title":        "Compound — Size Band",
        "question":     "In the Northeast, which client size band is most affected in President's Club?",
        "alt_question": "How does participation rate break down by client size band?",
        "metrics":      ["Participation Rate"],
    },
    {
        "title":        "Counter-trend",
        "question":     "How is the Channel Partner program performing compared to President's Club?",
        "alt_question": "Is participation rate improving in any segment?",
        "metrics":      ["Participation Rate"],
    },
    {
        "title":        "Root Cause",
        "question":     "Is goal achievement also declining in President's Club Northeast Mid-Market?",
        "alt_question": "What is the current goal achievement rate trend?",
        "metrics":      ["Goal Achievement Rate"],
    },
    {
        "title":        "Leading Indicator",
        "question":     "Was there an earlier warning signal before participation started falling?",
        "alt_question": "What is the current redemption rate trend?",
        "metrics":      ["Redemption Rate", "Points Per Rep"],
    },
    {
        "title":        "Action",
        "question":     "Which President's Club clients in the Northeast should we flag for immediate outreach?",
        "alt_question": "Which segments currently have the lowest participation rate?",
        "metrics":      ["Participation Rate", "Goal Achievement Rate"],
    },
]

DIM_DESCRIPTIONS = {
    "vertical":     "Industry vertical of the BI Worldwide client organization (e.g. Financial Services, Automotive, Technology). Use to identify which industries are experiencing the largest incentive program engagement declines.",
    "region":       "US geographic region of the client. West and Northeast show the strongest signal — use this dimension first when drilling into where engagement is falling.",
    "size_band":    "Size tier of the client by number of eligible reps (Small Enterprise, Mid-Market, Large Enterprise, Global). Small Enterprise clients show the earliest and sharpest declines.",
    "program_type": "Type of incentive program the client runs (Sales Contest, Quota Attainment, Channel Partner, President's Club). Use to identify whether the engagement decline is concentrated in specific program structures.",
    "date":         "Date of the incentive program activity record. Use to analyze weekly and monthly trends.",
    "client_id":    "Unique identifier for the BI Worldwide client account. Use to drill into a specific client's program engagement history.",
}

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 2 — TABLEAU PULSE
# ════════════════════════════════════════════════════════════════════════════════
if cp.get("pulse_done"):
    print("\n[SKIP] Pulse already complete.")
else:
    print("\n" + "=" * 70)
    print("PHASE 2 — TABLEAU PULSE")
    print("=" * 70)

    import tableauserverclient as TSC
    import tableauhyperapi as ha

    tc = config["tableau"]
    server, auth_token, site_id = get_tableau_token(config)
    h_rest = tableau_headers(auth_token)
    h_pulse = tableau_pulse_headers(auth_token)
    h_pulse_create = {**h_pulse, "Content-Type": "application/vnd.tableau.metricqueryservice.v1.CreateDefinitionRequest+json"}
    h_pulse_json = {"x-tableau-auth": auth_token, "Accept": "application/json", "Content-Type": "application/json"}
    base_url = tc["server_url"].rstrip("/")
    api_ver = server.version

    # ── Cleanup existing project + group ─────────────────────────────────────
    print("\n  Cleaning up existing BI Worldwide assets...")
    all_projects, _ = server.projects.get()
    for proj in all_projects:
        if proj.name.startswith(f"{COMPANY} |"):
            server.projects.delete(proj.id)
            print(f"    Deleted project: {proj.name}")

    import xml.etree.ElementTree as ET
    ns = {"t": "http://tableau.com/api"}
    grp_resp = requests.get(
        f"{base_url}/api/{api_ver}/sites/{site_id}/groups",
        headers=h_rest,
        params={"pageSize": 100},
    )
    grp_list = grp_resp.json().get("groups", {}).get("group", [])
    for g in grp_list:
        gname = g.get("name", "")
        if gname.startswith(f"{COMPANY} |"):
            gid = g.get("id")
            requests.delete(f"{base_url}/api/{api_ver}/sites/{site_id}/groups/{gid}", headers=h_rest)
            print(f"    Deleted group: {gname}")

    # Cleanup existing Pulse definitions
    def get_all_pulse_definitions():
        defs = []
        npt = ""
        while True:
            params = {"page_size": 100}
            if npt:
                params["page_token"] = npt
            r = requests.get(f"{base_url}/api/-/pulse/definitions", headers=h_pulse, params=params)
            body = r.json()
            defs.extend(body.get("definitions", []))
            npt = body.get("next_page_token", "")
            if not npt:
                break
        return defs

    existing_defs = get_all_pulse_definitions()
    for d in existing_defs:
        if COMPANY.lower() in d.get("name", "").lower() or "incentive" in d.get("name", "").lower() or "participation" in d.get("name", "").lower():
            requests.delete(f"{base_url}/api/-/pulse/definitions/{d['id']}", headers=h_pulse)
            print(f"    Deleted definition: {d['name']}")

    # ── Create timestamped project ────────────────────────────────────────────
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    proj_name = f"{COMPANY} | {ts}"
    new_proj = TSC.ProjectItem(name=proj_name, description="BI Worldwide Sales Incentive Demo")
    new_proj = server.projects.create(new_proj)
    cp["pulse_project_id"]   = new_proj.id
    cp["pulse_project_name"] = proj_name
    save_checkpoint(cp)
    print(f"\n  Created project: {proj_name}")

    # ── Write .hyper and publish ──────────────────────────────────────────────
    hyper_path = os.path.join(DEMO_DIR, f"{SLUG}.hyper")
    print(f"\n  Writing .hyper file...")
    from tableauhyperapi import HyperProcess, Telemetry, Connection, TableDefinition, SqlType, TableName, Inserter, CreateMode

    with HyperProcess(telemetry=Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hyper:
        with Connection(hyper.endpoint, hyper_path, CreateMode.CREATE_AND_REPLACE) as conn:
            table_def = TableDefinition(
                table_name=TableName("Extract", "Extract"),
                columns=[
                    TableDefinition.Column("Record ID",             SqlType.text()),
                    TableDefinition.Column("Client ID",             SqlType.text()),
                    TableDefinition.Column("Client Name",           SqlType.text()),
                    TableDefinition.Column("Date",                  SqlType.date()),
                    TableDefinition.Column("Vertical",              SqlType.text()),
                    TableDefinition.Column("Region",                SqlType.text()),
                    TableDefinition.Column("Size Band",             SqlType.text()),
                    TableDefinition.Column("Program Type",          SqlType.text()),
                    TableDefinition.Column("Participation Rate",    SqlType.double()),
                    TableDefinition.Column("Goal Achievement Rate", SqlType.double()),
                    TableDefinition.Column("Points Per Rep",        SqlType.double()),
                    TableDefinition.Column("Redemption Rate",       SqlType.double()),
                    TableDefinition.Column("Active Reps",           SqlType.big_int()),
                    TableDefinition.Column("Total Eligible Reps",   SqlType.big_int()),
                    TableDefinition.Column("Points Total",          SqlType.big_int()),
                ]
            )
            conn.catalog.create_schema_if_not_exists("Extract")
            conn.catalog.create_table_if_not_exists(table_def)
            with Inserter(conn, table_def) as ins:
                for _, row in df.iterrows():
                    ins.add_row([
                        row["Record ID"], row["Client ID"], row["Client Name"],
                        ha.Date(*[int(x) for x in row["Date"].split("-")]),
                        row["Vertical"], row["Region"], row["Size Band"], row["Program Type"],
                        float(row["Participation Rate"]),
                        float(row["Goal Achievement Rate"]),
                        float(row["Points Per Rep"]),
                        float(row["Redemption Rate"]),
                        int(row["Active Reps"]),
                        int(row["Total Eligible Reps"]),
                        int(row["Points Total"]),
                    ])
                ins.execute()
    print(f"  .hyper written: {hyper_path}")

    ds_item = TSC.DatasourceItem(project_id=new_proj.id, name=f"{COMPANY} - Sales Incentive")
    ds_item = server.datasources.publish(ds_item, hyper_path, "Overwrite")
    cp["pulse_datasource_id"]   = ds_item.id
    cp["pulse_datasource_name"] = ds_item.name
    save_checkpoint(cp)
    print(f"  Published datasource: {ds_item.name} (id={ds_item.id})")

    # ── Create Pulse metric definitions ───────────────────────────────────────
    print("\n  Creating Pulse metric definitions...")
    metric_ids = []
    def_ids = []
    for mc in METRIC_CONFIG:
        payload = {
            "name": f"{COMPANY} — {mc['label']}",
            "specification": {
                "datasource": {"id": ds_item.id},
                "basic_specification": {
                    "measure": {"field": mc["label"], "aggregation": mc["pulse_agg"]},
                    "time_dimension": {"field": "Date"},
                    "filters": [],
                },
                "is_running_total": False,
            },
            "representation_options": {
                "type": "NUMBER_FORMAT_TYPE_NUMBER",
                "number_units": {
                    "singular_noun": mc["singular"],
                    "plural_noun":   mc["plural"],
                },
                "sentiment_type": "SENTIMENT_TYPE_UP_IS_GOOD",
            },
            "extension_options": {
                "allowed_dimensions": ["Vertical", "Region", "Size Band", "Program Type"],
                "allowed_granularities": [
                    "GRANULARITY_BY_WEEK",
                    "GRANULARITY_BY_MONTH",
                    "GRANULARITY_BY_QUARTER",
                    "GRANULARITY_BY_YEAR",
                ],
                "offset_from_today": 1,
                "correlation_candidate_definition_ids": [],
                "use_dynamic_offset": False,
            },
            "insights_options": {"show_insights": True},
            "comparisons": {"comparisons": [{"compare_config": {"comparison": "TIME_COMPARISON_PREVIOUS_PERIOD"}, "index": 0}]},
            "certification": {"is_certified": False},
            "datasource_goals": [],
            "related_links": [],
        }
        r = requests.post(f"{base_url}/api/-/pulse/definitions", headers=h_pulse_create, json=payload)
        if r.status_code not in (200, 201):
            print(f"    ERROR creating {mc['label']}: {r.status_code} {r.text[:200]}")
            continue
        resp_body = r.json()
        def_id = resp_body.get("definition", {}).get("metadata", {}).get("id")

        # Fetch metric ID (NOT definition ID)
        time.sleep(1)
        r2 = requests.get(f"{base_url}/api/-/pulse/definitions/{def_id}/metrics", headers=h_pulse)
        metrics_list = r2.json().get("metrics", [])
        if not metrics_list:
            print(f"    WARNING: no metric found for definition {def_id}")
            continue
        metric_id = metrics_list[0]["id"]
        metric_ids.append(metric_id)
        def_ids.append(def_id)
        print(f"    Created: {mc['label']} (def={def_id}, metric={metric_id})")

    cp["pulse_metric_ids"]  = metric_ids
    cp["pulse_def_ids"]     = def_ids
    cp["pulse_def_name_ts"] = proj_name
    save_checkpoint(cp)

    # ── Create group + subscribe ───────────────────────────────────────────────
    print(f"\n  Creating group: {proj_name}")
    grp_payload = f"""<?xml version='1.0' encoding='UTF-8'?>
<tsRequest><group name="{proj_name}"/></tsRequest>"""
    grp_resp = requests.post(
        f"{base_url}/api/{api_ver}/sites/{site_id}/groups",
        headers={**h_rest, "Content-Type": "application/xml"},
        data=grp_payload.encode("utf-8"),
    )
    if grp_resp.status_code not in (200, 201):
        raise RuntimeError(f"Group creation failed: {grp_resp.status_code} {grp_resp.text[:300]}")
    grp_body = grp_resp.json()
    group_id = grp_body.get("group", {}).get("id")
    if not group_id:
        raise RuntimeError(f"Group ID is None after creation: {grp_resp.text[:300]}")
    print(f"  Group created: {group_id}")
    cp["pulse_group_id"] = group_id
    save_checkpoint(cp)

    # Subscribe group to each metric
    print(f"\n  Subscribing group to {len(metric_ids)} metrics...")
    for metric_id in metric_ids:
        sub_payload = {"metric_id": metric_id, "followers": [{"group_id": group_id}]}
        r = requests.post(f"{base_url}/api/-/pulse/subscriptions:batchCreate", headers=h_pulse_json, json=sub_payload)
        if r.status_code in (200, 201):
            print(f"    Subscribed metric {metric_id}")
        else:
            print(f"    WARNING: batchCreate for metric {metric_id}: {r.status_code} {r.text[:150]}")

    server.auth.sign_out()
    cp["pulse_done"] = True
    save_checkpoint(cp)
    print("\n  Pulse phase complete.")

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 3 — DATA CLOUD: SCHEMA + STREAMS
# ════════════════════════════════════════════════════════════════════════════════
SCHEMA_NAME  = "bi_worldwide_incentive_fact"
SCHEMA_LABEL = "bi_worldwide_incentive_fact"

if cp.get("streams_done"):
    print("\n[SKIP] Streams already registered.")
else:
    print("\n" + "=" * 70)
    print("PHASE 3 — DATA CLOUD: SCHEMA + STREAMS")
    print("=" * 70)

    sf_token, sf_instance, dc_token, dc_domain = get_all_tokens(config)
    sf_h = {"Authorization": f"Bearer {sf_token}", "Content-Type": "application/json"}

    connector_id    = config["salesforce"]["connector_sf_id"]
    connector_name  = config["salesforce"]["ingestion_connector_name"]
    connector_uuid  = config["salesforce"]["connector_uuid_name"]

    # ── Register schema ───────────────────────────────────────────────────────
    print(f"\n  Registering schema: {SCHEMA_NAME}")
    r = requests.get(
        f"{sf_instance}/services/data/v62.0/ssot/connections/{connector_id}/schema",
        headers=sf_h
    )
    existing_schemas = r.json().get("schemas", []) if r.status_code == 200 else []
    existing_names = [s["name"] for s in existing_schemas]

    new_schema = {
        "name":       SCHEMA_NAME,
        "label":      SCHEMA_LABEL,
        "schemaType": "IngestApi",
        "fields": [
            {"name": "record_id",             "label": "Record ID",             "dataType": "Text"},
            {"name": "client_id",             "label": "Client ID",             "dataType": "Text"},
            {"name": "client_name",           "label": "Client Name",           "dataType": "Text"},
            {"name": "date",                  "label": "Date",                  "dataType": "Date"},
            {"name": "vertical",              "label": "Vertical",              "dataType": "Text"},
            {"name": "region",                "label": "Region",                "dataType": "Text"},
            {"name": "size_band",             "label": "Size Band",             "dataType": "Text"},
            {"name": "program_type",          "label": "Program Type",          "dataType": "Text"},
            {"name": "participation_rate",    "label": "Participation Rate",    "dataType": "Number"},
            {"name": "goal_achievement_rate", "label": "Goal Achievement Rate", "dataType": "Number"},
            {"name": "points_per_rep",        "label": "Points Per Rep",        "dataType": "Number"},
            {"name": "redemption_rate",       "label": "Redemption Rate",       "dataType": "Number"},
            {"name": "active_reps",           "label": "Active Reps",           "dataType": "Number"},
            {"name": "total_eligible_reps",   "label": "Total Eligible Reps",   "dataType": "Number"},
            {"name": "points_total",          "label": "Points Total",          "dataType": "Number"},
        ]
    }

    # Strip read-only fields from existing schemas before PUT
    STRIP_FIELDS = {"availabilityStatus", "createdDate", "lastModifiedDate"}
    def clean_schema(s):
        return {k: v for k, v in s.items() if k not in STRIP_FIELDS}

    if SCHEMA_NAME in existing_names:
        merged = [clean_schema(s) if s["name"] != SCHEMA_NAME else new_schema for s in existing_schemas]
    else:
        merged = [clean_schema(s) for s in existing_schemas] + [new_schema]

    r = requests.put(
        f"{sf_instance}/services/data/v62.0/ssot/connections/{connector_id}/schema",
        headers=sf_h,
        json={"schemas": merged}
    )
    if r.status_code not in (200, 201, 204):
        raise RuntimeError(f"Schema PUT failed: {r.status_code} {r.text[:300]}")
    print(f"  Schema registered. Waiting 20s for propagation...")
    time.sleep(20)

    # ── Create data stream ────────────────────────────────────────────────────
    print(f"  Creating data stream: {SCHEMA_NAME}")
    stream_payload = {
        "name":            SCHEMA_NAME,
        "label":           SCHEMA_NAME,
        "datasource":      connector_name[:10],
        "datastreamType":  "INGESTAPI",
        "connectorInfo": {
            "connectorType":    "IngestApi",
            "connectorDetails": {"name": connector_uuid, "events": [SCHEMA_NAME]},
        },
        "dataLakeObjectInfo": {
            "label":    SCHEMA_NAME,
            "category": "Other",
            "dataspaceInfo": [{"name": "default"}],
            "dataLakeFieldInputRepresentations": [
                {"name": "record_id", "label": "record_id", "dataType": "Text", "isPrimaryKey": True}
            ],
            "eventDateTimeFieldName":   "",
            "recordModifiedFieldName":  "",
        },
        "mappings": [],
    }
    r = requests.post(
        f"{sf_instance}/services/data/v62.0/ssot/data-streams",
        headers=sf_h,
        json=stream_payload
    )
    if r.status_code not in (200, 201):
        if "already in use" in r.text.lower() or "already exists" in r.text.lower():
            print(f"  Stream already exists — discovering stream name...")
            r2 = requests.get(f"{sf_instance}/services/data/v62.0/ssot/data-streams", headers=sf_h,
                              params={"connectorId": connector_id, "limit": 200})
            stream_name = None
            for ds_item in r2.json().get("dataStreams", []):
                if SCHEMA_NAME.lower() in ds_item.get("name", "").lower():
                    stream_name = ds_item["name"]
                    print(f"  Found existing stream: {stream_name}")
                    break
            if not stream_name:
                raise RuntimeError(f"Stream exists but could not be found")
            # Get DLO name from stream details
            r3 = requests.get(f"{sf_instance}/services/data/v62.0/ssot/data-streams/{stream_name}", headers=sf_h)
            b3 = r3.json()
            if isinstance(b3, list): b3 = b3[0]
            dlo_name = b3.get("dataLakeObjectInfo", {}).get("name")
            if not dlo_name:
                raise RuntimeError(f"Could not find DLO name for stream {stream_name}")
        else:
            raise RuntimeError(f"Stream creation failed: {r.status_code} {r.text[:300]}")
    else:
        stream_body = r.json()
        dlo_name = stream_body.get("dataLakeObjectInfo", {}).get("name") or stream_body.get("name")
    print(f"  Stream created. DLO name: {dlo_name}")
    cp["dlo_name"] = dlo_name
    save_checkpoint(cp)

    # ── Poll for ACTIVE ────────────────────────────────────────────────────────
    dlo_name = cp["dlo_name"]
    print(f"  Polling DLO status for {dlo_name}...")
    for attempt in range(30):
        time.sleep(10)
        r = requests.get(
            f"{sf_instance}/services/data/v62.0/ssot/data-streams/{dlo_name}",
            headers=sf_h
        )
        body = r.json()
        if isinstance(body, list):
            body = body[0] if body else {}
        status = body.get("dataLakeObjectInfo", {}).get("status") or body.get("status", "UNKNOWN")
        print(f"    [{attempt+1}] status = {status}")
        if status == "ACTIVE":
            break
    else:
        raise RuntimeError("DLO did not become ACTIVE in time")

    print("  DLO ACTIVE. Waiting additional 30s for bulk API propagation...")
    time.sleep(30)
    cp["streams_done"] = True
    save_checkpoint(cp)

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 4 — BULK INGEST
# ════════════════════════════════════════════════════════════════════════════════
if cp.get("ingest_done"):
    print("\n[SKIP] Bulk ingest already complete.")
else:
    print("\n" + "=" * 70)
    print("PHASE 4 — BULK INGEST")
    print("=" * 70)

    sf_token, sf_instance, dc_token, dc_domain = get_all_tokens(config)
    dc_h = {"Authorization": f"Bearer {dc_token}", "Content-Type": "application/json"}
    ingest_base = f"https://{dc_domain}/api/v1/ingest"

    # Rename df columns to match schema field names
    df_dc = df.rename(columns={
        "Record ID":            "record_id",
        "Client ID":            "client_id",
        "Client Name":          "client_name",
        "Date":                 "date",
        "Vertical":             "vertical",
        "Region":               "region",
        "Size Band":            "size_band",
        "Program Type":         "program_type",
        "Participation Rate":   "participation_rate",
        "Goal Achievement Rate":"goal_achievement_rate",
        "Points Per Rep":       "points_per_rep",
        "Redemption Rate":      "redemption_rate",
        "Active Reps":          "active_reps",
        "Total Eligible Reps":  "total_eligible_reps",
        "Points Total":         "points_total",
    })

    # Submit ingest job
    job_payload = {
        "object":     SCHEMA_NAME,
        "operation":  "upsert",
        "sourceName": config["salesforce"]["ingestion_connector_name"],
    }
    print(f"  Submitting ingest job for {SCHEMA_NAME} ({len(df_dc):,} rows)...")
    r = requests.post(f"{ingest_base}/jobs", headers=dc_h, json=job_payload)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Job creation failed: {r.status_code} {r.text[:300]}")
    job_id = r.json()["id"]
    print(f"  Job created: {job_id}")
    cp["ingest_job_id"] = job_id
    save_checkpoint(cp)

    # Upload CSV batches (500 rows each)
    BATCH_SIZE = 500
    csv_headers = list(df_dc.columns)
    total_batches = math.ceil(len(df_dc) / BATCH_SIZE)
    print(f"  Uploading {total_batches} batches of {BATCH_SIZE} rows...")
    for i in range(total_batches):
        batch = df_dc.iloc[i*BATCH_SIZE:(i+1)*BATCH_SIZE]
        lines = [",".join(str(v) for v in batch.columns)]
        for _, row in batch.iterrows():
            lines.append(",".join(str(v) for v in row))
        csv_body = "\n".join(lines)
        r = requests.put(
            f"{ingest_base}/jobs/{job_id}/batches",
            headers={**dc_h, "Content-Type": "text/csv"},
            data=csv_body.encode("utf-8"),
        )
        if r.status_code not in (200, 201, 202, 204):
            print(f"    Batch {i+1} warning: {r.status_code} {r.text[:100]}")
        else:
            print(f"    Batch {i+1}/{total_batches} uploaded")

    # Close job
    r = requests.patch(
        f"{ingest_base}/jobs/{job_id}",
        headers=dc_h,
        json={"state": "UploadComplete"}
    )
    if r.status_code not in (200, 201, 202, 204):
        raise RuntimeError(f"Job close failed: {r.status_code} {r.text[:200]}")
    print(f"  Job closed. Polling for completion...")

    # Poll
    for attempt in range(60):
        time.sleep(10)
        r = requests.get(f"{ingest_base}/jobs/{job_id}", headers=dc_h)
        state = r.json().get("state", "UNKNOWN")
        print(f"    [{attempt+1}] state = {state}")
        if state == "JobComplete":
            break
        if state == "Failed":
            raise RuntimeError(f"Ingest job failed: {r.text[:300]}")
    else:
        raise RuntimeError("Ingest job did not complete in time")

    cp["ingest_done"] = True
    save_checkpoint(cp)
    print("  Bulk ingest complete.")

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 5 — WORKSPACE + SEMANTIC DATA MODEL
# ════════════════════════════════════════════════════════════════════════════════
if cp.get("sdm_done"):
    print("\n[SKIP] Workspace + SDM already complete.")
    sf_token, sf_instance, dc_token, dc_domain = get_all_tokens(config)
    sf_h = {"Authorization": f"Bearer {sf_token}", "Content-Type": "application/json"}
    ws_api  = cp["ws_api"]
    sdm_api = cp["sdm_api"]
    do_api  = cp["do_api"]
else:
    print("\n" + "=" * 70)
    print("PHASE 5 — WORKSPACE + SEMANTIC DATA MODEL")
    print("=" * 70)

    sf_token, sf_instance, dc_token, dc_domain = get_all_tokens(config)
    sf_h = {"Authorization": f"Bearer {sf_token}", "Content-Type": "application/json"}

    # Cleanup prior workspace/SDM assets
    for ws in cp.get("all_ws_apis", []):
        requests.delete(f"{sf_instance}/services/data/v65.0/tableau/workspaces/{ws}", headers=sf_h)
        print(f"  Deleted workspace: {ws}")
    for sdm in cp.get("all_sdm_apis", []):
        requests.delete(f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm}", headers=sf_h)
        print(f"  Deleted SDM: {sdm}")
    cp["all_ws_apis"]  = []
    cp["all_sdm_apis"] = []
    cp.pop("ws_api",  None)
    cp.pop("sdm_api", None)
    cp.pop("do_api",  None)
    save_checkpoint(cp)

    # Create workspace
    ts_slug = datetime.now().strftime("%Y%m%d_%H%M")
    ws_label = f"BI Worldwide Sales Incentive {ts_slug}"
    r = requests.post(
        f"{sf_instance}/services/data/v65.0/tableau/workspaces",
        headers=sf_h,
        json={"label": ws_label, "description": "BI Worldwide Sales Incentive demo workspace"}
    )
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Workspace creation failed: {r.status_code} {r.text[:300]}")
    ws_api = r.json().get("apiName") or r.json().get("name")
    cp["ws_api"] = ws_api
    cp["all_ws_apis"].append(ws_api)
    save_checkpoint(cp)
    print(f"  Workspace created: {ws_api}")

    # Create SDM
    r = requests.post(
        f"{sf_instance}/services/data/v65.0/ssot/semantic/models",
        headers=sf_h,
        json={
            "label":        "BI Worldwide Sales Incentive",
            "dataspace":    "default",
            "agentEnabled": True,
        }
    )
    if r.status_code not in (200, 201):
        raise RuntimeError(f"SDM creation failed: {r.status_code} {r.text[:300]}")
    sdm_api = r.json()["apiName"]
    cp["sdm_api"] = sdm_api
    cp["all_sdm_apis"].append(sdm_api)
    save_checkpoint(cp)
    print(f"  SDM created: {sdm_api}")

    # Add DLO to SDM
    dlo_name = cp["dlo_name"]
    r = requests.post(
        f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects",
        headers=sf_h,
        json={
            "dataLakeObjectName": dlo_name,
            "dataObjectName":     dlo_name,
            "dataObjectType":     "dlo",
            "label":              "Incentive Fact",
        }
    )
    if r.status_code not in (200, 201):
        raise RuntimeError(f"DO creation failed: {r.status_code} {r.text[:300]}")
    do_api = r.json()["apiName"]
    cp["do_api"] = do_api
    save_checkpoint(cp)
    print(f"  Data Object added: {do_api}")
    time.sleep(5)

    cp["sdm_done"] = True
    save_checkpoint(cp)

# ── Fetch DO fields ────────────────────────────────────────────────────────────
print(f"\n  Fetching DO field map...")
r = requests.get(
    f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects/{do_api}",
    headers=sf_h
)
do_body = r.json()
raw_measurements = do_body.get("semanticMeasurements", [])
raw_dimensions   = do_body.get("semanticDimensions", [])

# Build measurement map: field_base_name → {apiName, dataObjectFieldName}
meas_map = {}
for m in raw_measurements:
    field_name = m.get("dataObjectFieldName", "")
    base = field_name.replace("__c", "")
    meas_map[base] = {"apiName": m["apiName"], "dataObjectFieldName": field_name}

# Build dimension map: base_field_name → apiName
dim_field_map = {}
for d in raw_dimensions:
    field_name = d.get("dataObjectFieldName", "")
    base = field_name.replace("__c", "")
    dim_field_map[base] = d["apiName"]

print(f"  Measurements found: {list(meas_map.keys())}")
print(f"  Dimensions found:   {list(dim_field_map.keys())}")

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 6 — MEASUREMENTS + FIELD DESCRIPTIONS
# ════════════════════════════════════════════════════════════════════════════════
if cp.get("measurements_done"):
    print("\n[SKIP] Measurements already configured.")
else:
    print("\n" + "=" * 70)
    print("PHASE 6 — MEASUREMENTS + DESCRIPTIONS")
    print("=" * 70)

    for mc in METRIC_CONFIG:
        field = mc["field"]
        if field not in meas_map:
            print(f"  WARNING: field '{field}' not in measurement map, skipping")
            continue
        m_api   = meas_map[field]["apiName"]
        m_field = meas_map[field]["dataObjectFieldName"]
        r = requests.put(
            f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects/{do_api}/measurements/{m_api}",
            headers=sf_h,
            json={
                "apiName":             m_api,
                "label":               mc["label"],
                "dataObjectFieldName": m_field,
                "aggregationType":     mc["agg"],
                "description":         mc["description"],
            }
        )
        if r.status_code not in (200, 201, 204):
            print(f"  ERROR setting measurement {mc['label']}: {r.status_code} {r.text[:200]}")
        else:
            print(f"  Measurement configured: {mc['label']} ({mc['agg']})")

    # PUT dimension descriptions
    for field_base, dim_api in dim_field_map.items():
        desc = DIM_DESCRIPTIONS.get(field_base)
        if not desc:
            continue
        field_dc = field_base + "__c"
        label = field_base.replace("_", " ").title()
        r = requests.put(
            f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects/{do_api}/dimensions/{dim_api}",
            headers=sf_h,
            json={
                "apiName":             dim_api,
                "label":               label,
                "dataObjectFieldName": field_dc,
                "description":         desc,
            }
        )
        if r.status_code not in (200, 201, 204):
            print(f"  WARNING dim description PUT {field_base}: {r.status_code} {r.text[:150]}")
        else:
            print(f"  Dimension described: {label}")

    cp["measurements_done"] = True
    save_checkpoint(cp)

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 7 — CALCULATED MEASUREMENTS + METRICS
# ════════════════════════════════════════════════════════════════════════════════
if cp.get("metrics_done"):
    print("\n[SKIP] Metrics already created.")
    # reload metric apiNames
    r = requests.get(
        f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/metrics",
        headers=sf_h
    )
    created_metrics = {item["label"]: item["apiName"] for item in r.json().get("items", [])}
else:
    print("\n" + "=" * 70)
    print("PHASE 7 — CALCULATED MEASUREMENTS + METRICS")
    print("=" * 70)

    # Find date dimension apiName
    date_dim_api = dim_field_map.get("date", "date")

    created_metrics = {}
    for mc in METRIC_CONFIG:
        field = mc["field"]
        if field not in meas_map:
            print(f"  WARNING: skipping metric for missing field '{field}'")
            continue
        m_api = meas_map[field]["apiName"]

        # Create CLC
        clc_api   = f"{field}_clc"
        clc_label = f"{mc['label']} Calc"
        clc_expr  = f"AVG([{do_api}].[{m_api}])" if mc["agg"] == "Average" else f"SUM([{do_api}].[{m_api}])"
        r = requests.post(
            f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/calculated-measurements",
            headers=sf_h,
            json={
                "apiName":            clc_api,
                "label":              clc_label,
                "aggregationType":    "UserAgg",
                "dataType":           "Number",
                "decimalPlace":       4,
                "directionality":     "Up",
                "displayCategory":    "Continuous",
                "expression":         clc_expr,
                "filters":            [],
                "isOverrideBase":     False,
                "isVisible":          True,
                "level":              "AggregateFunction",
                "overriddenProperties": [],
                "semanticDataType":   "None",
            }
        )
        if r.status_code not in (200, 201):
            print(f"  ERROR creating CLC for {mc['label']}: {r.status_code} {r.text[:200]}")
            continue
        clc_api_resp = r.json()["apiName"]
        print(f"  CLC created: {clc_api_resp}")

        # Dimension references — drives "why" drilldowns in Concierge and Tableau Next
        dim_refs = [
            {"tableFieldReference": {"fieldApiName": dim_field_map.get("region",       "region"),       "tableApiName": do_api}},
            {"tableFieldReference": {"fieldApiName": dim_field_map.get("vertical",     "vertical"),     "tableApiName": do_api}},
            {"tableFieldReference": {"fieldApiName": dim_field_map.get("size_band",    "size_band"),    "tableApiName": do_api}},
            {"tableFieldReference": {"fieldApiName": dim_field_map.get("program_type", "program_type"), "tableApiName": do_api}},
        ]

        # Create metric
        mtc_label = mc["label"]
        r = requests.post(
            f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/metrics",
            headers=sf_h,
            json={
                "label":           mtc_label,
                "aggregationType": "UserAgg",
                "measurementReference": {
                    "calculatedFieldApiName": clc_api_resp
                },
                "timeDimensionReference": {
                    "tableFieldReference": {
                        "fieldApiName": date_dim_api,
                        "tableApiName": do_api,
                    }
                },
                "timeGrains": ["Week", "Month", "Quarter", "Year"],
                "additionalDimensions": dim_refs,
                "insightsSettings": {
                    "singularNoun": mc["singular"],
                    "pluralNoun":   mc["plural"],
                    "sentiment":    mc["sentiment"],
                    "insightsDimensionsReferences": dim_refs,
                },
            }
        )
        if r.status_code not in (200, 201):
            print(f"  ERROR creating metric {mtc_label}: {r.status_code} {r.text[:200]}")
            continue
        mtc_api = r.json()["apiName"]
        created_metrics[mtc_label] = mtc_api
        print(f"  Metric created: {mtc_label} → {mtc_api}")

    cp["metrics_done"]    = True
    cp["created_metrics"] = created_metrics
    save_checkpoint(cp)

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 8 — VISUALIZATIONS + DASHBOARD
# ════════════════════════════════════════════════════════════════════════════════
if cp.get("dashboard_done"):
    print("\n[SKIP] Dashboard already complete.")
else:
    print("\n" + "=" * 70)
    print("PHASE 8 — VISUALIZATIONS + DASHBOARD")
    print("=" * 70)

    # Cleanup prior vizzes + dashboards
    for v in cp.get("all_viz_apis", []):
        requests.delete(f"{sf_instance}/services/data/v66.0/tableau/visualizations/{v}?minorVersion=12", headers=sf_h)
        print(f"  Deleted viz: {v}")
    for d in cp.get("all_dash_apis", []):
        requests.delete(f"{sf_instance}/services/data/v66.0/tableau/dashboards/{d}", headers=sf_h)
        print(f"  Deleted dashboard: {d}")
    cp["all_viz_apis"]  = []
    cp["all_dash_apis"] = []
    save_checkpoint(cp)

    DASH_BG  = "#F3F3F3"
    CHART_BG = "#FFFFFF"
    TEXT_COL = "#2E2E2E"

    FONTS = {
        "actionableHeaders": {"color": TEXT_COL, "size": 13},
        "axisTickLabels":    {"color": TEXT_COL, "size": 13},
        "fieldLabels":       {"color": TEXT_COL, "size": 13},
        "headers":           {"color": TEXT_COL, "size": 13},
        "legendLabels":      {"color": TEXT_COL, "size": 13},
        "markLabels":        {"color": TEXT_COL, "size": 13},
        "marks":             {"color": TEXT_COL, "size": 13},
    }
    LINES = {
        "axisLine":              {"color": "#C9C9C9"},
        "fieldLabelDividerLine": {"color": "#C9C9C9"},
        "separatorLine":         {"color": "#C9C9C9"},
        "zeroLine":              {"color": "#C9C9C9"},
    }

    def _style_number(fkey, dp=2, pct=False):
        return {fkey: {"defaults": {"format": {"numberFormatInfo": {
            "decimalPlaces": dp, "displayUnits": "Auto",
            "includeThousandSeparator": not pct,
            "negativeValuesFormat": "Auto",
            "prefix": "", "suffix": "%" if pct else "", "type": "Number",
        }}}}}

    def _marks_headers_style():
        return {
            "color": {"color": ""}, "isAutomaticSize": True,
            "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
            "range": {"reverse": False},
            "size": {"isAutomatic": True, "type": "Pixel", "value": 13},
        }

    def _vizql_mark_headers():
        return {
            "encodings": [], "isAutomatic": True,
            "stack": {"isAutomatic": True, "isStacked": False}, "type": "Text",
        }

    VIZ_BASE   = f"{sf_instance}/services/data/v66.0"
    VIZ_PARAMS = {"minorVersion": "12"}

    def make_viz(name, label, fields_dict, vis_spec):
        payload = {
            "name": name, "label": label,
            "dataSource": {"name": sdm_api, "label": "BI Worldwide Sales Incentive", "type": "SemanticModel"},
            "workspace":  {"name": ws_api,  "label": ws_api},
            "interactions": [],
            "fields": fields_dict,
            "visualSpecification": vis_spec,
            "view": {
                "label": "default", "name": f"{name}_default",
                "viewSpecification": {"sortOrders": {"columns": [], "fields": {}, "rows": []}}
            }
        }
        r = requests.post(f"{VIZ_BASE}/tableau/visualizations", headers=sf_h, params=VIZ_PARAMS, json=payload)
        if r.status_code in (200, 201):
            viz_name = r.json().get("name", name)
            print(f"  Viz created: {label} → {viz_name}")
            cp["all_viz_apis"].append(viz_name)
            save_checkpoint(cp)
            return viz_name
        print(f"  ERROR creating viz '{label}': {r.status_code} {r.text[:250]}")
        return None

    OBJ = do_api
    FM  = dim_field_map
    MM  = meas_map

    # Viz 1 — Participation Rate trend over time
    viz1 = make_viz(
        "BIW_Participation_Rate_Trend", "Participation Rate by Week",
        fields_dict={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("date", "date"), "function": "DatePartWeek"},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": MM.get("participation_rate", {}).get("apiName", "participation_rate"), "function": "Avg"},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {},
            "marks": {
                "fields": {}, "headers": _vizql_mark_headers(),
                "panes": {"encodings": [], "isAutomatic": False, "type": "Line",
                          "stack": {"isAutomatic": True, "isStacked": False}}
            },
            "style": {
                "axis": {"fields": {"F2": {
                    "isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": False, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 1, "displayUnits": "Auto",
                        "includeThousandSeparator": False, "negativeValuesFormat": "Auto",
                        "prefix": "", "suffix": "%", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}
                }}},
                "encodings": {"fields": _style_number("F2", dp=1, pct=True)},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                "rows":    {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {
                    "columns": {"mergeRepeatedCells": True, "showIndex": False},
                    "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                    "rows": {"mergeRepeatedCells": True, "showIndex": False}
                },
                "lines": LINES,
                "marks": {
                    "fields": {}, "headers": _marks_headers_style(),
                    "panes": {"color": {"color": ""}, "isAutomaticSize": False,
                              "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                              "range": {"reverse": False},
                              "size": {"isAutomatic": False, "type": "Pixel", "value": 3}}
                },
                "referenceLines": {},
                "shading": {"backgroundColor": CHART_BG, "banding": {}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        }
    )

    # Viz 2 — Goal Achievement Rate trend over time
    viz2 = make_viz(
        "BIW_Goal_Achievement_Trend", "Goal Achievement Rate by Week",
        fields_dict={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("date", "date"), "function": "DatePartWeek"},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": MM.get("goal_achievement_rate", {}).get("apiName", "goal_achievement_rate"), "function": "Avg"},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {},
            "marks": {
                "fields": {}, "headers": _vizql_mark_headers(),
                "panes": {"encodings": [], "isAutomatic": False, "type": "Line",
                          "stack": {"isAutomatic": True, "isStacked": False}}
            },
            "style": {
                "axis": {"fields": {"F2": {
                    "isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": False, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 1, "displayUnits": "Auto",
                        "includeThousandSeparator": False, "negativeValuesFormat": "Auto",
                        "prefix": "", "suffix": "%", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}
                }}},
                "encodings": {"fields": _style_number("F2", dp=1, pct=True)},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                "rows":    {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {
                    "columns": {"mergeRepeatedCells": True, "showIndex": False},
                    "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                    "rows": {"mergeRepeatedCells": True, "showIndex": False}
                },
                "lines": LINES,
                "marks": {
                    "fields": {}, "headers": _marks_headers_style(),
                    "panes": {"color": {"color": ""}, "isAutomaticSize": False,
                              "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                              "range": {"reverse": False},
                              "size": {"isAutomatic": False, "type": "Pixel", "value": 3}}
                },
                "referenceLines": {},
                "shading": {"backgroundColor": CHART_BG, "banding": {}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        }
    )

    # Viz 3 — Redemption Rate by Region (bar)
    viz3 = make_viz(
        "BIW_Redemption_by_Region", "Redemption Rate by Region",
        fields_dict={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("region", "region")},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": MM.get("redemption_rate", {}).get("apiName", "redemption_rate"), "function": "Avg"},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {},
            "marks": {
                "fields": {}, "headers": _vizql_mark_headers(),
                "panes": {"encodings": [], "isAutomatic": False, "type": "Bar",
                          "stack": {"isAutomatic": True, "isStacked": False}}
            },
            "style": {
                "axis": {"fields": {"F2": {
                    "isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": True, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 1, "displayUnits": "Auto",
                        "includeThousandSeparator": False, "negativeValuesFormat": "Auto",
                        "prefix": "", "suffix": "%", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}
                }}},
                "encodings": {"fields": _style_number("F2", dp=1, pct=True)},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                "rows":    {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {
                    "columns": {"mergeRepeatedCells": True, "showIndex": False},
                    "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                    "rows": {"mergeRepeatedCells": True, "showIndex": False}
                },
                "lines": LINES,
                "marks": {
                    "fields": {}, "headers": _marks_headers_style(),
                    "panes": {"color": {"color": ""}, "isAutomaticSize": True,
                              "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                              "range": {"reverse": False},
                              "size": {"isAutomatic": True, "type": "Percentage", "value": 75}}
                },
                "referenceLines": {},
                "shading": {"backgroundColor": CHART_BG, "banding": {}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        }
    )

    # Viz 4 — Points Per Rep by Vertical (bar)
    viz4 = make_viz(
        "BIW_Points_by_Vertical", "Points Per Rep by Vertical",
        fields_dict={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("vertical", "vertical")},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": MM.get("points_per_rep", {}).get("apiName", "points_per_rep"), "function": "Avg"},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {},
            "marks": {
                "fields": {}, "headers": _vizql_mark_headers(),
                "panes": {"encodings": [], "isAutomatic": False, "type": "Bar",
                          "stack": {"isAutomatic": True, "isStacked": False}}
            },
            "style": {
                "axis": {"fields": {"F2": {
                    "isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": True, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 0, "displayUnits": "Auto",
                        "includeThousandSeparator": True, "negativeValuesFormat": "Auto",
                        "prefix": "", "suffix": "", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}
                }}},
                "encodings": {"fields": _style_number("F2", dp=0)},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                "rows":    {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {
                    "columns": {"mergeRepeatedCells": True, "showIndex": False},
                    "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                    "rows": {"mergeRepeatedCells": True, "showIndex": False}
                },
                "lines": LINES,
                "marks": {
                    "fields": {}, "headers": _marks_headers_style(),
                    "panes": {"color": {"color": ""}, "isAutomaticSize": True,
                              "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                              "range": {"reverse": False},
                              "size": {"isAutomatic": True, "type": "Percentage", "value": 75}}
                },
                "referenceLines": {},
                "shading": {"backgroundColor": CHART_BG, "banding": {}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        }
    )

    cp["viz_apis"] = [v for v in [viz1, viz2, viz3, viz4] if v]
    save_checkpoint(cp)

    # ── Dashboard ─────────────────────────────────────────────────────────────
    print(f"\n  Creating dashboard...")

    mtc_participation = cp.get("created_metrics", {}).get("Participation Rate", "")
    mtc_goal          = cp.get("created_metrics", {}).get("Goal Achievement Rate", "")

    COL_COUNT = 72
    widgets   = {}
    page_widgets = []
    row = 0

    # Metric widgets
    if mtc_participation:
        widgets["w_mtc_part"] = {
            "name": "w_mtc_part", "type": "metric",
            "source": {"name": mtc_participation},
            "parameters": {"metricOption": {"sdmApiName": sdm_api}},
            "actions": [],
        }
        page_widgets.append({"name": "w_mtc_part", "row": row, "column": 0, "rowspan": 15, "colspan": 36})
    if mtc_goal:
        widgets["w_mtc_goal"] = {
            "name": "w_mtc_goal", "type": "metric",
            "source": {"name": mtc_goal},
            "parameters": {"metricOption": {"sdmApiName": sdm_api}},
            "actions": [],
        }
        page_widgets.append({"name": "w_mtc_goal", "row": row, "column": 36, "rowspan": 15, "colspan": 36})

    row = 15
    viz_list = [v for v in [viz1, viz2, viz3, viz4] if v]
    col = 0
    for i, v_api in enumerate(viz_list):
        wk = f"w_viz_{i}"
        widgets[wk] = {
            "name": wk, "type": "visualization",
            "source": {"name": v_api},
            "parameters": {}, "actions": [],
        }
        page_widgets.append({"name": wk, "row": row, "column": col, "rowspan": 20, "colspan": 36})
        col += 36
        if col >= COL_COUNT:
            col = 0
            row += 20

    # Container widget required
    widgets["w_container"] = {
        "name": "w_container", "type": "container",
        "parameters": {"widgetStyle": {}}, "actions": [],
    }

    dash_name  = f"BIW_Sales_Incentive_{datetime.now().strftime('%Y%m%d_%H%M')}"
    dash_payload = {
        "name":                 dash_name,
        "label":                "BI Worldwide Sales Incentive",
        "workspaceIdOrApiName": ws_api,
        "widgets":              widgets,
        "layouts": [{
            "name": "default", "columnCount": COL_COUNT, "rowHeight": 10, "maxWidth": 1200,
            "style": {"backgroundColor": DASH_BG, "cellSpacingX": 8, "cellSpacingY": 8, "gutterColor": DASH_BG},
            "pages": [{"name": str(uuid.uuid4()), "label": "Overview", "widgets": page_widgets}],
        }],
    }
    r = requests.post(
        f"{VIZ_BASE}/tableau/dashboards",
        headers=sf_h,
        params=VIZ_PARAMS,
        json=dash_payload
    )
    if r.status_code not in (200, 201):
        print(f"  WARNING: Dashboard creation failed: {r.status_code} {r.text[:300]}")
        print(f"  You can build the dashboard manually in Tableau Next.")
        dash_api = dash_name
    else:
        dash_api = r.json().get("name", dash_name)
        print(f"  Dashboard created: {dash_api}")
        print(f"  Note: this is a starter dashboard — feel free to customize the layout,")
        print(f"  add filters, adjust colors, or rearrange tiles directly in Tableau Next.")
        _want_tips = input("\n  Would you like suggestions for enhancing the dashboard? [y/N]: ").strip().lower()
        if _want_tips == "y":
            print("""
  Dashboard enhancement ideas:
  ─────────────────────────────────────────────────────────────────────
  Layout
    • Add a date range filter and a Program Type filter at the top so
      the audience can slice immediately without navigating menus.
    • Put the two primary metrics (Participation Rate, Goal Achievement)
      in larger tiles (colspan 18) and push the three supporting metrics
      into a narrower second row — visually signals what matters most.

  Visualizations
    • Participation Rate by Month (line, color by Program Type) — shows
      which program is driving the decline over time.
    • Region × Size Band highlight table (Square mark) — instantly
      reveals the geographic/segment hotspot.
    • Redemption Rate vs Participation Rate scatter (Circle mark, color
      by Program Type) — shows the leading-indicator relationship between
      the two metrics across program types.

  Story flow
    • Order tiles so the audience reads: What's wrong? → Where? → Why?
      Primary metric BANs → trend line → heatmap → scatter.
    • Use the heatmap as the "where" answer and the scatter as the "why"
      answer — it creates a natural left-to-right narrative.
  ─────────────────────────────────────────────────────────────────────""")
    cp["all_dash_apis"].append(dash_api)
    cp["dash_api"] = dash_api
    save_checkpoint(cp)
    cp["dashboard_done"] = True
    save_checkpoint(cp)

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 8.5 — PULSE LIVE INSIGHTS (AI summaries via Pulse Insights API)
# ════════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("PHASE 8.5 — PULSE LIVE INSIGHTS")
print("=" * 70)

pulse_live_insights  = {}   # per-metric summaries (kept for reference)
pulse_prompt_answers = {}   # per-prompt Q&A answers

BRIEF_CT = "application/vnd.tableau.pulse.embeddingsservice.v1.GenerateInsightBriefRequest+json"

def _build_metric_context(base_url, h_rest, def_id, metric_id, metric_label):
    """Fetch live definition + metric spec and return a metric_group_context entry."""
    r_def = requests.get(f"{base_url}/api/-/pulse/definitions/{def_id}", headers=h_rest)
    r_met = requests.get(f"{base_url}/api/-/pulse/definitions/{def_id}/metrics", headers=h_rest)
    if r_def.status_code != 200 or r_met.status_code != 200:
        return None
    d = r_def.json().get("definition", {})
    metrics_list = r_met.json().get("metrics", [])
    if not metrics_list:
        return None
    m = metrics_list[0]
    return {
        "metadata": {"definition_id": def_id, "metric_id": metric_id,
                     "name": f"{COMPANY} — {metric_label}", "tags": []},
        "metric": {
            "definition":           d.get("specification", {}),
            "extension_options":    d.get("extension_options", {}),
            "metric_specification": m.get("specification", {}),
            "representation_options": d.get("representation_options", {}),
        }
    }

def _call_brief(base_url, auth_token, question, metric_contexts):
    """Call the Pulse brief endpoint with a specific question and metric context list."""
    h = {"x-tableau-auth": auth_token, "Accept": "application/json", "Content-Type": BRIEF_CT}
    payload = {
        "language": "LANGUAGE_EN_US",
        "locale":   "LOCALE_EN_US",
        "now":      date.today().isoformat(),
        "messages": [{
            "content":                     question,
            "action_type":                 "ACTION_TYPE_SUMMARIZE",
            "role":                        "ROLE_USER",
            "metric_group_context":        metric_contexts,
            "metric_group_context_resolved": False,
        }]
    }
    r = requests.post(f"{base_url}/api/-/pulse/insights/brief", headers=h, json=payload)
    if r.status_code in (200, 201):
        return r.json().get("markup", "")
    return f"[Error {r.status_code}: {r.text[:120]}]"

if cp.get("pulse_done") and cp.get("pulse_def_ids") and cp.get("pulse_datasource_id"):
    import re as _re
    _tab_server, _tab_token, _tab_site = get_tableau_token()
    _base = _tab_server.server_address.rstrip("/")
    h_rest = {"x-tableau-auth": _tab_token, "Accept": "application/json"}

    def_ids_stored    = cp["pulse_def_ids"]
    metric_ids_stored = cp["pulse_metric_ids"]

    # Build a label → context map (fetches each definition once)
    print("  Building metric context cache...")
    metric_label_to_idx = {mc["label"]: i for i, mc in enumerate(METRIC_CONFIG)}
    ctx_cache = {}
    for i, mc in enumerate(METRIC_CONFIG):
        if i >= len(def_ids_stored) or i >= len(metric_ids_stored):
            print(f"  Skipping {mc['label']} — def/metric ID not in checkpoint")
            continue
        ctx = _build_metric_context(_base, h_rest, def_ids_stored[i], metric_ids_stored[i], mc["label"])
        if ctx:
            ctx_cache[mc["label"]] = ctx

    _NO_DATA_PHRASES = [
        "i'm sorry", "i don't have", "i don't have enough", "not enough data",
        "unable to", "cannot provide", "no data", "insufficient data",
        "i apologize", "don't have access",
    ]

    def _is_no_data(text: str) -> bool:
        t = text.lower()
        return any(phrase in t for phrase in _NO_DATA_PHRASES)

    def _summarize(markup: str, max_sentences: int = 3) -> str:
        """Strip HTML tags and return the first max_sentences sentences."""
        clean = _re.sub(r"<[^>]+>", " ", markup)
        clean = _re.sub(r"\s+", " ", clean).strip()
        # Split on sentence-ending punctuation followed by a space/end
        parts = _re.split(r"(?<=[.!?])\s+", clean)
        return " ".join(parts[:max_sentences]).strip()

    # Per-prompt answers using the actual demo question text
    print(f"  Fetching answers for {len(DEMO_PROMPTS)} walkthrough prompts...")
    for step in DEMO_PROMPTS:
        contexts = [ctx_cache[lbl] for lbl in step["metrics"] if lbl in ctx_cache]
        if not contexts:
            print(f"    {step['title']}: skipped (no metric context)")
            continue
        print(f"    {step['title']}...")
        markup = _call_brief(_base, _tab_token, step["question"], contexts)
        clean = _re.sub(r"<[^>]+>", "", markup)

        # Retry with alt_question if response is a "no data" refusal
        if _is_no_data(clean) and step.get("alt_question"):
            print(f"      [no data response — retrying with alt question]")
            markup2 = _call_brief(_base, _tab_token, step["alt_question"], contexts)
            clean2 = _re.sub(r"<[^>]+>", "", markup2)
            if not _is_no_data(clean2):
                markup = markup2
                clean = clean2
                print(f"      [alt question succeeded]")
            else:
                print(f"      [alt question also returned no data — keeping original]")

        summary = _summarize(markup)
        pulse_prompt_answers[step["title"]] = summary
        print(f"      → {summary[:160]}")

    _tab_server.auth.sign_out()
    cp["pulse_prompt_answers"] = pulse_prompt_answers
    save_checkpoint(cp)
    print(f"\n  Captured answers for {len(pulse_prompt_answers)} prompts.")
else:
    print("  [SKIP] Pulse not complete or def IDs not in checkpoint — skipping live insights.")

# ════════════════════════════════════════════════════════════════════════════════
# PHASE 9 — DOCS + SUMMARY
# ════════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 70)
print("PHASE 9 — DOCS + SUMMARY")
print("=" * 70)

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

BUSINESS_PREFS = """# BI Worldwide Sales Incentive Analytics — Concierge Context

# COMPANY CONTEXT
# This data represents BI Worldwide's client portfolio — enterprise organizations using BI Worldwide's sales incentive platform.
# Each record is one client account's weekly incentive program activity.
# BI Worldwide operates in 183 countries; this dataset covers US-based client accounts.

# METRICS HIERARCHY
# PRIMARY — Participation Rate: the first metric to show. A sustained decline here means the platform is losing motivational effect.
# PRIMARY — Goal Achievement Rate: the second metric. Declining goal achievement erodes participation over a 2-4 week lag.
# SUPPORTING — Redemption Rate: a leading indicator. Reps stop redeeming when they stop believing in the program.
# SUPPORTING — Points Per Rep: behavioral signal. Falling points-per-rep precedes participation drops.
# SUPPORTING — Active Reps: volume baseline. Use to distinguish disengagement from headcount changes.

# DIAGNOSTIC DIMENSIONS (in priority order)
# 1. Program Type — President's Club programs show the sharpest decline (~35-40% drop). Sales Contest is moderate. Channel Partner is flat or slightly improving and is NOT a concern. Always filter by Program Type first.
# 2. Region — Northeast is the highest-signal region for President's Club; West is secondary. South and Southwest are largely unaffected.
# 3. Size Band — Mid-Market clients are hardest hit within President's Club. Large Enterprise and Global accounts are more resilient.
# 4. Vertical — Financial Services and Automotive show the strongest declines within the affected segments.

# KEY INSIGHT (compound story)
# The overall Participation Rate decline (~25%) understates the problem. When filtered to President's Club + Northeast + Mid-Market, the decline is ~40-45%. Channel Partner programs are flat or improving, which masks the severity in the averages.

# TIME COMPARISON PREFERENCE
# Default to last 12 weeks vs. prior 12 weeks for trend analysis.
# Use Year-over-Year for seasonal comparisons (incentive programs peak in Q4).

# TERMINOLOGY
# "At-risk client" = a client whose Participation Rate has declined >15% over 8 weeks.
# "Program engagement" = composite of Participation Rate + Goal Achievement Rate.
# "Points velocity" = Points Per Rep trend over 4 weeks.

# QUESTION INTENT — resolve ambiguous words without asking the user to clarify
# "worst" = the segment with the steepest percentage-point decline over the most recent 12-week trend. Never ask for clarification; default to steepest trend decline.
# "best" = the segment with the highest current value or most improvement over the most recent 12 weeks.
# "biggest drop" / "largest decline" = largest absolute percentage-point fall over 12 weeks.
# "most affected" = steepest decline in Participation Rate, segmented by the most recently mentioned dimension.
# "earlier warning" / "leading indicator" = look at Redemption Rate and Points Per Rep trends before the Participation Rate decline started (~3 months ago).
# "who is at risk" / "flag for outreach" = clients in Program Type = President's Club, Region = Northeast, Size Band = Mid-Market with Participation Rate declined >15% over 8 weeks.
# "how is X performing" = compare X's current Participation Rate trend to the portfolio average. Do not ask what metric to use; always use Participation Rate as the default.
# "is it concentrated" = compare the decline magnitude across Program Types and state whether one segment dominates. Never ask for clarification.

# ANSWER STYLE
# Never ask the user to clarify what they mean by common analytical terms (worst, best, biggest, most affected, etc.). Use the QUESTION INTENT definitions above and answer directly.
# When asked about declines, always start with Program Type, then drill to Region, then Size Band.
# The counter-narrative: Channel Partner programs are NOT declining — this is a President's Club problem, not a platform-wide problem.
# When asked which clients are most at risk, filter to Program Type = President's Club, Region = Northeast, Size Band = Mid-Market first.
# Lead with the answer, then supporting data. Do not open with questions back to the user.
"""

cp["business_preferences"] = BUSINESS_PREFS
save_checkpoint(cp)

# Write guide markdown
guide_path = os.path.join(DEMO_DIR, f"{SLUG}_guide.md")
with open(guide_path, "w") as f:
    f.write(f"""# BI Worldwide — Sales Incentive Demo Guide

## Story
**Audience:** New CIO at BI Worldwide
**Problem:** Overall Participation Rate is down ~25% — but that average hides the real story. President's Club programs are down ~35-40%, dragging the portfolio average. Channel Partner programs are flat or improving, masking the severity. The steepest concentration: President's Club + Northeast region + Mid-Market size band, where participation has dropped ~40-45%.

## Demo click path
1. Open Pulse / Tableau Next dashboard → see **Participation Rate** declining (~25% overall)
2. Filter by **Program Type = President's Club** → signal jumps to ~35-40% drop
3. Filter by **Region = Northeast** → worst regional concentration revealed
4. Add **Size Band = Mid-Market** → deepest cut: ~40-45% decline in this specific cohort
5. Switch to **Channel Partner** → counter-trend, flat or slightly improving — "it's not the platform, it's this program structure"
6. Open **Goal Achievement Rate** → confirms the drop in President's Club isn't isolated
7. Pull up **Redemption Rate** → leading indicator, already declining 2-3 weeks before participation dropped

## Key talking points
- "The overall number looks bad — but it's actually worse than it looks. Channel Partner is propping up the average."
- "President's Club in the Northeast for Mid-Market clients is down 40%. That's the at-risk cohort."
- "Channel Partner is flat — this is a President's Club design problem, not a platform problem. That's an actionable finding."
- Redemption Rate dropped first — the platform could have flagged this 2 weeks earlier if someone was watching.

## Metrics
| Metric | Type | Healthy | Current Signal |
|--------|------|---------|----------------|
| Participation Rate | Rate/Average | 70-80% | ~25% overall; ~40% in PC+Northeast+MidMkt |
| Goal Achievement Rate | Rate/Average | 65-75% | ~25% decline, concentrated in same cohort |
| Redemption Rate | Rate/Average | 70-78% | ~18% decline (leading indicator) |
| Points Per Rep | Average | 900-1800 | ~18% decline |
| Active Reps | Sum/Volume | varies | ~10% decline |

## Dimensions
- **Program Type** — President's Club (culprit, ~2× signal), Sales Contest (moderate), Quota Attainment (mild), Channel Partner (counter-trend, flat)
- **Region** — Northeast (worst), West (secondary), Midwest/South/Southwest (largely unaffected)
- **Size Band** — Mid-Market (hardest hit), Small Enterprise (moderate), Large Enterprise/Global (resilient)
- **Vertical** — Financial Services, Automotive (most affected within impacted cohorts)
""")
print(f"  Guide written: {guide_path}")

COMPANY_SUMMARY = (
    "BI Worldwide is a global engagement solutions company operating in 183 countries. "
    "They design and operate sales incentive programs — including President's Club, Sales Contests, "
    "Quota Attainment programs, and Channel Partner programs — on behalf of large enterprise clients. "
    "Their platform tracks rep-level participation, goal attainment, points accumulation, and reward "
    "redemption across each client's salesforce. This demo uses BI Worldwide's own internal analytics "
    "to surface a deteriorating engagement trend across their client portfolio before it becomes a "
    "retention risk."
)

# ── Build shared section content ──────────────────────────────────────────────
import re as _re
prompt_answers = cp.get("pulse_prompt_answers", {})

# Answers are stored as pre-summarized plain text from Phase 8.5
doc_steps = [
    {"title": step["title"], "question": step["question"], "answer": prompt_answers.get(step["title"], "")}
    for step in DEMO_PROMPTS
]

doc_metrics = [
    {"label": mc["label"], "description": mc["description"], "why_it_matters": mc["why_it_matters"]}
    for mc in METRIC_CONFIG
]

doc_sections = [
    {
        "heading": "Demo Scenario",
        "subsections": [
            {"subheading": "About BI Worldwide", "body": COMPANY_SUMMARY},
            {
                "subheading": "Audience & Story",
                "body": (
                    "Audience: New CIO at BI Worldwide\n\n"
                    "Story: Sales incentive program engagement is declining across key regions and verticals. "
                    "The CIO needs to identify where, why, and which clients are most at risk."
                ),
            },
        ],
    },
    {"heading": "Metrics Reference",  "metrics": doc_metrics},
    {"heading": "Concierge Prompts", "steps": doc_steps},
    {
        "heading": "Business Preferences (SDM)",
        "body": (
            "COPY AND PASTE the text below into:\n"
            "Data 360 → Semantic Model → [your SDM name] → AI Optimization → Manage Business Preferences\n\n"
            + BUSINESS_PREFS
        ),
    },
]

# ── Ask user: docx, Google Doc, or both ───────────────────────────────────────
from connections import has_google_config
_google_available = has_google_config(config)

if _google_available:
    print("\n  Document format:")
    print("    1  Local .docx (default)")
    print("    2  Google Doc (saved to your Drive)")
    print("    3  Both")
    _fmt_choice = input("  Choose format [1]: ").strip() or "1"
else:
    _fmt_choice = "1"

_write_docx   = _fmt_choice in ("1", "3")
_write_gdoc   = _fmt_choice in ("2", "3") and _google_available

# ── Write .docx ───────────────────────────────────────────────────────────────
docx_path = os.path.join(DEMO_DIR, f"{SLUG}_concierge_walkthrough.docx")
if _write_docx:
    doc = Document()
    doc.add_heading("BI Worldwide — Concierge Walkthrough", 0)

    # 1. Demo Scenario — company overview + story
    doc.add_heading("Demo Scenario", 1)
    doc.add_heading("About BI Worldwide", 2)
    doc.add_paragraph(COMPANY_SUMMARY)
    doc.add_heading("Audience & Story", 2)
    doc.add_paragraph("Audience: New CIO at BI Worldwide")
    doc.add_paragraph(
        "Story: Sales incentive program engagement is declining across key regions and verticals. "
        "The CIO needs to identify where, why, and which clients are most at risk."
    )

    # 2. Metrics Reference — before the prompts so readers understand what they're looking at
    doc.add_heading("Metrics Reference", 1)
    doc.add_paragraph(
        "Each metric below includes its definition and why it matters to the client. "
        "Use these to frame the story during the demo."
    )
    for mc in doc_metrics:
        doc.add_heading(mc["label"], 2)
        p = doc.add_paragraph()
        p.add_run("What it measures: ").bold = True
        p.add_run(mc["description"])
        p = doc.add_paragraph()
        p.add_run("Why it matters: ").bold = True
        p.add_run(mc["why_it_matters"])

    # 3. Concierge Prompts — Q&A with live AI responses
    doc.add_heading("Concierge Prompts", 1)
    doc.add_paragraph(
        "Each step below shows the question to ask followed by the expected Concierge response, "
        "captured live from the data at build time."
    )
    for step in doc_steps:
        doc.add_heading(step["title"], 2)
        p = doc.add_paragraph()
        p.add_run("Ask: ").bold = True
        p.add_run(f'"{step["question"]}"')
        if step["answer"]:
            p2 = doc.add_paragraph()
            p2.add_run("Expected response: ").bold = True
            p2.add_run(step["answer"])

    # 4. Business Preferences
    doc.add_heading("Business Preferences (SDM)", 1)
    doc.add_paragraph("COPY AND PASTE the text below into:")
    doc.add_paragraph("Data 360 → Semantic Model → [your SDM name] → AI Optimization → Manage Business Preferences")
    doc.add_paragraph("")
    doc.add_paragraph(BUSINESS_PREFS)

    doc.save(docx_path)
    print(f"  Walkthrough saved: {docx_path}")

# ── Write Google Doc ──────────────────────────────────────────────────────────
gdoc_url = None
if _write_gdoc:
    print("  Creating Google Doc...", end="", flush=True)
    try:
        import sys as _sys
        _sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/../..")
        from google_docs import create_walkthrough_doc
        gdoc_url = create_walkthrough_doc(
            title="BI Worldwide — Concierge Walkthrough",
            sections=doc_sections,
            google_config=config["google"],
        )
        cp["gdoc_url"] = gdoc_url
        save_checkpoint(cp)
        print(f" OK\n  Google Doc: {gdoc_url}")
    except Exception as _e:
        print(f" FAILED — {_e}")
        print("  Falling back to .docx only.")

# Final summary
tc = config["tableau"]
pulse_url = f"{tc['server_url'].rstrip('/')}/pulse"
sf_inst   = config["salesforce"].get("data_cloud_domain", "")

print("\n" + "=" * 70)
print("BUILD COMPLETE")
print("=" * 70)
print(f"\n  Company:    BI Worldwide")
print(f"  Use case:   Sales Incentive Program Engagement")
print(f"  Rows:       {len(df):,}")
print(f"\n  Metrics created:")
for label, api in cp.get("created_metrics", {}).items():
    print(f"    {label} → {api}")
print(f"\n  Visualizations:")
for v in cp.get("viz_apis", []):
    print(f"    {v}")
print(f"\n  Dashboard: {cp.get('dash_api','')}")
print(f"\n  Tableau Pulse:      {pulse_url}")
print(f"  Tableau Next SDM:   {sdm_api}")
print(f"  Workspace:          {ws_api}")
print(f"\n  Files:")
print(f"    CSV:         {csv_path}")
print(f"    Guide:       {guide_path}")
if _write_docx:
    print(f"    Walkthrough: {docx_path}")
if gdoc_url:
    print(f"    Google Doc:  {gdoc_url}")
print(f"\n  ⚠️  MANUAL STEP REQUIRED:")
print(f"     Open the walkthrough .docx and paste the 'Business Preferences'")
print(f"     text into: Data 360 → Semantic Model → {sdm_api} → AI Optimization → Manage Business Preferences")
print(f"\n  ⚠️  Enable Analytics Agent Readiness:")
print(f"     Data 360 → Semantic Model → {sdm_api} → Settings → Analytics Agent Readiness → toggle ON")
print("=" * 70)
