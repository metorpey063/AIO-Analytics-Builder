# BI Worldwide — Sales Incentive Demo Guide

## Story
**Audience:** New CIO at BI Worldwide
**Problem:** Overall Participation Rate is down ~25% — but that average hides the real story. President's Club programs are down ~35-40%, dragging the portfolio average. Channel Partner programs are flat or improving, masking the severity. The steepest concentration: President's Club + Northeast region + Mid-Market size band, where participation has dropped ~40-45%.

## Demo click path
1. Open Pulse / Tableau Next dashboard → see **Participation Rate** declining (~25% overall)
2. Filter by **Program Type = President's Club** → signal jumps to ~35-40% drop
3. Filter by **Region = Northeast** → worst regional concentration revealed
4. Add **Size Band = Mid-Market** → deepest cut: ~40-45% decline in this specific cohort
5. Switch to **Channel Partner** → counter-trend, flat or slightly improving — "it's not the platform, it's this program structure"
6. Open **Goal Achievement Rate** → confirms the drop in President's Club isn't isolated
7. Pull up **Redemption Rate** → leading indicator, already declining 2-3 weeks before participation dropped

## Key talking points
- "The overall number looks bad — but it's actually worse than it looks. Channel Partner is propping up the average."
- "President's Club in the Northeast for Mid-Market clients is down 40%. That's the at-risk cohort."
- "Channel Partner is flat — this is a President's Club design problem, not a platform problem. That's an actionable finding."
- Redemption Rate dropped first — the platform could have flagged this 2 weeks earlier if someone was watching.

## Metrics
| Metric | Type | Healthy | Current Signal |
|--------|------|---------|----------------|
| Participation Rate | Rate/Average | 70-80% | ~25% overall; ~40% in PC+Northeast+MidMkt |
| Goal Achievement Rate | Rate/Average | 65-75% | ~25% decline, concentrated in same cohort |
| Redemption Rate | Rate/Average | 70-78% | ~18% decline (leading indicator) |
| Points Per Rep | Average | 900-1800 | ~18% decline |
| Active Reps | Sum/Volume | varies | ~10% decline |

## Dimensions
- **Program Type** — President's Club (culprit, ~2× signal), Sales Contest (moderate), Quota Attainment (mild), Channel Partner (counter-trend, flat)
- **Region** — Northeast (worst), West (secondary), Midwest/South/Southwest (largely unaffected)
- **Size Band** — Mid-Market (hardest hit), Small Enterprise (moderate), Large Enterprise/Global (resilient)
- **Vertical** — Financial Services, Automotive (most affected within impacted cohorts)
