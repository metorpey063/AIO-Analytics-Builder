# George Washington University — Student Retention Demo Guide

**Use Case:** At-Risk Student Engagement Declining
**Persona:** VP of Student Affairs
**Platform:** Tableau Next + Salesforce Data Cloud
**Built:** 2026-05-08 00:00

---

## The Story

Over the past 6 months, GWU's at-risk student engagement rate has dropped sharply — from ~72% to ~45%. At the same time, support service sessions have fallen 36%. The VP of Student Affairs is seeing early warning signs: academic warning rates are creeping up, average GPA among at-risk students is sliding, and advisors are taking longer to reach flagged students.

**The "uh oh" moment:** Two leading indicators — engagement rate and service utilization — are declining in tandem. If this continues, retention will follow. The data is showing the problem before it becomes a crisis.

---

## Demo Click Path

### 1. Open the workspace
- Navigate to Tableau Next → **George Washington University — Student Retention** workspace
- Enable Analytics Agent Readiness if not already on (Data 360 → Semantic Model → Settings → toggle ON)

### 2. Lead with At-Risk Engagement Rate
- Open the **At-Risk Engagement Rate** metric tile
- Point out the sparkline: clear downward trend over the last 6 months
- *"We're reaching far fewer at-risk students than we were a year ago"*

### 3. Confirm with Support Service Utilization
- Open **Support Service Utilization** — sessions are down 36%
- *"And it's not just an engagement number — the actual service interactions are falling too"*

### 4. Drill into the supporting metrics
- Show **Retention Rate** beginning to dip — *"We haven't felt this in retention yet, but we will"*
- Show **Academic Warning Rate** rising — *"Warning flags are going up while engagement is going down — that's a dangerous combination"*
- Show **Days to First Outreach** increasing — *"Advisors are taking longer to reach students who need help"*

### 5. Use Concierge to go deeper (see walkthrough doc)
- Open the Concierge panel and paste the questions from the walkthrough
- Demonstrate how the AI synthesises insights across all metrics in natural language

---

## Dimensions Available
- **School** — Columbian College, School of Business, Elliott School, etc.
- **Risk Category** — Academic, Financial, Social-Emotional, First-Generation
- **Campus** — Foggy Bottom, Mount Vernon, Virginia Science & Technology

---

## Metric Reference

| Metric | Type | Signal | Direction |
|--------|------|--------|-----------|
| At-Risk Engagement Rate | Primary | −37% over 6 months | Down is bad |
| Support Service Utilization | Primary | −36% over 6 months | Down is bad |
| Retention Rate | Supporting | −13% over 6 months | Down is bad |
| Academic Warning Rate | Supporting | +12% over 6 months | Up is bad |
| Average GPA | Supporting | −10% over 6 months | Down is bad |
| Days to First Outreach | Supporting | +11% over 6 months | Up is bad |

---

## Post-Demo Checklist
- [ ] Enable Analytics Agent Readiness toggle in Data 360 → Semantic Model → Settings
- [ ] Confirm Concierge panel is accessible in the workspace
- [ ] Share walkthrough .docx with the SE running the demo
