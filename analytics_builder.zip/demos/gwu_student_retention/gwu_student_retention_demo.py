"""
GWU Student Retention — Tableau Next Demo
Company: George Washington University
Use Case: Student Retention (At-Risk Student Engagement Declining)
Persona: VP of Student Affairs
Primary Metrics: At-Risk Student Engagement Rate, Support Service Utilization
Supporting Metrics: Retention Rate, Academic Warning Rate, Average GPA, Days to First Outreach
Output: Tableau Next (Salesforce Data Cloud)
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import json, time, uuid, math, random
import requests
import pandas as pd
import numpy as np
from datetime import date, datetime
from dateutil.relativedelta import relativedelta
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

from connections import load_config, get_sf_token, get_dc_token, sf_headers, dc_headers

# ── Parameters ──────────────────────────────────────────────────────────────────
COMPANY       = "George Washington University"
COMPANY_SLUG  = "gwu"
USE_CASE      = "Student Retention"
USE_CASE_SLUG = "student_retention"
SLUG          = f"{COMPANY_SLUG}_{USE_CASE_SLUG}"
TODAY         = date.today()
TIMESTAMP     = TODAY.strftime("%Y-%m-%d %H:%M")
DEMO_DIR      = os.path.dirname(os.path.abspath(__file__))

# GWU brand colors — from communications.gwu.edu/brand-guidelines/color-palette
BRAND = {
    "primary":   "#033C5A",   # GW Blue
    "secondary": "#D6BF91",   # GW Buff
    "chart_bg":  "#FFFFFF",
    "text":      "#033C5A",   # use GW Blue for text
    "dash_bg":   "#E6F1F6",   # 10% tint of GW Blue (blended 90% toward white)
}

SCHOOLS = [
    "Columbian College of Arts & Sciences",
    "School of Business",
    "Elliott School of International Affairs",
    "School of Engineering & Applied Science",
    "Milken Institute School of Public Health",
    "School of Media & Public Affairs",
    "School of Education & Human Development",
    "Law School",
]

RISK_CATEGORIES = ["Academic", "Financial", "Social-Emotional", "First-Generation"]
CAMPUSES        = ["Foggy Bottom", "Mount Vernon", "Virginia Science & Technology"]

METRIC_CONFIG = {
    "engagement_rate": {
        "label":         "At-Risk Student Engagement Rate",
        "field":         "Engagement Rate",
        "agg":           "Average",
        "singular_noun": "at-risk student engagement",
        "plural_noun":   "at-risk student engagements",
        "sentiment":     "SentimentTypeUpIsGood",
        "is_primary":    True,
    },
    "service_utilization": {
        "label":         "Support Service Utilization",
        "field":         "Service Sessions",
        "agg":           "Sum",
        "singular_noun": "support service session",
        "plural_noun":   "support service sessions",
        "sentiment":     "SentimentTypeUpIsGood",
        "is_primary":    True,
    },
    "retention_rate": {
        "label":         "Retention Rate",
        "field":         "Retention Rate",
        "agg":           "Average",
        "singular_noun": "student retention",
        "plural_noun":   "student retentions",
        "sentiment":     "SentimentTypeUpIsGood",
        "is_primary":    False,
    },
    "academic_warning_rate": {
        "label":         "Academic Warning Rate",
        "field":         "Academic Warning Rate",
        "agg":           "Average",
        "singular_noun": "academic warning",
        "plural_noun":   "academic warnings",
        "sentiment":     "SentimentTypeUpIsBad",
        "is_primary":    False,
    },
    "avg_gpa": {
        "label":         "Average GPA",
        "field":         "Average GPA",
        "agg":           "Average",
        "singular_noun": "average GPA",
        "plural_noun":   "average GPAs",
        "sentiment":     "SentimentTypeUpIsGood",
        "is_primary":    False,
    },
    "days_to_outreach": {
        "label":         "Days to First Outreach",
        "field":         "Days to First Outreach",
        "agg":           "Average",
        "singular_noun": "days to first outreach",
        "plural_noun":   "days to first outreach",
        "sentiment":     "SentimentTypeUpIsBad",
        "is_primary":    False,
    },
}

# ── Signal ramp ─────────────────────────────────────────────────────────────────
def signal_ramp(d, onset=-6, duration=6):
    months_from_today = (d.year - TODAY.year) * 12 + (d.month - TODAY.month)
    if months_from_today <= onset:
        return 0.0
    return min(1.0, (months_from_today - onset) / duration)

# ── Phase 1 — Data generation ────────────────────────────────────────────────────
def generate_data():
    print("\n── Phase 1: Generating data ────────────────────────────────────────")
    random.seed(42)
    np.random.seed(42)

    months = [TODAY - relativedelta(months=i) for i in range(23, -1, -1)]
    rows = []

    for school in SCHOOLS:
        for risk_cat in RISK_CATEGORIES:
            for campus in CAMPUSES:
                for month in months:
                    ramp = signal_ramp(month)

                    # At-Risk Engagement Rate: baseline 0.72, decline to ~0.45 (primary, -37%)
                    base_eng = 0.72 + np.random.normal(0, 0.015)
                    engagement_rate = base_eng * (1 - 0.37 * ramp) + np.random.normal(0, 0.01)
                    engagement_rate = max(0.30, min(0.95, engagement_rate))

                    # Support Service Sessions: baseline ~85/school/month, decline to ~54 (primary, -36%)
                    base_sessions = 85 + np.random.normal(0, 4)
                    service_sessions = base_sessions * (1 - 0.36 * ramp) + np.random.normal(0, 3)
                    service_sessions = max(20, service_sessions)

                    # Retention Rate: baseline 0.943, supporting decline to ~0.82 (-13%)
                    base_ret = 0.943 + np.random.normal(0, 0.005)
                    retention_rate = base_ret * (1 - 0.13 * ramp) + np.random.normal(0, 0.003)
                    retention_rate = max(0.70, min(0.99, retention_rate))

                    # Academic Warning Rate: baseline 0.08, rise to ~0.135 (+12% supporting)
                    base_warn = 0.08 + np.random.normal(0, 0.005)
                    academic_warning_rate = base_warn * (1 + 0.12 * ramp) + np.random.normal(0, 0.003)
                    academic_warning_rate = max(0.02, min(0.35, academic_warning_rate))

                    # Average GPA: baseline 3.32, decline to ~2.98 (-10% supporting)
                    base_gpa = 3.32 + np.random.normal(0, 0.03)
                    avg_gpa = base_gpa * (1 - 0.10 * ramp) + np.random.normal(0, 0.02)
                    avg_gpa = max(2.50, min(4.00, avg_gpa))

                    # Days to First Outreach: baseline 3.2 days, rise to ~5.6 (+11% supporting)
                    base_days = 3.2 + np.random.normal(0, 0.2)
                    days_to_outreach = base_days * (1 + 0.11 * ramp) + np.random.normal(0, 0.15)
                    days_to_outreach = max(1.0, days_to_outreach)

                    rows.append({
                        "Month":                  month.replace(day=1),
                        "School":                 school,
                        "Risk Category":          risk_cat,
                        "Campus":                 campus,
                        "Engagement Rate":        round(engagement_rate, 4),
                        "Service Sessions":       round(service_sessions, 1),
                        "Retention Rate":         round(retention_rate, 4),
                        "Academic Warning Rate":  round(academic_warning_rate, 4),
                        "Average GPA":            round(avg_gpa, 3),
                        "Days to First Outreach": round(days_to_outreach, 2),
                    })

    df = pd.DataFrame(rows)

    # Sanity check
    eng = df["Engagement Rate"]
    ret = df["Retention Rate"]
    sess = df["Service Sessions"]
    print(f"  Engagement Rate  — min:{eng.min():.3f}  max:{eng.max():.3f}  mean:{eng.mean():.3f}")
    print(f"  Retention Rate   — min:{ret.min():.3f}  max:{ret.max():.3f}  mean:{ret.mean():.3f}")
    print(f"  Service Sessions — min:{sess.min():.1f}  max:{sess.max():.1f}  mean:{sess.mean():.1f}")
    print(f"  Rows generated: {len(df)}")

    return df

# ── Auth ──────────────────────────────────────────────────────────────────────
def get_tokens():
    config = load_config()
    sf_token, sf_instance = get_sf_token(config)
    dc_token, dc_domain   = get_dc_token(sf_token, sf_instance)
    connector_name        = config["salesforce"]["ingestion_connector_name"]
    connector_id          = config["salesforce"]["connector_sf_id"]
    return sf_token, sf_instance, dc_token, dc_domain, connector_name, connector_id

# ── Checkpoint helpers ────────────────────────────────────────────────────────
CHECKPOINT_FILE = os.path.join(DEMO_DIR, f"{SLUG}_checkpoint.json")

def load_checkpoint():
    if os.path.exists(CHECKPOINT_FILE):
        with open(CHECKPOINT_FILE) as f:
            return json.load(f)
    return {}

def save_checkpoint(cp):
    with open(CHECKPOINT_FILE, "w") as f:
        json.dump(cp, f, indent=2)
    print(f"  [checkpoint saved]")

# ── Phase 2 — Schema + Streams ────────────────────────────────────────────────
def phase2_schema_streams(sf_token, sf_instance, connector_name, connector_id, cp):
    if cp.get("phase2_done"):
        print("\n── Phase 2: Schema + Streams [skipped — already done] ──────────────")
        return cp

    print("\n── Phase 2: Registering schema + creating data streams ──────────────")
    hdrs = sf_headers(sf_token)

    FACT_SCHEMA_NAME = f"{COMPANY_SLUG}_Fact_StudentEngagement"

    # GET existing schema
    r = requests.get(
        f"{sf_instance}/services/data/v62.0/ssot/connections/{connector_id}/schema",
        headers=hdrs
    )
    existing_schemas = r.json().get("schemas", []) if r.status_code == 200 else []

    def clean_schema(s):
        return {k: s[k] for k in ("name", "label", "schemaType", "fields") if k in s}

    fact_schema = {
        "name":       FACT_SCHEMA_NAME,
        "label":      FACT_SCHEMA_NAME,
        "schemaType": "IngestApi",
        "fields": [
            {"name": "month_date",              "label": "month_date",              "dataType": "Date"},
            {"name": "school",                  "label": "school",                  "dataType": "Text"},
            {"name": "risk_category",           "label": "risk_category",           "dataType": "Text"},
            {"name": "campus",                  "label": "campus",                  "dataType": "Text"},
            {"name": "engagement_rate",         "label": "engagement_rate",         "dataType": "Number"},
            {"name": "service_sessions",        "label": "service_sessions",        "dataType": "Number"},
            {"name": "retention_rate",          "label": "retention_rate",          "dataType": "Number"},
            {"name": "academic_warning_rate",   "label": "academic_warning_rate",   "dataType": "Number"},
            {"name": "avg_gpa",                 "label": "avg_gpa",                 "dataType": "Number"},
            {"name": "days_to_outreach",        "label": "days_to_outreach",        "dataType": "Number"},
        ]
    }

    # Merge schema (preserve existing, replace/add ours)
    merged = {s["name"]: clean_schema(s) for s in existing_schemas}
    merged[FACT_SCHEMA_NAME] = fact_schema

    r = requests.put(
        f"{sf_instance}/services/data/v62.0/ssot/connections/{connector_id}/schema",
        headers=hdrs, json={"schemas": list(merged.values())}
    )
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Schema PUT failed: {r.status_code} {r.text[:300]}")
    print(f"  Schema registered: {FACT_SCHEMA_NAME}")

    # Create data stream
    config      = load_config()
    conn_uuid   = config["salesforce"].get("connector_uuid_name", connector_name)
    stream_name_req = f"demo_{FACT_SCHEMA_NAME.lower()}"[:40]
    stream_payload = {
        "name":             stream_name_req,
        "label":            "GWU Student Engagement Fact",
        "datasource":       connector_name[:10],
        "datastreamType":   "INGESTAPI",
        "connectorInfo": {
            "connectorType":    "IngestApi",
            "connectorDetails": {"name": conn_uuid, "events": [FACT_SCHEMA_NAME]},
        },
        "dataLakeObjectInfo": {
            "label":    "GWU Student Engagement Fact",
            "category": "Other",
            "dataspaceInfo": [{"name": "default"}],
            "dataLakeFieldInputRepresentations": [
                {"name": "month_date", "label": "month_date", "dataType": "Date", "isPrimaryKey": True}
            ],
            "eventDateTimeFieldName":  "",
            "recordModifiedFieldName": "",
        },
        "mappings": [],
    }
    r = requests.post(
        f"{sf_instance}/services/data/v62.0/ssot/data-streams",
        headers=hdrs, json=stream_payload
    )
    if r.status_code in (200, 201):
        stream_name = r.json().get("name", stream_name_req)
        print(f"  Data stream created: {stream_name}")
    elif "already in use" in r.text.lower() or "already exists" in r.text.lower():
        print("  Stream already exists — discovering...")
        r2 = requests.get(
            f"{sf_instance}/services/data/v62.0/ssot/data-streams",
            headers=hdrs, params={"connectorId": connector_id, "limit": 200}
        )
        stream_name = None
        for ds in r2.json().get("dataStreams", []):
            if FACT_SCHEMA_NAME.lower() in ds.get("name", "").lower():
                stream_name = ds["name"]
                break
        if not stream_name:
            raise RuntimeError("Stream exists but could not be found")
        print(f"  Found existing stream: {stream_name}")
    else:
        raise RuntimeError(f"Data stream POST failed: {r.status_code} {r.text[:300]}")

    # Poll for ACTIVE — status is nested under dataLakeObjectInfo, not at top level
    print("  Waiting for DLO to become ACTIVE...")
    for attempt in range(30):
        time.sleep(10)
        r = requests.get(
            f"{sf_instance}/services/data/v62.0/ssot/data-streams/{stream_name}",
            headers=hdrs
        )
        body = r.json()
        status = body.get("dataLakeObjectInfo", {}).get("status") or body.get("status", "UNKNOWN")
        print(f"    [{attempt+1}/30] status: {status}")
        if status == "ACTIVE":
            break
    else:
        raise RuntimeError("DLO did not become ACTIVE within 5 minutes")

    # Wait an extra 30s after ACTIVE before bulk ingest — schema propagation lag
    print("  DLO is ACTIVE. Waiting 30s for schema propagation...")
    time.sleep(30)

    # Get the actual DLO name from the stream response
    r_stream = requests.get(
        f"{sf_instance}/services/data/v62.0/ssot/data-streams/{stream_name}",
        headers=hdrs
    )
    dlo_name = r_stream.json().get("dataLakeObjectInfo", {}).get("name", FACT_SCHEMA_NAME)
    print(f"  DLO name: {dlo_name}")

    cp["phase2_done"]   = True
    cp["stream_name"]   = stream_name
    cp["fact_obj_name"] = FACT_SCHEMA_NAME
    cp["dlo_name"]      = dlo_name
    save_checkpoint(cp)
    return cp

# ── Phase 3 — Bulk Ingest ─────────────────────────────────────────────────────
def phase3_bulk_ingest(df, dc_token, dc_domain, connector_name, cp):
    if cp.get("phase3_done"):
        print("\n── Phase 3: Bulk Ingest [skipped — already done] ────────────────────")
        return cp

    print("\n── Phase 3: Bulk ingest ─────────────────────────────────────────────")
    hdrs = dc_headers(dc_token)
    fact_obj = cp["fact_obj_name"]

    # Wait for schema to propagate to Bulk API
    print("  Waiting 20s for schema to propagate to Bulk API...")
    time.sleep(20)

    def submit_job(obj_name, records):
        payload = {"object": obj_name, "sourceName": connector_name, "operation": "upsert"}
        for attempt in range(5):
            r = requests.post(
                f"https://{dc_domain}/api/v1/ingest/jobs",
                headers=hdrs, json=payload
            )
            if r.status_code == 404:
                print(f"    404 on job submit — retrying in 15s (attempt {attempt+1}/5)...")
                time.sleep(15)
                continue
            if r.status_code not in (200, 201):
                raise RuntimeError(f"Job submit failed: {r.status_code} {r.text[:300]}")
            body = r.json()
            return body.get("id") or body.get("data", {}).get("id")
        raise RuntimeError(f"Could not submit ingest job for {obj_name} after 5 retries")

    def upload_data(job_id, records):
        csv_lines = []
        fields = list(records[0].keys())
        csv_lines.append(",".join(fields))
        for rec in records:
            csv_lines.append(",".join(str(rec[f]) for f in fields))
        csv_data = "\n".join(csv_lines)
        r = requests.put(
            f"https://{dc_domain}/api/v1/ingest/jobs/{job_id}/batches",
            headers={**hdrs, "Content-Type": "text/csv"},
            data=csv_data.encode("utf-8")
        )
        if r.status_code not in (200, 201, 202):
            raise RuntimeError(f"Batch upload failed: {r.status_code} {r.text[:300]}")

    def close_job(job_id):
        r = requests.patch(
            f"https://{dc_domain}/api/v1/ingest/jobs/{job_id}",
            headers=hdrs, json={"state": "UploadComplete"}
        )
        if r.status_code not in (200, 201):
            raise RuntimeError(f"Job close failed: {r.status_code} {r.text[:300]}")

    def poll_job(job_id, label="job"):
        for attempt in range(60):
            time.sleep(10)
            r = requests.get(f"https://{dc_domain}/api/v1/ingest/jobs/{job_id}", headers=hdrs)
            body = r.json()
            state = body.get("state") or body.get("data", {}).get("state", "UNKNOWN")
            print(f"    [{label}] attempt {attempt+1}/60: {state}")
            if state == "JobComplete":
                return
            if state in ("Failed", "Aborted"):
                raise RuntimeError(f"Ingest job {job_id} failed: {r.text[:300]}")
        raise RuntimeError(f"Ingest job {job_id} did not complete within 10 minutes")

    # Build records
    fact_records = []
    for _, row in df.iterrows():
        fact_records.append({
            "month_date":            row["Month"].strftime("%Y-%m-%d"),
            "school":                row["School"],
            "risk_category":         row["Risk Category"],
            "campus":                row["Campus"],
            "engagement_rate":       row["Engagement Rate"],
            "service_sessions":      row["Service Sessions"],
            "retention_rate":        row["Retention Rate"],
            "academic_warning_rate": row["Academic Warning Rate"],
            "avg_gpa":               row["Average GPA"],
            "days_to_outreach":      row["Days to First Outreach"],
        })

    print(f"  Submitting ingest job ({len(fact_records)} rows)...")
    job_id = submit_job(fact_obj, fact_records)
    upload_data(job_id, fact_records)
    close_job(job_id)
    print(f"  Job submitted: {job_id}. Polling for completion...")
    poll_job(job_id, "fact")

    cp["phase3_done"] = True
    save_checkpoint(cp)
    return cp

# ── Phase 4 — Workspace + SDM ─────────────────────────────────────────────────
def phase4_workspace_sdm(sf_token, sf_instance, cp):
    if cp.get("phase4_done"):
        print("\n── Phase 4: Workspace + SDM [skipped — already done] ────────────────")
        return cp

    print("\n── Phase 4: Building workspace + Semantic Data Model ────────────────")
    hdrs = sf_headers(sf_token)

    # Retry cleanup — delete any workspace/SDM created by prior failed runs
    for prev_sdm in cp.get("all_sdm_apis", []):
        dr = requests.delete(f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{prev_sdm}", headers=hdrs)
        print(f"  Cleaned up stale SDM {prev_sdm}: {dr.status_code}")
    for prev_ws in cp.get("all_ws_apis", []):
        dr = requests.delete(f"{sf_instance}/services/data/v65.0/tableau/workspaces/{prev_ws}", headers=hdrs)
        print(f"  Cleaned up stale workspace {prev_ws}: {dr.status_code}")
    cp["all_sdm_apis"] = []
    cp["all_ws_apis"]  = []
    cp.pop("ws_api",  None)
    cp.pop("sdm_api", None)
    cp.pop("do_api",  None)
    save_checkpoint(cp)

    # Create workspace
    ws_payload = {"label": f"{COMPANY} — {USE_CASE}", "name": SLUG}
    r = requests.post(f"{sf_instance}/services/data/v65.0/tableau/workspaces", headers=hdrs, json=ws_payload)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Workspace creation failed: {r.status_code} {r.text[:300]}")
    ws_api = r.json().get("name", SLUG)
    cp["all_ws_apis"].append(ws_api)
    save_checkpoint(cp)
    print(f"  Workspace created: {ws_api}")

    # Create SDM
    sdm_payload = {"label": f"{COMPANY} Student Retention", "dataspace": "default", "agentEnabled": True}
    r = requests.post(f"{sf_instance}/services/data/v65.0/ssot/semantic/models", headers=hdrs, json=sdm_payload)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"SDM creation failed: {r.status_code} {r.text[:300]}")
    sdm_api = r.json().get("apiName")
    cp["all_sdm_apis"].append(sdm_api)
    save_checkpoint(cp)
    print(f"  SDM created: {sdm_api}")

    # Add fact DLO to SDM — use the actual DLO name from the stream, not the schema name
    dlo_name = cp.get("dlo_name", cp["fact_obj_name"])
    dlo_payload = {"label": "Student Engagement Activity", "dataObjectType": "dlo", "dataObjectName": dlo_name}
    r = requests.post(f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects", headers=hdrs, json=dlo_payload)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"DLO add failed: {r.status_code} {r.text[:300]}")
    do_api = r.json().get("apiName")
    print(f"  DLO added: {do_api}")

    # Get auto-detected measurements
    time.sleep(5)
    r = requests.get(
        f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects/{do_api}",
        headers=hdrs
    )
    do_detail = r.json()
    measurements = do_detail.get("semanticMeasurements", [])
    print(f"  Auto-detected measurements: {[m['apiName'] for m in measurements]}")

    # Update aggregation for each measurement
    field_to_agg = {
        "engagement_rate":       "Average",
        "service_sessions":      "Sum",
        "retention_rate":        "Average",
        "academic_warning_rate": "Average",
        "avg_gpa":               "Average",
        "days_to_outreach":      "Average",
    }
    measurement_api_map = {}
    for m in measurements:
        field = m.get("dataObjectFieldName", "").rstrip("__c").lower()
        api   = m.get("apiName")
        agg   = field_to_agg.get(field, "Average")
        put_body = {
            "apiName":             api,
            "label":               m.get("label", api),
            "dataObjectFieldName": m.get("dataObjectFieldName"),
            "aggregationType":     agg,
        }
        r = requests.put(
            f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects/{do_api}/measurements/{api}",
            headers=hdrs, json=put_body
        )
        if r.status_code not in (200, 201):
            print(f"    WARNING: measurement PUT failed for {api}: {r.status_code} {r.text[:200]}")
        else:
            print(f"  Measurement updated: {api} → {agg}")
        measurement_api_map[field] = api

    cp["phase4_done"]           = True
    cp["ws_api"]                = ws_api
    cp["sdm_api"]               = sdm_api
    cp["do_api"]                = do_api
    cp["measurement_api_map"]   = measurement_api_map
    save_checkpoint(cp)
    return cp

# ── Phase 5 — Calculated Measurements + Metrics ───────────────────────────────
def phase5_metrics(sf_token, sf_instance, cp):
    if cp.get("phase5_done"):
        print("\n── Phase 5: Metrics [skipped — already done] ────────────────────────")
        return cp

    print("\n── Phase 5: Creating calculated measurements + semantic metrics ──────")
    hdrs    = sf_headers(sf_token)
    sdm_api = cp["sdm_api"]
    do_api  = cp["do_api"]
    m_map   = cp["measurement_api_map"]

    # (cfg_key, field_key, agg_fn, clc_api)
    metric_defs = [
        ("engagement_rate",       "engagement_rate",       "AVG",  "gwu_engagement_rate_clc"),
        ("service_utilization",   "service_sessions",      "SUM",  "gwu_service_sessions_clc"),
        ("retention_rate",        "retention_rate",        "AVG",  "gwu_retention_rate_clc"),
        ("academic_warning_rate", "academic_warning_rate", "AVG",  "gwu_academic_warning_clc"),
        ("avg_gpa",               "avg_gpa",               "AVG",  "gwu_avg_gpa_clc"),
        ("days_to_outreach",      "days_to_outreach",      "AVG",  "gwu_days_outreach_clc"),
    ]

    # Step 1: Create _clc calculated measurements (delete existing first)
    clc_map = {}
    for cfg_key, field_key, agg_fn, clc_api in metric_defs:
        meas_api = m_map.get(field_key)
        if not meas_api:
            print(f"  WARNING: No measurement for {field_key}, skipping")
            continue
        # Delete if exists from a previous run
        requests.delete(
            f"{sf_instance}/services/data/v66.0/ssot/semantic/models/{sdm_api}/calculated-measurements/{clc_api}",
            headers=hdrs
        )
        expr = f"{agg_fn}([{do_api}].[{meas_api}])"
        cfg  = METRIC_CONFIG[cfg_key]
        r = requests.post(
            f"{sf_instance}/services/data/v66.0/ssot/semantic/models/{sdm_api}/calculated-measurements",
            headers=hdrs,
            json={
                "apiName": clc_api, "label": cfg["label"],
                "aggregationType": "UserAgg", "dataType": "Number", "decimalPlace": 4,
                "directionality": "Up", "displayCategory": "Continuous",
                "expression": expr, "filters": [], "isOverrideBase": False, "isVisible": True,
                "level": "AggregateFunction", "overriddenProperties": [],
                "semanticDataType": "None", "sentiment": cfg["sentiment"],
                "shouldTreatNullsAsZeros": False, "sortOrder": "None", "totalAggregationType": "Sum",
            }
        )
        if r.status_code in (200, 201):
            actual = r.json().get("apiName", clc_api)
            clc_map[cfg_key] = actual
            print(f"  _clc created: {actual}")
        else:
            print(f"  WARNING: _clc failed for {cfg['label']}: {r.status_code} {r.text[:200]}")

    # Step 2: Create semantic metrics referencing the _clc
    metric_api_map = {}
    for cfg_key, field_key, agg_fn, clc_api in metric_defs:
        actual_clc = clc_map.get(cfg_key)
        if not actual_clc:
            print(f"  WARNING: No _clc for {cfg_key}, skipping metric")
            continue
        cfg = METRIC_CONFIG[cfg_key]
        r = requests.post(
            f"{sf_instance}/services/data/v66.0/ssot/semantic/models/{sdm_api}/metrics",
            headers=hdrs,
            json={
                "label": cfg["label"],
                "aggregationType": "UserAgg",
                "measurementReference": {"calculatedFieldApiName": actual_clc},
                "timeDimensionReference": {"tableFieldReference": {
                    "fieldApiName": "month_date", "tableApiName": do_api,
                }},
                "timeGrains": ["Day", "Week", "Month", "Quarter", "Year"],
                "filters": [], "isCumulative": False, "isGoalEditingBlocked": False,
                "additionalDimensions": [
                    {"tableFieldReference": {"fieldApiName": "school",        "tableApiName": do_api}},
                    {"tableFieldReference": {"fieldApiName": "risk_category", "tableApiName": do_api}},
                    {"tableFieldReference": {"fieldApiName": "campus",        "tableApiName": do_api}},
                ],
                "insightsSettings": {
                    "insightTypes": [
                        {"enabled": True, "type": "TrendChangeAlert"},
                        {"enabled": True, "type": "CurrentTrend"},
                        {"enabled": True, "type": "TopContributors"},
                        {"enabled": True, "type": "BottomContributors"},
                        {"enabled": True, "type": "TopDrivers"},
                    ],
                    "insightsDimensionsReferences": [
                        {"tableFieldReference": {"fieldApiName": "school",        "tableApiName": do_api}},
                        {"tableFieldReference": {"fieldApiName": "risk_category", "tableApiName": do_api}},
                    ],
                    "pluralNoun": cfg["plural_noun"],
                    "singularNoun": cfg["singular_noun"],
                    "sentiment": cfg["sentiment"],
                },
            }
        )
        if r.status_code in (200, 201):
            mtc_api = r.json().get("apiName")
            metric_api_map[cfg_key] = mtc_api
            print(f"  Metric created: {mtc_api} ({cfg['label']})")
        else:
            print(f"  WARNING: Metric failed for {cfg['label']}: {r.status_code} {r.text[:300]}")

    cp["phase5_done"]     = True
    cp["metric_api_map"]  = metric_api_map
    save_checkpoint(cp)
    return cp

# ── Phase 6 — Visualizations + Dashboard ─────────────────────────────────────
def phase6_vizzes_dashboard(sf_token, sf_instance, cp):
    if cp.get("phase6_done"):
        print("\n── Phase 6: Vizzes + Dashboard [skipped — already done] ─────────────")
        return cp

    print("\n── Phase 6: Creating visualizations + dashboard ─────────────────────")
    hdrs    = sf_headers(sf_token)
    sdm_api = cp["sdm_api"]
    ws_api  = cp["ws_api"]
    do_api  = cp["do_api"]

    VIZ_PARAMS = {"minorVersion": "12"}

    # Delete any vizzes/dashboards created by previous (failed) runs of this phase.
    # We only delete what we created — tracked in the checkpoint across retries.
    for prev_dash in cp.get("all_dash_apis", []):
        r = requests.delete(
            f"{sf_instance}/services/data/v66.0/tableau/dashboards/{prev_dash}",
            headers=hdrs, params=VIZ_PARAMS
        )
        print(f"  Deleted previous dashboard: {prev_dash} ({r.status_code})")
    for prev_viz in cp.get("all_viz_apis", []):
        r = requests.delete(
            f"{sf_instance}/services/data/v66.0/tableau/visualizations/{prev_viz}",
            headers=hdrs, params=VIZ_PARAMS
        )
        print(f"  Deleted previous viz: {prev_viz} ({r.status_code})")
    cp["all_dash_apis"] = []
    cp["all_viz_apis"]  = []
    save_checkpoint(cp)

    FONTS = {
        "actionableHeaders": {"color": BRAND["primary"], "size": 13},
        "axisTickLabels":    {"color": BRAND["text"],    "size": 13},
        "fieldLabels":       {"color": BRAND["text"],    "size": 13},
        "headers":           {"color": BRAND["text"],    "size": 13},
        "legendLabels":      {"color": BRAND["text"],    "size": 13},
        "markLabels":        {"color": BRAND["text"],    "size": 13},
        "marks":             {"color": BRAND["text"],    "size": 13},
    }
    LINES = {
        "axisLine":              {"color": "#C9C9C9"},
        "fieldLabelDividerLine": {"color": "#C9C9C9"},
        "separatorLine":         {"color": "#C9C9C9"},
        "zeroLine":              {"color": "#C9C9C9"},
    }

    def _marks_headers_style():
        return {
            "color": {"color": ""}, "isAutomaticSize": True,
            "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
            "range": {"reverse": False},
            "size": {"isAutomatic": True, "type": "Pixel", "value": 13},
        }

    def make_viz(name, label, flds, vis_type, dim_field):
        chart_type = "Line" if vis_type == "line" else "Bar"

        payload = {
            "name":  name,
            "label": label,
            "dataSource": {"name": sdm_api, "label": label, "type": "SemanticModel"},
            "workspace":  {"name": ws_api,  "label": ws_api},
            "interactions": [],
            "fields": flds,
            "visualSpecification": {
                "layout": "Vizql",
                "columns": ["F1"],
                "rows":    ["F2"],
                "forecasts": {}, "legends": {}, "measureValues": [], "referenceLines": {},
                "marks": {
                    "fields": {}, "headers": {"encodings": [], "isAutomatic": True,
                                               "stack": {"isAutomatic": True, "isStacked": False}, "type": "Text"},
                    "panes": {"encodings": [], "isAutomatic": True,
                               "stack": {"isAutomatic": True, "isStacked": False}, "type": chart_type},
                },
                "style": {
                    "axis": {"fields": {}},
                    "encodings": {"fields": {"F2": {"defaults": {"format": {"numberFormatInfo": {
                        "decimalPlaces": 2, "displayUnits": "Auto", "includeThousandSeparator": False,
                        "negativeValuesFormat": "Auto", "prefix": "", "suffix": "", "type": "Number",
                    }}}}}},
                    "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                    "rows":    {"showDividerLine": False, "showLabels": True}},
                    "fit": "Entire",
                    "fonts": FONTS,
                    "headers": {
                        "columns": {"mergeRepeatedCells": True, "showIndex": False},
                        "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                        "rows": {"mergeRepeatedCells": True, "showIndex": False},
                    },
                    "lines": LINES,
                    "marks": {
                        "fields":  {},
                        "headers": _marks_headers_style(),
                        "panes": {
                            "color": {"color": ""}, "isAutomaticSize": True,
                            "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                            "range": {"reverse": False},
                            "size": {"isAutomatic": True, "type": "Pixel", "value": 13},
                        },
                    },
                    "referenceLines":    {},
                    "shading":           {"backgroundColor": BRAND["chart_bg"], "banding": {}},
                    "showDataPlaceholder": False,
                    "title":             {"isVisible": True},
                },
            },
            "view": {
                "label": "default", "name": f"{name}_default",
                "viewSpecification": {"sortOrders": {"columns": [], "fields": {}, "rows": []}},
            },
        }
        r = requests.post(
            f"{sf_instance}/services/data/v66.0/tableau/visualizations",
            headers=hdrs, params=VIZ_PARAMS, json=payload
        )
        if r.status_code in (200, 201):
            vn = r.json().get("name", name)
            print(f"  Viz created: {vn}")
            cp.setdefault("all_viz_apis", []).append(vn)
            save_checkpoint(cp)
            return vn
        print(f"  WARNING: Viz failed for {label}: {r.status_code} {r.text[:300]}")
        return None

    def fields_dict(measure_field, dim_field, is_date_dim=False):
        f1 = {"type": "Field", "displayCategory": "Discrete",  "role": "Dimension", "objectName": do_api, "fieldName": dim_field}
        f2 = {"type": "Field", "displayCategory": "Continuous", "role": "Measure",   "objectName": do_api, "fieldName": measure_field, "function": "Avg"}
        if is_date_dim:
            f1["function"] = "DatePartMonth"
        return {"F1": f1, "F2": f2}

    viz_api_names = [
        make_viz(f"{SLUG}_engagement_trend",   "At-Risk Engagement Rate — Trend",         fields_dict("engagement_rate",       "month_date",    is_date_dim=True),  "line", "month_date"),
        make_viz(f"{SLUG}_service_bar",        "Support Service Sessions by School",      fields_dict("service_sessions",      "school",         is_date_dim=False), "bar",  "school"),
        make_viz(f"{SLUG}_retention_trend",    "Retention Rate — Trend",                  fields_dict("retention_rate",        "month_date",    is_date_dim=True),  "line", "month_date"),
        make_viz(f"{SLUG}_warning_rate_bar",   "Academic Warning Rate by Risk Category",  fields_dict("academic_warning_rate", "risk_category", is_date_dim=False), "bar",  "risk_category"),
    ]

    # Dashboard
    metric_map = cp.get("metric_api_map", {})
    primary_metrics = [k for k, cfg in METRIC_CONFIG.items() if cfg["is_primary"]]

    COL_COUNT = 72
    METRICS_PER_ROW = 2
    metric_col_width = COL_COUNT // METRICS_PER_ROW
    widgets = {}

    for i, mtc_key in enumerate(primary_metrics):
        mtc_api = metric_map.get(mtc_key)
        if not mtc_api:
            continue
        k = f"metric_{i+1}"
        widgets[k] = {
            "actions": [], "name": k, "type": "metric",
            "source": {"name": mtc_api},
            "parameters": {
                "metricOption": {
                    "sdmApiName": sdm_api,
                    "layout": {"componentVisibility": {
                        "title": True, "value": True, "comparison": True,
                        "chart": True, "insights": True, "details": True,
                    }}
                },
                "receiveFilterSource": {"filterMode": "all", "widgetIds": []},
            }
        }

    VIZ_W = 35
    VIZ_H = 28
    for i, vapi in enumerate(viz_api_names):
        if not vapi:
            continue
        k  = f"visualization_{i+1}"
        ck = f"container_{i+1}"
        widgets[k]  = {"actions": [], "name": k,  "type": "visualization", "source": {"name": vapi}, "parameters": {"receiveFilterSource": {"filterMode": "all", "widgetIds": []}}}
        widgets[ck] = {"actions": [], "name": ck, "type": "container",     "parameters": {}}

    # Build page_widgets layout
    page_widgets = []
    metric_names_ordered = [k for k in [f"metric_{i+1}" for i in range(len(primary_metrics))] if k in widgets]
    for i, k in enumerate(metric_names_ordered):
        col_idx = i % METRICS_PER_ROW
        page_widgets.append({"name": k, "column": col_idx * metric_col_width, "row": 0, "colspan": metric_col_width, "rowspan": 15})

    layout_row = 15
    for i in range(len(viz_api_names)):
        col_start = (i % 2) * (VIZ_W + 2)
        row_start = layout_row + (i // 2) * VIZ_H
        ck = f"container_{i+1}"
        k  = f"visualization_{i+1}"
        if ck in widgets:
            page_widgets.append({"name": ck, "column": col_start,     "row": row_start,     "colspan": VIZ_W,     "rowspan": VIZ_H})
            page_widgets.append({"name": k,  "column": col_start + 1, "row": row_start + 1, "colspan": VIZ_W - 2, "rowspan": VIZ_H - 2})

    dash_payload = {
        "name":  f"{SLUG}_dashboard",
        "label": f"{COMPANY} — Student Retention Dashboard",
        "workspaceIdOrApiName": ws_api,
        "widgets": widgets,
        "layouts": [{
            "name": "default", "columnCount": COL_COUNT, "rowHeight": 10, "maxWidth": 1200,
            "style": {"backgroundColor": BRAND["dash_bg"], "cellSpacingX": 8, "cellSpacingY": 8, "gutterColor": BRAND["dash_bg"]},
            "pages": [{"name": str(uuid.uuid4()), "label": "Overview", "widgets": page_widgets}],
        }],
    }
    r = requests.post(
        f"{sf_instance}/services/data/v66.0/tableau/dashboards",
        headers=hdrs, params=VIZ_PARAMS, json=dash_payload
    )
    if r.status_code in (200, 201):
        dash_api = r.json().get("name", dash_payload["name"])
        print(f"  Dashboard created: {dash_api}")
        cp.setdefault("all_dash_apis", []).append(dash_api)
        save_checkpoint(cp)
    else:
        print(f"  WARNING: Dashboard creation failed: {r.status_code} {r.text[:400]}")
        dash_api = None

    cp["phase6_done"]    = True
    cp["viz_api_names"]  = viz_api_names
    cp["dash_api"]       = dash_api
    save_checkpoint(cp)
    return cp

# ── Phase 7 — Docs + Summary ──────────────────────────────────────────────────
def phase7_docs(cp):
    if cp.get("phase7_done"):
        print("\n── Phase 7: Docs [skipped — already done] ───────────────────────────")
        return cp

    print("\n── Phase 7: Writing demo guide + Concierge walkthrough ─────────────")

    ws_api  = cp.get("ws_api", SLUG)
    sdm_api = cp.get("sdm_api", "")
    sf_instance = cp.get("sf_instance", "")

    # Guide markdown
    guide_path = os.path.join(DEMO_DIR, f"{SLUG}_guide.md")
    with open(guide_path, "w") as f:
        f.write(f"""# {COMPANY} — Student Retention Demo Guide

**Use Case:** At-Risk Student Engagement Declining
**Persona:** VP of Student Affairs
**Platform:** Tableau Next + Salesforce Data Cloud
**Built:** {TIMESTAMP}

---

## The Story

Over the past 6 months, GWU's at-risk student engagement rate has dropped sharply — from ~72% to ~45%. At the same time, support service sessions have fallen 36%. The VP of Student Affairs is seeing early warning signs: academic warning rates are creeping up, average GPA among at-risk students is sliding, and advisors are taking longer to reach flagged students.

**The "uh oh" moment:** Two leading indicators — engagement rate and service utilization — are declining in tandem. If this continues, retention will follow. The data is showing the problem before it becomes a crisis.

---

## Demo Click Path

### 1. Open the workspace
- Navigate to Tableau Next → **{COMPANY} — {USE_CASE}** workspace
- Enable Analytics Agent Readiness if not already on (Data 360 → Semantic Model → Settings → toggle ON)

### 2. Lead with At-Risk Engagement Rate
- Open the **At-Risk Engagement Rate** metric tile
- Point out the sparkline: clear downward trend over the last 6 months
- *"We're reaching far fewer at-risk students than we were a year ago"*

### 3. Confirm with Support Service Utilization
- Open **Support Service Utilization** — sessions are down 36%
- *"And it's not just an engagement number — the actual service interactions are falling too"*

### 4. Drill into the supporting metrics
- Show **Retention Rate** beginning to dip — *"We haven't felt this in retention yet, but we will"*
- Show **Academic Warning Rate** rising — *"Warning flags are going up while engagement is going down — that's a dangerous combination"*
- Show **Days to First Outreach** increasing — *"Advisors are taking longer to reach students who need help"*

### 5. Use Concierge to go deeper (see walkthrough doc)
- Open the Concierge panel and paste the questions from the walkthrough
- Demonstrate how the AI synthesises insights across all metrics in natural language

---

## Dimensions Available
- **School** — Columbian College, School of Business, Elliott School, etc.
- **Risk Category** — Academic, Financial, Social-Emotional, First-Generation
- **Campus** — Foggy Bottom, Mount Vernon, Virginia Science & Technology

---

## Metric Reference

| Metric | Type | Signal | Direction |
|--------|------|--------|-----------|
| At-Risk Engagement Rate | Primary | −37% over 6 months | Down is bad |
| Support Service Utilization | Primary | −36% over 6 months | Down is bad |
| Retention Rate | Supporting | −13% over 6 months | Down is bad |
| Academic Warning Rate | Supporting | +12% over 6 months | Up is bad |
| Average GPA | Supporting | −10% over 6 months | Down is bad |
| Days to First Outreach | Supporting | +11% over 6 months | Up is bad |

---

## Post-Demo Checklist
- [ ] Enable Analytics Agent Readiness toggle in Data 360 → Semantic Model → Settings
- [ ] Confirm Concierge panel is accessible in the workspace
- [ ] Share walkthrough .docx with the SE running the demo
""")
    print(f"  Guide written: {guide_path}")

    # Concierge walkthrough .docx
    docx_path = os.path.join(DEMO_DIR, f"{SLUG}_concierge_walkthrough.docx")
    doc = Document()

    title = doc.add_heading(f"{COMPANY} — Student Retention", 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_heading("Concierge Demo Walkthrough", level=1)
    doc.add_paragraph(
        f"Persona: VP of Student Affairs | Platform: Tableau Next | Built: {TIMESTAMP}"
    )
    doc.add_paragraph(
        "Use the questions below in order. Each one is designed to reveal a layer of the story. "
        "Paste them directly into the Concierge chat panel."
    )

    prompts = [
        (
            "Opening — surface the primary signal",
            "What is the current at-risk student engagement rate, and how has it changed over the past six months?",
            "Expect Concierge to surface the ~37% decline. Let the audience absorb the number before moving on."
        ),
        (
            "Confirm with service utilization",
            "How have support service sessions trended over the same period?",
            "Reinforces the primary signal — both leading indicators are moving in the same direction."
        ),
        (
            "Connect to lagging indicator",
            "Is there any impact on student retention rates?",
            "Retention hasn't fully dropped yet — this is the 'we're heading toward a cliff' moment."
        ),
        (
            "Diagnose the cause",
            "Which schools or campuses are showing the largest decline in engagement rate?",
            "Lets the audience see that the problem is concentrated — not uniform. Creates urgency to act in specific areas."
        ),
        (
            "Operational drill-down",
            "How has the average days to first outreach changed, and is there a correlation with engagement rate?",
            "Shows the operational root cause — advisors are slower to reach students, and engagement is falling as a result."
        ),
        (
            "Academic consequences",
            "What is happening to academic warning rates among at-risk students?",
            "Closing the loop: less engagement → slower outreach → more academic warnings. The story arc is complete."
        ),
    ]

    for i, (section, prompt, talking_point) in enumerate(prompts, 1):
        doc.add_heading(f"{i}. {section}", level=2)
        p = doc.add_paragraph()
        p.add_run("Prompt: ").bold = True
        p.add_run(prompt)
        p2 = doc.add_paragraph()
        p2.add_run("Talking point: ").bold = True
        p2.add_run(talking_point)
        doc.add_paragraph()

    doc.add_heading("Setup Reminder", level=1)
    doc.add_paragraph(
        "Before demoing: Data 360 → Semantic Model → Settings → Analytics Agent Readiness → toggle ON. "
        "Without this, the Concierge panel will not appear."
    )

    # Business Preferences section
    business_prefs = (
        "# Context: This SDM tracks at-risk student engagement for George Washington University.\n"
        "# 'At-risk students' refers to students flagged in the early-alert risk identification system.\n"
        "# When asked about engagement, prioritize engagement_rate over service_sessions as the primary signal.\n"
        "# Risk Category breakdowns (Academic, Financial, Social-Emotional, First-Generation) are more diagnostic than Campus for root-cause analysis.\n"
        "# Days to First Outreach is an operational metric — increases indicate advisor capacity issues, not student behavior.\n"
        "# Academic Warning Rate is a lagging indicator; engagement_rate and service_sessions are the leading indicators.\n"
        "# When comparing time periods, default to the last 6 months vs. the prior 6 months.\n"
        "# Retention Rate should be interpreted as semester-over-semester, not year-over-year.\n"
        "# GPA in this dataset reflects at-risk students only, not the general student population.\n"
        "# School-level breakdowns are preferred over Campus-level when diagnosing engagement gaps."
    )

    doc.add_heading("Business Preferences (SDM)", level=1)
    doc.add_paragraph(
        "Copy the text below and paste it into your Semantic Data Model's Business Preferences field:\n"
        "Data 360 → Semantic Model → [your SDM] → AI Optimization → Manage Business Preferences"
    )
    doc.add_paragraph(business_prefs)

    doc.save(docx_path)
    print(f"  Walkthrough written: {docx_path}")

    cp["phase7_done"]         = True
    cp["guide_path"]          = guide_path
    cp["docx_path"]           = docx_path
    cp["business_preferences"] = business_prefs
    save_checkpoint(cp)
    return cp

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    print(f"\n{'='*70}")
    print(f"  Analytics Builder — {COMPANY}")
    print(f"  Use Case: {USE_CASE}")
    print(f"  Persona:  VP of Student Affairs")
    print(f"  Output:   Tableau Next")
    print(f"{'='*70}")

    cp = load_checkpoint()

    df = generate_data()

    sf_token, sf_instance, dc_token, dc_domain, connector_name, connector_id = get_tokens()
    cp["sf_instance"] = sf_instance

    cp = phase2_schema_streams(sf_token, sf_instance, connector_name, connector_id, cp)
    cp = phase3_bulk_ingest(df, dc_token, dc_domain, connector_name, cp)
    cp = phase4_workspace_sdm(sf_token, sf_instance, cp)
    cp = phase5_metrics(sf_token, sf_instance, cp)
    cp = phase6_vizzes_dashboard(sf_token, sf_instance, cp)
    cp = phase7_docs(cp)

    # Final summary
    print(f"\n{'='*70}")
    print(f"  BUILD COMPLETE")
    print(f"{'='*70}")
    print(f"\n  Company:    {COMPANY}")
    print(f"  Workspace:  {cp.get('ws_api')}")
    print(f"  SDM:        {cp.get('sdm_api')}")
    print(f"  Dashboard:  {cp.get('dash_api')}")
    print(f"\n  Metrics created:")
    for k, v in cp.get("metric_api_map", {}).items():
        label = METRIC_CONFIG[k]["label"]
        print(f"    • {label} ({v})")
    print(f"\n  Visualizations:")
    for name in cp.get("viz_api_names", []):
        if name:
            print(f"    • {name}")
    print(f"\n  Files:")
    print(f"    Guide:       {cp.get('guide_path')}")
    print(f"    Walkthrough: {cp.get('docx_path')}")
    print(f"\n  Tableau Next URL:")
    print(f"    {sf_instance}/tableau")
    print(f"\n  ⚠  IMPORTANT: Enable Analytics Agent Readiness")
    print(f"     Data 360 → Semantic Model → Settings → Analytics Agent Readiness → ON")
    print(f"\n  ⚠  IMPORTANT: Add Business Preferences to your SDM")
    print(f"     1. Data 360 → Semantic Model → {cp.get('sdm_api', '[your SDM]')}")
    print(f"     2. AI Optimization → Manage Business Preferences")
    print(f"     3. Open the walkthrough .docx — the 'Business Preferences (SDM)' section")
    print(f"        has the full text ready to copy and paste.")
    bprefs = cp.get("business_preferences", "")
    if bprefs:
        print(f"\n  Business Preferences text (also in .docx):")
        for line in bprefs.splitlines():
            print(f"    {line}")
    print(f"\n{'='*70}\n")

if __name__ == "__main__":
    main()
