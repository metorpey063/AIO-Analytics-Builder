# Engine — Member CSAT Concierge Demo Walkthrough

**Persona:** SVP Operations  
**Story:** CSAT scores declining over the last 6 months — what's driving it, where is it worst, and what do we do?

---

## Setup

1. Open the **Engine Member CSAT Dashboard** in Tableau Next
2. Open the **Concierge** panel (chat icon, top right)
3. Make sure the SDM shown is **Engine Member CSAT**

---

## Part 1 — Orient the audience on the dashboard

> *"Before we ask any questions, walk the audience through what they're looking at."*

Point to the metric tiles:
- **Avg CSAT Score** — overall member satisfaction, 1–5 scale. Healthy is above 4.2.
- **Avg NPS Score** — net promoter score, industry-good above 40.
- **Issues Reported** — total support tickets opened.
- **Avg Resolution Hours** — how long it takes to close a ticket. Over 12 hours is slow.
- **Platform Booking Rate** — % of bookings made through Engine's platform. Decline = members going elsewhere.
- **Survey Response Rate** — % of surveys returned. Low = data may be less reliable.

> *"Notice the sparklines on each card — CSAT and NPS are both trending down over the last 6 months while Issues and Resolution Hours are trending up. That's our story."*

---

## Part 2 — Concierge: Surface the trend

**Ask Concierge:**
> "How has our CSAT score trended over the last 6 months?"

*What to expect:* A time-series breakdown confirming the downtrend with the magnitude of decline.

**Follow-up:**
> "Which segment is most affected?"

*What to expect:* Enterprise called out as underperforming relative to SMB and Consumer — this is the engineered signal in the data.

---

## Part 3 — Concierge: Dig into the hidden driver

**Ask Concierge:**
> "What should I be worried about?"

*What to expect:* Concierge cross-references CSAT decline with high Issues Reported — surfaces Enterprise + a specific region (West or Northeast depending on your data) as the highest-risk combination.

**Follow-up:**
> "Show me CSAT by region for the Enterprise segment"

*What to expect:* A breakdown revealing which region is pulling the score down.

**Ask:**
> "What is driving the CSAT decline in that region?"

*What to expect:* Resolution time and platform booking rate called out as the two primary contributing factors per the business preferences.

---

## Part 4 — Concierge: Quantify the risk

**Ask Concierge:**
> "How does our resolution time compare to the healthy threshold?"

*What to expect:* Avg Resolution Hours surfaced against the 12-hour benchmark — Concierge knows this threshold from the business preferences.

**Ask:**
> "Is our platform booking rate declining in the Enterprise segment?"

*What to expect:* Confirmation with trend data — frames it as a flight-to-off-platform risk signal.

---

## Part 5 — Close with action

**Ask Concierge:**
> "What should the SVP Operations prioritize to improve CSAT in the next quarter?"

*What to expect:* Three-part recommendation grounded in the data:
1. Reduce resolution time in the affected region (operational fix)
2. Drive platform adoption in Enterprise (product/sales fix)
3. Increase survey response rate to improve data confidence (measurement fix)

---

## Key talking points for the demo

- **"The dashboard shows you the what — Concierge shows you the why and the so what."**
- **"The business preferences are what make this contextual.** The agent knows that Enterprise is your highest-value segment, that a score below 3.8 is a problem, and that platform booking rate is a leading indicator of churn — without you having to explain that every time."
- **"This isn't a search engine — it's an analyst who already knows your business."**

---

## Suggested Q&A prompts for live audience interaction

- *"Ask it something you'd normally ask your analyst on a Monday morning."*
- *"Ask it which region you should investigate first."*
- *"Ask it to compare Enterprise CSAT this quarter to the same period last year."*
- *"Ask it what would happen to overall CSAT if we fixed the resolution time issue."*
