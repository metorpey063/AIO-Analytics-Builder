# Engine — Member CSAT Demo Guide

**Persona:** SVP Operations
**Story:** Member CSAT scores declining over the last 6 months, driven by hotel quality issues and booking friction
**Built:** 2026-05-07 08:04

## The Story

Member CSAT scores at Engine have been declining for the past 6 months.
Enterprise members are most affected. Issues reported are up, resolution
times are climbing, and off-platform booking rates are creeping upward —
suggesting friction is pushing members to book outside the platform.

## Key Metrics

| Metric | Trend |
|--------|-------|
| Avg CSAT Score | ↓ Declining (from ~4.3 to ~3.9) |
| Net Promoter Score | ↓ Declining |
| Issues Reported | ↑ Increasing |
| Avg Resolution Hours | ↑ Increasing |
| Platform Booking Rate | ↓ Declining |

## Demo Talking Points

1. **Open CSAT Trend** — show the 6-month decline, segment breakdown
2. **Enterprise impact** — Enterprise segment hit hardest (highest CSAT to start, biggest drop)
3. **Issues & resolution** — issues up 80%, resolution time up 6+ hrs
4. **Platform leakage** — 12% drop in platform booking rate = members booking elsewhere

## Concierge Prompts

- "What's happening with member CSAT?"
- "Which segments have the lowest CSAT scores?"
- "How has the platform booking rate changed this year?"
- "What's driving the increase in issues reported?"

## Assets

- Workspace: ``
- SDM: ``
- Dashboard: Engine Member CSAT Dashboard

## Workspace URL

N/A — Pulse only build

## Post-Build Step

N/A — Pulse only build
