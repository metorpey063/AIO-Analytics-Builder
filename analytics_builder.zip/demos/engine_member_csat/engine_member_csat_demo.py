#!/usr/bin/env python3
"""
Engine — Member CSAT Downtrend Demo
Persona: SVP Operations
Output: Tableau Next (Salesforce Data Cloud)

Signal: Member CSAT scores declining over the past 6 months,
        driven by hotel quality issues and booking friction.
"""

import json, sys, uuid, os, requests, subprocess, tempfile, shutil, zipfile
import pandas as pd
import numpy as np
import time as _time
from datetime import date, datetime as _dt
from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from xml.etree import ElementTree as ET

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

# ── Demo parameters ────────────────────────────────────────────────────────────
COMPANY_NAME  = "Engine"
USE_CASE      = "Member CSAT"
PERSONA       = "SVP Operations"
STORY         = "Member CSAT scores declining over the last 6 months, driven by hotel quality issues and booking friction"
SIGNAL_ONSET  = -6

company_slug   = "engine"
use_case_slug  = "member_csat"
WORKSPACE_NAME = f"{company_slug}_{use_case_slug}"
SDM_NAME       = WORKSPACE_NAME
TODAY          = date.today()
START_DATE     = date(TODAY.year - 2, TODAY.month, 1)
TIMESTAMP      = _dt.now().strftime("%Y-%m-%d %H:%M")

# ── Output mode selection ──────────────────────────────────────────────────────
print(f"\n{'='*66}")
print(f"  ENGINE — MEMBER CSAT DEMO BUILDER")
print(f"  {'─'*62}")
print(f"  Which output would you like to build?")
print(f"")
print(f"    1. pulse  — Tableau Pulse metrics")
print(f"    2. next   — Tableau Next + Data Cloud dashboard")
print(f"    3. both   — Build both Pulse and Next")
print(f"    4. csv    — CSV export only")
print(f"  {'─'*62}")
_mode_input = input("  Enter choice (1/2/3/4 or pulse/next/both/csv): ").strip().lower()
if _mode_input in ("1", "pulse"):   BUILD_MODE = "pulse"
elif _mode_input in ("2", "next"):  BUILD_MODE = "next"
elif _mode_input in ("3", "both"):  BUILD_MODE = "both"
elif _mode_input in ("4", "csv"):   BUILD_MODE = "csv"
else:
    print(f"  Unrecognised input '{_mode_input}' — defaulting to 'both'")
    BUILD_MODE = "both"
print(f"\n  Building: {BUILD_MODE.upper()}\n")

BUILD_PULSE = BUILD_MODE in ("pulse", "both")
BUILD_NEXT  = BUILD_MODE in ("next",  "both")
BUILD_CSV   = BUILD_MODE == "csv"

# ── Diagnostics ────────────────────────────────────────────────────────────────
_SCRIPT_START = _time.time()
def _ts(): return _dt.now().strftime("%H:%M:%S")
def ok(m):   print(f"  [{_ts()}] ✅ {m}")
def info(m): print(f"  [{_ts()}] ℹ️  {m}")
def warn(m): print(f"  [{_ts()}] ⚠️  {m}")
def die(m, r=None):
    print(f"\n  ❌ FAILED: {m}")
    if r is not None: print(f"  HTTP {r.status_code}: {r.text[:600]}")
    sys.exit(1)

def phase(n, total, label):
    print(f"\n[{n}/{total}] {label}...")

def mac_notify(title, message):
    try:
        script = f'display notification "{message}" with title "{title}" sound name "Glass"'
        with tempfile.NamedTemporaryFile(mode="w", suffix=".applescript", delete=False) as f:
            f.write(script); fpath = f.name
        subprocess.run(["osascript", fpath], check=False, capture_output=True)
        os.unlink(fpath)
    except Exception:
        pass

# ── Auth — load profiles based on mode ────────────────────────────────────────
from connections import load_config, get_all_tokens, get_tableau_token, tableau_headers, sf_headers, dc_headers
import tableauserverclient as TSC

if BUILD_NEXT or BUILD_MODE == "csv":
    config_next = load_config()   # active profile = torp_s_engine_test (SF/DC)
    sf = config_next["salesforce"]
    sf_token, sf_instance, dc_token, dc_domain = get_all_tokens(config_next)
    SF_HDRS   = sf_headers(sf_token)
    DC_HDRS   = dc_headers(dc_token)
    BASE_SF   = f"{sf_instance}/services/data/v62.0"
    BASE_SEM  = f"{sf_instance}/services/data/v65.0"
    BASE_SEM66 = f"{sf_instance}/services/data/v66.0"
    BASE_VIZ  = f"{sf_instance}/services/data/v66.0"
    CONN_SF_ID = sf["connector_sf_id"]
    CONN_UUID  = sf.get("connector_uuid_name", sf.get("ingestion_connector_name", ""))

if BUILD_PULSE:
    config_pulse = load_config("torpey_demo_org")
    tc = config_pulse["tableau"]
    TC_SERVER_URL = tc["server_url"].rstrip("/")

# ── Deployment plan ────────────────────────────────────────────────────────────
TOTAL_PHASES = (4 if BUILD_PULSE else 0) + (10 if BUILD_NEXT else 0) + (1 if BUILD_CSV else 0)
_phase_counter = [0]
def phase(label, total=None):
    _phase_counter[0] += 1
    n = _phase_counter[0]
    t = total or TOTAL_PHASES
    print(f"\n[{n}/{t}] {label}...")

print(f"{'='*66}")
print(f"  DEPLOYMENT PLAN — {COMPANY_NAME} — {USE_CASE} — {BUILD_MODE.upper()}")
print(f"  {'─'*62}")
if BUILD_PULSE:
    print(f"  Pulse Phase 1   Generate synthetic data    ~5s")
    print(f"  Pulse Phase 2   Publish .hyper datasource  ~15s")
    print(f"  Pulse Phase 3   Create Pulse metrics       ~30s")
    print(f"  Pulse Phase 4   Create group + subscribe   ~10s")
if BUILD_NEXT:
    print(f"  Next  Phase 1   Generate synthetic data    ~5s  (shared)")
    print(f"  Next  Phase 2   Register DC schema+streams ~15s")
    print(f"  Next  Phase 3   Wait for DLO ACTIVE        ~30–120s")
    print(f"  Next  Phase 4   Bulk ingest data           ~30s")
    print(f"  Next  Phase 5   Wait for jobs              ~60s")
    print(f"  Next  Phase 6   Create workspace           ~5s")
    print(f"  Next  Phase 7   Build SDM                  ~30s")
    print(f"  Next  Phase 8   Calculated fields+metrics  ~30s")
    print(f"  Next  Phase 9   Create visualizations      ~20s")
    print(f"  Next  Phase 10  Build dashboard            ~10s")
print(f"  {'─'*62}")
print(f"{'='*66}\n")

# ── PHASE 1: Generate synthetic data ──────────────────────────────────────────
phase("Generating synthetic data")

np.random.seed(42)
months = pd.date_range(START_DATE, TODAY, freq="MS")

categories = ["Hotel Quality", "Booking Experience", "Support", "Pricing", "App/Digital"]
segments   = ["Enterprise", "SMB", "Mid-Market"]
regions    = ["West", "Central", "East", "International"]

# Dimension: member segments
segment_rows = []
for i, seg in enumerate(segments):
    segment_rows.append({
        "segment_id": f"SEG{i+1:02d}",
        "segment_name": seg,
        "member_count": [12500, 8200, 4100][i],
        "avg_spend_per_trip": [380.0, 210.0, 310.0][i],
    })
df_segments = pd.DataFrame(segment_rows)

def signal_ramp(d, onset=SIGNAL_ONSET, duration=6):
    mft = (d.year - TODAY.year) * 12 + (d.month - TODAY.month)
    if mft <= onset: return 0.0
    return min(1.0, (mft - onset) / duration)

# Fact: monthly CSAT + operational metrics per segment
fact_rows = []
for month in months:
    for seg in segment_rows:
        signal = signal_ramp(month)
        seg_id = seg["segment_id"]

        # PRIMARY: CSAT — strong, clean decline (~0.55 pts = ~13% drop). This is the story.
        base_csat = {"SEG01": 4.35, "SEG02": 4.15, "SEG03": 4.25}[seg_id]
        csat_score = round(base_csat - (signal * 0.55) + np.random.uniform(-0.05, 0.05), 2)
        csat_score = max(1.0, min(5.0, csat_score))

        # SUPPORTING: NPS — softer correlated drift, answers "is loyalty also affected?"
        base_nps = {"SEG01": 52, "SEG02": 42, "SEG03": 47}[seg_id]
        nps_score = round(base_nps - (signal * 9) + np.random.uniform(-3, 3), 1)

        # SUPPORTING: Survey volume — slight response-rate drop, context only
        surveys_sent = int(seg["member_count"] * 0.15 + np.random.randint(-50, 50))
        response_rate = round(0.28 - (signal * 0.03) + np.random.uniform(-0.02, 0.02), 3)
        surveys_completed = int(surveys_sent * response_rate)

        # SUPPORTING: Resolution metrics — moderate rise, explains the CSAT drop when asked
        issues_reported = int(100 + (signal * 55) + np.random.randint(-10, 10))
        resolved_same_day = round(0.72 - (signal * 0.10) + np.random.uniform(-0.03, 0.03), 3)
        avg_resolution_hours = round(8.5 + (signal * 4.5) + np.random.uniform(-0.5, 0.5), 1)

        # SUPPORTING: Platform booking rate — subtle drift, a leading indicator not the headline
        total_bookings = int(seg["member_count"] * 0.08 + np.random.randint(-20, 20))
        platform_rate = round(0.87 - (signal * 0.07) + np.random.uniform(-0.02, 0.02), 3)

        fact_rows.append({
            "record_id": f"{seg_id}_{month.strftime('%Y%m')}",
            "date": str(month.date()),
            "month_key": int(month.strftime("%Y%m")),
            "year": month.year,
            "quarter": ((month.month - 1) // 3) + 1,
            "month_name": month.strftime("%B"),
            "segment_id": seg_id,
            "segment_name": seg["segment_name"],
            "region": regions[hash(seg_id + month.strftime("%Y%m")) % 4],
            "csat_score": csat_score,
            "nps_score": nps_score,
            "surveys_sent": surveys_sent,
            "surveys_completed": surveys_completed,
            "response_rate": response_rate,
            "issues_reported": issues_reported,
            "resolved_same_day_rate": resolved_same_day,
            "avg_resolution_hours": avg_resolution_hours,
            "total_bookings": total_bookings,
            "platform_booking_rate": platform_rate,
        })

df_fact = pd.DataFrame(fact_rows)
ok(f"Fact table: {len(df_fact)} rows ({len(segment_rows)} segments × {len(months)} months)")
ok(f"Dimension table: {len(df_segments)} member segments")

# ── PULSE PHASES ───────────────────────────────────────────────────────────────
pulse_project_name = None
pulse_group_name   = None
pulse_metric_count = 0

if BUILD_PULSE:
    from tableauhyperapi import HyperProcess, Telemetry, Connection, TableDefinition, SqlType, TableName, Inserter, CreateMode, SchemaName, Date, NOT_NULLABLE

    phase("Publishing datasource to Tableau Cloud")

    tc_server, tc_auth_token, tc_site_id = get_tableau_token(config_pulse)
    tc_pulse_base = f"{TC_SERVER_URL}/api/-/pulse"
    tc_base_url   = f"{TC_SERVER_URL}/api/{tc_server.version}/sites/{tc_site_id}"
    tc_hdrs       = {"X-Tableau-Auth": tc_auth_token, "Accept": "application/json"}
    tc_hdrs_create = {**tc_hdrs, "Content-Type": "application/vnd.tableau.metricqueryservice.v1.CreateDefinitionRequest+json"}
    tc_hdrs_xml    = {**tc_hdrs, "Content-Type": "application/xml", "Accept": "application/xml"}

    # Clean up previous Engine Pulse projects + definitions
    all_projects, _ = tc_server.projects.get()
    for p in all_projects:
        if p.name.startswith("Engine |"):
            tc_server.projects.delete(p.id)
            info(f"Deleted old project: {p.name}")

    existing_defs = requests.get(f"{tc_pulse_base}/definitions?page_size=50", headers=tc_hdrs).json().get("definitions", [])
    for d in existing_defs:
        if d.get("metadata", {}).get("name", "").startswith("Engine"):
            requests.delete(f"{tc_pulse_base}/definitions/{d['metadata']['id']}", headers=tc_hdrs)
            info(f"Deleted old definition: {d['metadata']['name']}")

    # Create project
    pulse_project_name = f"Engine | {TIMESTAMP}"
    proj = tc_server.projects.create(TSC.ProjectItem(name=pulse_project_name))
    ok(f"Project created: {pulse_project_name}")

    # Write .hyper with title-case column names matching crescendo pattern
    # All numeric columns use SqlType.double() to satisfy Pulse API; date as SqlType.date()
    PULSE_DS_NAME = "Engine - Member CSAT"
    hyper_path = Path(tempfile.mkdtemp()) / "engine_member_csat.hyper"

    with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hyper:
        with Connection(hyper.endpoint, str(hyper_path), CreateMode.CREATE_AND_REPLACE) as conn:
            conn.catalog.create_schema_if_not_exists("Extract")
            tbl = TableDefinition(TableName("Extract", "Extract"), [
                TableDefinition.Column("Record ID",             SqlType.text(),   NOT_NULLABLE),
                TableDefinition.Column("Date",                  SqlType.date(),   NOT_NULLABLE),
                TableDefinition.Column("Segment ID",            SqlType.text(),   NOT_NULLABLE),
                TableDefinition.Column("Segment",               SqlType.text(),   NOT_NULLABLE),
                TableDefinition.Column("Region",                SqlType.text(),   NOT_NULLABLE),
                TableDefinition.Column("CSAT Score",            SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("NPS Score",             SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Surveys Sent",          SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Survey Response Rate",  SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Issues Reported",       SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Avg Resolution Hours",  SqlType.double(), NOT_NULLABLE),
                TableDefinition.Column("Platform Booking Rate", SqlType.double(), NOT_NULLABLE),
            ])
            conn.catalog.create_table(tbl)
            col_names = [c.name.unescaped for c in tbl.columns]
            col_map = {
                "Record ID":             "record_id",
                "Date":                  "date",
                "Segment ID":            "segment_id",
                "Segment":               "segment_name",
                "Region":                "region",
                "CSAT Score":            "csat_score",
                "NPS Score":             "nps_score",
                "Surveys Sent":          "surveys_sent",
                "Survey Response Rate":  "response_rate",
                "Issues Reported":       "issues_reported",
                "Avg Resolution Hours":  "avg_resolution_hours",
                "Platform Booking Rate": "platform_booking_rate",
            }
            with Inserter(conn, tbl) as ins:
                for _, row in df_fact.iterrows():
                    d = row["date"] if hasattr(row["date"], "year") else _dt.strptime(str(row["date"]), "%Y-%m-%d").date()
                    ins.add_row([
                        str(row["record_id"]),
                        Date(d.year, d.month, d.day),
                        str(row["segment_id"]),
                        str(row["segment_name"]),
                        str(row["region"]),
                        float(row["csat_score"]),
                        float(row["nps_score"]),
                        float(row["surveys_sent"]),
                        float(row["response_rate"]),
                        float(row["issues_reported"]),
                        float(row["avg_resolution_hours"]),
                        float(row["platform_booking_rate"]),
                    ])
                ins.execute()

    ds_item = TSC.DatasourceItem(project_id=proj.id, name=PULSE_DS_NAME)
    ds_item = tc_server.datasources.publish(ds_item, str(hyper_path), mode=TSC.Server.PublishMode.Overwrite)
    PULSE_DS_LUID = ds_item.id
    ok(f"Datasource published: {PULSE_DS_NAME} (luid: {PULSE_DS_LUID})")

    # ── Create Pulse metrics ──────────────────────────────────────────────────
    phase("Creating Pulse metrics + group")

    PULSE_METRICS = [
        ("Engine Avg CSAT Score",        "Avg member satisfaction (1–5). Healthy above 4.2.",        "CSAT Score",            "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_NUMBER",   "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Engine Avg NPS Score",         "Net Promoter Score. Industry-good above 40.",              "NPS Score",             "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_NUMBER",   "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Engine Issues Reported",       "Total support tickets opened.",                            "Issues Reported",       "AGGREGATION_SUM",     "NUMBER_FORMAT_TYPE_NUMBER",   "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Engine Avg Resolution Hours",  "Hours to resolve a ticket. Over 12 hrs is slow.",         "Avg Resolution Hours",  "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_NUMBER",   "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Engine Platform Booking Rate", "% of bookings via Engine's platform.",                    "Platform Booking Rate", "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_PERCENT",  "SENTIMENT_TYPE_UP_IS_GOOD"),
        ("Engine Survey Response Rate",  "% of surveys returned. Below 20% = data unreliable.",     "Survey Response Rate",  "AGGREGATION_AVERAGE", "NUMBER_FORMAT_TYPE_PERCENT",  "SENTIMENT_TYPE_UP_IS_GOOD"),
    ]

    pulse_metric_ids = []
    for name, desc, field, agg, fmt, sentiment in PULSE_METRICS:
        payload = {
            "name": name,
            "specification": {
                "datasource": {"id": PULSE_DS_LUID},
                "basic_specification": {
                    "measure": {"field": field, "aggregation": agg},
                    "time_dimension": {"field": "Date"},
                    "filters": [],
                },
                "is_running_total": False,
            },
            "extension_options": {
                "allowed_dimensions": ["Segment", "Region"],
                "allowed_granularities": ["GRANULARITY_BY_MONTH", "GRANULARITY_BY_QUARTER", "GRANULARITY_BY_YEAR"],
                "offset_from_today": 1,
                "correlation_candidate_definition_ids": [],
                "use_dynamic_offset": False,
            },
            "representation_options": {"type": fmt, "sentiment_type": sentiment},
            "insights_options": {"show_insights": True},
            "comparisons": {"comparisons": [{"compare_config": {"comparison": "TIME_COMPARISON_PREVIOUS_PERIOD"}, "index": 0}]},
            "certification": {"is_certified": False},
            "datasource_goals": [],
            "related_links": [],
        }
        r = requests.post(f"{tc_pulse_base}/definitions", headers=tc_hdrs_create, json=payload)
        if r.status_code in (200, 201):
            def_id = r.json()["definition"]["metadata"]["id"]
            r2 = requests.get(f"{tc_pulse_base}/definitions/{def_id}/metrics", headers=tc_hdrs)
            ml = r2.json().get("metrics", []) if r2.ok else []
            if ml:
                mid = ml[0]["id"]
                pulse_metric_ids.append({"name": name, "metric_id": mid})
                ok(f"Pulse metric: {name}")
            else:
                warn(f"Pulse metric created but no metric_id: {name}")
        else:
            warn(f"Pulse metric failed: {name} — {r.status_code} {r.text[:200]}")

    pulse_metric_count = len(pulse_metric_ids)

    # ── Create group + subscribe ──────────────────────────────────────────────
    pulse_group_name = f"Engine | {TIMESTAMP}"
    r = requests.post(
        f"{tc_base_url}/groups", headers=tc_hdrs_xml,
        data=f'<?xml version="1.0" encoding="UTF-8"?><tsRequest><group name="{pulse_group_name}"/></tsRequest>'.encode()
    )
    if r.ok:
        root = ET.fromstring(r.content)
        grp = root.find(".//{http://tableau.com/api}group")
        if grp is None:
            grp = root.find(".//group")
        tc_group_id = grp.get("id") if grp is not None else None
        ok(f"Group created: {pulse_group_name} ({tc_group_id})")

        for m in pulse_metric_ids:
            sub = {"metric_id": m["metric_id"], "followers": [{"group_id": tc_group_id}]}
            requests.post(f"{tc_pulse_base}/subscriptions:batchCreate", headers=tc_hdrs, json=sub)
        ok(f"Group subscribed to {pulse_metric_count} metrics")
    else:
        warn(f"Group creation failed: {r.status_code} {r.text[:200]}")

    tc_server.auth.sign_out()


# ── NEXT PHASES ────────────────────────────────────────────────────────────────
if BUILD_NEXT:

    # ── PHASE 2: Register DC schema + create streams ──────────────────────────
    phase("Registering Data Cloud schema + streams")

    r = requests.get(f"{BASE_SF}/ssot/connections/{CONN_SF_ID}/schema", headers=SF_HDRS)
    if not r.ok:
        die("Failed to fetch existing schema", r)
    existing_schemas = r.json().get("schemas", [])

    def clean_schema(s):
        clean = {k: s[k] for k in ("name", "label", "schemaType") if k in s}
        clean["fields"] = [
            {k: f[k] for k in ("name", "label", "dataType") if k in f}
            for f in s.get("fields", [])
        ]
        return clean

    cleaned_existing = [clean_schema(s) for s in existing_schemas]

    FACT_SCHEMA_NAME = f"{company_slug}_Fact_Member_CSAT"
    DIM_SCHEMA_NAME  = f"{company_slug}_Dim_Segment"

    new_schemas = [
        {
            "name": FACT_SCHEMA_NAME,
            "label": FACT_SCHEMA_NAME,
            "schemaType": "IngestApi",
            "fields": [
                {"name": "record_id",                "label": "record_id",                "dataType": "Text"},
                {"name": "date",                     "label": "date",                     "dataType": "Date"},
                {"name": "month_key",                "label": "month_key",                "dataType": "Number"},
                {"name": "year",                     "label": "year",                     "dataType": "Number"},
                {"name": "quarter",                  "label": "quarter",                  "dataType": "Number"},
                {"name": "month_name",               "label": "month_name",               "dataType": "Text"},
                {"name": "segment_id",               "label": "segment_id",               "dataType": "Text"},
                {"name": "segment_name",             "label": "segment_name",             "dataType": "Text"},
                {"name": "region",                   "label": "region",                   "dataType": "Text"},
                {"name": "csat_score",               "label": "csat_score",               "dataType": "Number"},
                {"name": "nps_score",                "label": "nps_score",                "dataType": "Number"},
                {"name": "surveys_sent",             "label": "surveys_sent",             "dataType": "Number"},
                {"name": "surveys_completed",        "label": "surveys_completed",        "dataType": "Number"},
                {"name": "response_rate",            "label": "response_rate",            "dataType": "Number"},
                {"name": "issues_reported",          "label": "issues_reported",          "dataType": "Number"},
                {"name": "resolved_same_day_rate",   "label": "resolved_same_day_rate",   "dataType": "Number"},
                {"name": "avg_resolution_hours",     "label": "avg_resolution_hours",     "dataType": "Number"},
                {"name": "total_bookings",           "label": "total_bookings",           "dataType": "Number"},
                {"name": "platform_booking_rate",    "label": "platform_booking_rate",    "dataType": "Number"},
            ]
        },
        {
            "name": DIM_SCHEMA_NAME,
            "label": DIM_SCHEMA_NAME,
            "schemaType": "IngestApi",
            "fields": [
                {"name": "segment_id",         "label": "segment_id",         "dataType": "Text"},
                {"name": "segment_name",       "label": "segment_name",       "dataType": "Text"},
                {"name": "member_count",       "label": "member_count",       "dataType": "Number"},
                {"name": "avg_spend_per_trip", "label": "avg_spend_per_trip", "dataType": "Number"},
            ]
        },
    ]

    merged = {s["name"]: s for s in cleaned_existing}
    for s in new_schemas:
        merged[s["name"]] = s

    r = requests.put(f"{BASE_SF}/ssot/connections/{CONN_SF_ID}/schema",
                     headers=SF_HDRS, json={"schemas": list(merged.values())})
    if not r.ok:
        die("Failed to register schema", r)
    ok(f"Schema registered: {[s['name'] for s in new_schemas]}")

    created_streams = {}
    for schema in new_schemas:
        obj_name    = schema["name"]
        stream_name = f"demo_{obj_name.lower()}"[:40]
        is_fact     = "Fact" in obj_name
        pk_field    = "record_id" if is_fact else "segment_id"

        payload = {
            "name": stream_name,
            "label": stream_name.replace("_", " ").title(),
            "datasource": sf.get("ingestion_connector_name", "analytics_builder_demo")[:10],
            "datastreamType": "INGESTAPI",
            "connectorInfo": {
                "connectorType": "IngestApi",
                "connectorDetails": {"name": CONN_UUID, "events": [obj_name]}
            },
            "dataLakeObjectInfo": {
                "label": stream_name.replace("_", " ").title(),
                "category": "Other",
                "dataspaceInfo": [{"name": "default"}],
                "dataLakeFieldInputRepresentations": [
                    {"name": pk_field, "label": pk_field, "dataType": "Text", "isPrimaryKey": True}
                ],
                "eventDateTimeFieldName": "",
                "recordModifiedFieldName": ""
            },
            "mappings": []
        }

        r = requests.post(f"{BASE_SF}/ssot/data-streams", headers=SF_HDRS, json=payload)
        if r.status_code in (200, 201):
            full_name = r.json().get("name")
            created_streams[obj_name] = full_name
            ok(f"Stream created: {full_name}")
        elif "already in use" in r.text.lower() or "already exists" in r.text.lower():
            info(f"Stream exists for {obj_name} — discovering...")
            r2 = requests.get(f"{BASE_SF}/ssot/data-streams",
                              headers=SF_HDRS, params={"connectorId": CONN_SF_ID, "limit": 200})
            for ds_item in r2.json().get("dataStreams", []):
                if obj_name.lower() in ds_item.get("name", "").lower():
                    created_streams[obj_name] = ds_item["name"]
                    ok(f"Found existing: {ds_item['name']}")
                    break
            if obj_name not in created_streams:
                die(f"Stream exists but could not be found for {obj_name}")
        else:
            die(f"Failed to create stream for {obj_name}", r)

    # ── PHASE 3: Wait for DLO ACTIVE ──────────────────────────────────────────
    phase("Waiting for DLO ACTIVE")

    def wait_dlo_active(stream_name, timeout=300):
        start = _time.time()
        while _time.time() < start + timeout:
            r = requests.get(f"{BASE_SF}/ssot/data-streams/{stream_name}", headers=SF_HDRS)
            if r.ok:
                dlo_info = r.json().get("dataLakeObjectInfo", {})
                if dlo_info.get("status", "").upper() == "ACTIVE" and dlo_info.get("name"):
                    ok(f"DLO ACTIVE: {dlo_info['name']}  ({int(_time.time()-start)}s)")
                    return dlo_info["name"]
            elapsed = int(_time.time() - start)
            print(f"\r  ⏳ Waiting for DLO ACTIVE ({stream_name})... {elapsed}s", end="", flush=True)
            _time.sleep(10)
        die(f"Timeout waiting for DLO ACTIVE: {stream_name}")

    FACT_DLO = wait_dlo_active(created_streams[FACT_SCHEMA_NAME])
    DIM_DLO  = wait_dlo_active(created_streams[DIM_SCHEMA_NAME])

    info("Waiting 30s for bulk API to recognize new schemas...")
    _time.sleep(30)

    # ── PHASE 4: Bulk ingest ───────────────────────────────────────────────────
    phase("Submitting bulk ingest jobs")

    DC_INGEST_BASE = f"https://{dc_domain}"

    def df_to_csv(df):
        return df.to_csv(index=False)

    def _find_open_job(schema_name):
        hdrs = {"Authorization": f"Bearer {dc_token}", "Content-Type": "application/json"}
        r = requests.get(f"{DC_INGEST_BASE}/api/v1/ingest/jobs", headers=hdrs)
        if not r.ok:
            return None
        jobs = r.json().get("data", [])
        for j in jobs:
            if j.get("object") == schema_name and j.get("state") in ("Open", "UploadComplete", "InProgress"):
                return j
        return None

    def bulk_ingest(df, schema_name, label, max_retries=10):
        csv_data = df_to_csv(df)
        job_hdrs_json = {"Authorization": f"Bearer {dc_token}", "Content-Type": "application/json"}
        job_hdrs_csv  = {"Authorization": f"Bearer {dc_token}", "Content-Type": "text/csv"}

        for attempt in range(1, max_retries + 1):
            r = requests.post(
                f"{DC_INGEST_BASE}/api/v1/ingest/jobs",
                headers=job_hdrs_json,
                json={"object": schema_name, "sourceName": sf.get("ingestion_connector_name", "analytics_builder_demo"), "operation": "upsert"}
            )
            if r.ok:
                break
            if r.status_code == 404:
                wait = 15 * attempt
                print(f"\r  ⏳ {label}: schema not ready (attempt {attempt}/{max_retries}), waiting {wait}s...", end="", flush=True)
                _time.sleep(wait)
            elif r.status_code == 409:
                existing = _find_open_job(schema_name)
                if existing:
                    info(f"{label}: reusing existing job {existing['id']} (state: {existing['state']})")
                    if existing["state"] == "Open":
                        r2 = requests.put(
                            f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{existing['id']}/batches",
                            headers=job_hdrs_csv, data=csv_data.encode("utf-8")
                        )
                        if r2.ok:
                            requests.patch(f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{existing['id']}",
                                           headers=job_hdrs_json, json={"state": "UploadComplete"})
                        return existing["id"]
                    else:
                        return existing["id"]
                wait = 15 * attempt
                info(f"{label}: conflict, waiting {wait}s for existing job to clear...")
                _time.sleep(wait)
            else:
                die(f"Failed to create ingest job for {label}", r)
        else:
            die(f"Schema never became available for {label} after {max_retries} retries")

        resp = r.json()
        job_id = resp.get("id") or resp.get("data", {}).get("id")
        info(f"{label}: job created ({job_id})")

        r = requests.put(
            f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{job_id}/batches",
            headers=job_hdrs_csv,
            data=csv_data.encode("utf-8")
        )
        if not r.ok:
            die(f"Failed to upload data for {label}", r)
        ok(f"{label}: {len(df)} rows uploaded")

        r = requests.patch(
            f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{job_id}",
            headers=job_hdrs_json,
            json={"state": "UploadComplete"}
        )
        if not r.ok:
            die(f"Failed to close ingest job for {label}", r)
        ok(f"{label}: job closed — processing")
        return job_id

    fact_job_id = bulk_ingest(df_fact,     FACT_SCHEMA_NAME, "Fact_Member_CSAT")
    dim_job_id  = bulk_ingest(df_segments, DIM_SCHEMA_NAME,  "Dim_Segment")

    # ── PHASE 5: Wait for ingest jobs ─────────────────────────────────────────
    phase("Waiting for ingest jobs to complete")

    def wait_job(job_id, label, timeout=900):
        hdrs = {"Authorization": f"Bearer {dc_token}", "Content-Type": "application/json"}
        start = _time.time()
        while _time.time() < start + timeout:
            r = requests.get(f"{DC_INGEST_BASE}/api/v1/ingest/jobs/{job_id}", headers=hdrs)
            if r.ok:
                resp = r.json()
                state = resp.get("state") or resp.get("data", {}).get("state", "")
                elapsed = int(_time.time() - start)
                print(f"\r  ⏳ {label}: {state} ({elapsed}s)", end="", flush=True)
                if state == "JobComplete":
                    print()
                    ok(f"{label}: JobComplete ({elapsed}s)")
                    return True
                if state in ("Failed", "Aborted"):
                    print()
                    warn(f"Ingest job {label} ended with state: {state} — continuing anyway")
                    return False
            _time.sleep(10)
        warn(f"Timeout waiting for ingest job: {label} — continuing anyway")
        return False

    wait_job(fact_job_id, "Fact_Member_CSAT")
    wait_job(dim_job_id,  "Dim_Segment")

    # ── PHASE 6: Create workspace ─────────────────────────────────────────────
    phase("Creating workspace")

    r = requests.get(f"{BASE_SEM}/tableau/workspaces", headers=SF_HDRS)
    existing_workspaces = {w["name"]: w["id"] for w in r.json().get("workspaces", [])}
    if WORKSPACE_NAME in existing_workspaces:
        info(f"Workspace '{WORKSPACE_NAME}' exists — deleting and recreating")
        requests.delete(f"{BASE_SEM}/tableau/workspaces/{WORKSPACE_NAME}", headers=SF_HDRS)
        _time.sleep(3)

    r = requests.post(f"{BASE_SEM}/tableau/workspaces", headers=SF_HDRS, json={
        "label": WORKSPACE_NAME,
        "description": f"Demo: {COMPANY_NAME} {USE_CASE} — {PERSONA}"
    })
    if not r.ok:
        die("Failed to create workspace", r)
    workspace_name = r.json()["name"]
    workspace_id   = r.json()["id"]
    ok(f"Workspace created: {workspace_name} (id: {workspace_id})")

    # ── PHASE 7: Build Semantic Data Model ────────────────────────────────────
    phase("Building Semantic Data Model")

    SDM_LABEL = f"{COMPANY_NAME} {USE_CASE}"
    r = requests.get(f"{BASE_SEM}/ssot/semantic/models", headers=SF_HDRS, params={"limit": 200})
    for sdm in r.json().get("items", []):
        if sdm.get("label", "") == SDM_LABEL:
            info(f"SDM '{sdm['apiName']}' exists — deleting")
            requests.delete(f"{BASE_SEM}/ssot/semantic/models/{sdm['apiName']}", headers=SF_HDRS)
            _time.sleep(3)

    r = requests.post(f"{BASE_SEM}/ssot/semantic/models", headers=SF_HDRS, json={
        "label": SDM_LABEL,
        "description": f"{USE_CASE} metrics for {COMPANY_NAME}",
        "agentEnabled": True,
        "dataspace": "default",
    })
    if not r.ok:
        die("Failed to create SDM", r)
    sdm_api_name = r.json().get("apiName")
    ok(f"SDM created: {sdm_api_name}")

    r = requests.post(f"{BASE_SEM}/ssot/semantic/models/{sdm_api_name}/data-objects", headers=SF_HDRS, json={
        "dataObjectName": FACT_DLO,
        "label": "Member CSAT Activity",
        "dataObjectType": "dlo",
    })
    if r.ok:
        fact_do_api = r.json().get("apiName")
        ok(f"DLO added to SDM: Member CSAT Activity ({fact_do_api})")
    else:
        die("Failed to add fact DLO to SDM", r)

    # ── PHASE 8: Configure measurements + metrics ─────────────────────────────
    phase("Configuring measurements and verifying SDM")

    r = requests.get(
        f"{BASE_SEM}/ssot/semantic/models/{sdm_api_name}/data-objects/{fact_do_api}",
        headers=SF_HDRS,
    )
    detected_measurements = {}
    field_map = {}
    if r.ok:
        do_data = r.json()
        for m in do_data.get("semanticMeasurements", []):
            base = m["dataObjectFieldName"].replace("__c", "")
            detected_measurements[base] = (m["apiName"], m["dataObjectFieldName"])
            field_map[base] = m["apiName"]
        for d in do_data.get("semanticDimensions", []):
            dof = d.get("dataObjectFieldName", "")
            base = dof.replace("__c", "") if dof else d["apiName"].rstrip("0123456789")
            if base:
                field_map[base] = d["apiName"]
        _fm_preview = {k: v for k, v in list(field_map.items())[:8]}
        _fm_suffix = "..." if len(field_map) > 8 else ""
        info(f"Field map: {_fm_preview}{_fm_suffix}")

    MEASUREMENT_CONFIG = [
        ("csat_score",             "CSAT Score",              "Average"),
        ("nps_score",              "NPS Score",               "Average"),
        ("issues_reported",        "Issues Reported",         "Sum"),
        ("avg_resolution_hours",   "Avg Resolution Hours",    "Average"),
        ("platform_booking_rate",  "Platform Booking Rate",   "Average"),
        ("surveys_sent",           "Surveys Sent",            "Sum"),
        ("surveys_completed",      "Surveys Completed",       "Sum"),
        ("total_bookings",         "Total Bookings",          "Sum"),
        ("response_rate",          "Response Rate",           "Average"),
        ("resolved_same_day_rate", "Resolved Same Day Rate",  "Average"),
    ]

    configured = 0
    for base_field, label, agg in MEASUREMENT_CONFIG:
        if base_field not in detected_measurements:
            warn(f"Measurement not found: {base_field} (skipping)")
            continue
        api_name, field_name = detected_measurements[base_field]
        r = requests.put(
            f"{BASE_SEM}/ssot/semantic/models/{sdm_api_name}/data-objects/{fact_do_api}/measurements/{api_name}",
            headers=SF_HDRS,
            json={"apiName": api_name, "label": label, "dataObjectFieldName": field_name, "aggregationType": agg},
        )
        if r.ok:
            configured += 1
        else:
            warn(f"Measurement config failed for {label} (non-fatal): {r.status_code} {r.text[:150]}")
    ok(f"Measurements configured: {configured}/{len(MEASUREMENT_CONFIG)}")

    _time.sleep(2)
    r = requests.get(f"{BASE_SEM}/ssot/semantic/models/{sdm_api_name}", headers=SF_HDRS)
    if r.ok:
        sdm_info = r.json()
        ok(f"SDM verified: label={sdm_info.get('label')}, agentEnabled={sdm_info.get('agentEnabled')}, queryable={sdm_info.get('isQueryable')}")

    def _fapi(base_field):
        return field_map.get(base_field, base_field)

    METRIC_CONFIG = [
        ("Engine_CSAT_Score_clc",       "Avg CSAT Score",        "AVG",  "csat_score",             "Engine_CSAT_Score_mtc",       "Avg CSAT Score",        "SentimentTypeUpIsGood"),
        ("Engine_NPS_Score_clc",        "Avg NPS Score",         "AVG",  "nps_score",              "Engine_NPS_Score_mtc",        "Avg NPS Score",         "SentimentTypeUpIsGood"),
        ("Engine_Issues_Reported_clc",  "Issues Reported",       "SUM",  "issues_reported",        "Engine_Issues_Reported_mtc",  "Issues Reported",       "SentimentTypeUpIsBad"),
        ("Engine_Resolution_Hours_clc", "Avg Resolution Hours",  "AVG",  "avg_resolution_hours",   "Engine_Resolution_Hours_mtc", "Avg Resolution Hours",  "SentimentTypeUpIsBad"),
        ("Engine_Platform_Booking_clc", "Platform Booking Rate", "AVG",  "platform_booking_rate",  "Engine_Platform_Booking_mtc", "Platform Booking Rate", "SentimentTypeUpIsGood"),
        ("Engine_Response_Rate_clc",    "Survey Response Rate",  "AVG",  "response_rate",          "Engine_Response_Rate_mtc",    "Survey Response Rate",  "SentimentTypeUpIsGood"),
    ]

    clc_map = {}
    for clc_api, clc_label, agg_fn, meas_base, *_ in METRIC_CONFIG:
        if meas_base not in detected_measurements:
            warn(f"Skipping _clc for {clc_label} — measurement not found")
            continue
        meas_api, _ = detected_measurements[meas_base]
        expr = f"{agg_fn}([{fact_do_api}].[{meas_api}])"
        r = requests.post(
            f"{BASE_SEM}/ssot/semantic/models/{sdm_api_name}/calculated-measurements",
            headers=SF_HDRS,
            json={
                "apiName": clc_api, "label": clc_label,
                "aggregationType": "UserAgg", "dataType": "Number", "decimalPlace": 2,
                "directionality": "Up", "displayCategory": "Continuous",
                "expression": expr, "filters": [], "isOverrideBase": False, "isVisible": True,
                "level": "AggregateFunction", "overriddenProperties": [],
                "semanticDataType": "None", "sentiment": "SentimentTypeUpIsGood",
                "shouldTreatNullsAsZeros": False, "sortOrder": "None", "totalAggregationType": "Sum",
            },
        )
        if r.status_code in (200, 201):
            actual = r.json().get("apiName", clc_api)
            clc_map[clc_api] = actual
        else:
            warn(f"_clc failed for {clc_label}: {r.status_code} {r.text[:150]}")

    metric_names = []
    for clc_api, _, __, ___, metric_api, metric_label, sentiment in METRIC_CONFIG:
        actual_clc = clc_map.get(clc_api)
        if not actual_clc:
            warn(f"Skipping metric {metric_label} — no _clc field")
            continue
        r = requests.post(
            f"{BASE_SEM66}/ssot/semantic/models/{sdm_api_name}/metrics",
            headers=SF_HDRS,
            json={
                "apiName": metric_api, "label": metric_label,
                "aggregationType": "UserAgg",
                "measurementReference": {"calculatedFieldApiName": actual_clc},
                "timeDimensionReference": {"tableFieldReference": {
                    "fieldApiName": _fapi("date"), "tableApiName": fact_do_api
                }},
                "timeGrains": ["Day", "Week", "Month", "Quarter", "Year"],
                "filters": [], "isCumulative": False, "isGoalEditingBlocked": False,
                "additionalDimensions": [
                    {"tableFieldReference": {"fieldApiName": _fapi("segment_name"), "tableApiName": fact_do_api}},
                    {"tableFieldReference": {"fieldApiName": _fapi("region"),       "tableApiName": fact_do_api}},
                ],
                "insightsSettings": {
                    "insightTypes": [
                        {"enabled": False, "type": "TopContributors"},
                        {"enabled": False, "type": "ComparisonToExpectedRangeAlert"},
                        {"enabled": True,  "type": "TrendChangeAlert"},
                        {"enabled": True,  "type": "BottomContributors"},
                        {"enabled": True,  "type": "ConcentratedContributionAlert"},
                        {"enabled": True,  "type": "TopDrivers"},
                        {"enabled": True,  "type": "TopDetractors"},
                        {"enabled": True,  "type": "CurrentTrend"},
                        {"enabled": False, "type": "OutlierDetection"},
                        {"enabled": False, "type": "RecordLevelTable"},
                    ],
                    "insightsDimensionsReferences": [
                        {"tableFieldReference": {"fieldApiName": _fapi("segment_name"), "tableApiName": fact_do_api}},
                        {"tableFieldReference": {"fieldApiName": _fapi("region"),       "tableApiName": fact_do_api}},
                    ],
                    "pluralNoun": "", "sentiment": sentiment, "singularNoun": "",
                },
            },
        )
        if r.status_code in (200, 201):
            actual = r.json().get("apiName", metric_api)
            ok(f"Metric created: {metric_label} ({actual})")
            metric_names.append(actual)
        else:
            warn(f"Metric failed: {metric_label} — {r.status_code} {r.text[:150]}")

    ok(f"Semantic metrics created: {len(metric_names)}/{len(METRIC_CONFIG)}")

    # ── PHASE 9: Create visualizations ────────────────────────────────────────
    phase("Creating visualizations")

    VIZ_BASE   = f"{sf_instance}/services/data/v66.0"
    VIZ_PARAMS = {"minorVersion": "12"}

    def make_viz(name, label, fields, vis_spec):
        payload = {
            "name": name, "label": label,
            "dataSource": {"name": sdm_api_name, "label": "Engine Member CSAT", "type": "SemanticModel"},
            "workspace": {"name": workspace_name, "label": workspace_name},
            "interactions": [], "fields": fields, "visualSpecification": vis_spec,
            "view": {
                "label": "default", "name": f"{name}_default",
                "viewSpecification": {"sortOrders": {"columns": [], "fields": {}, "rows": []}}
            }
        }
        r = requests.post(f"{VIZ_BASE}/tableau/visualizations", headers=SF_HDRS, params=VIZ_PARAMS, json=payload)
        if r.status_code in (200, 201):
            viz_name = r.json().get("name", name)
            ok(f"Viz created: {label} ({viz_name})")
            return viz_name
        warn(f"Viz failed: {label} — {r.status_code} {r.text[:200]}")
        return None

    OBJ = fact_do_api

    def _style_number(fkey):
        return {fkey: {"defaults": {"format": {"numberFormatInfo": {
            "decimalPlaces": 2, "displayUnits": "Auto", "includeThousandSeparator": True,
            "negativeValuesFormat": "Auto", "prefix": "", "suffix": "", "type": "Number"
        }}}}}

    def _style_percent(fkey):
        return {fkey: {"defaults": {"format": {"numberFormatInfo": {
            "decimalPlaces": 1, "displayUnits": "Auto", "includeThousandSeparator": False,
            "negativeValuesFormat": "Auto", "prefix": "", "suffix": "%", "type": "Number"
        }}}}}

    FONTS = {
        "actionableHeaders": {"color": "#0250D9", "size": 13},
        "axisTickLabels":    {"color": "#2E2E2E", "size": 13},
        "fieldLabels":       {"color": "#2E2E2E", "size": 13},
        "headers":           {"color": "#2E2E2E", "size": 13},
        "legendLabels":      {"color": "#2E2E2E", "size": 13},
        "markLabels":        {"color": "#2E2E2E", "size": 13},
        "marks":             {"color": "#2E2E2E", "size": 13},
    }
    LINES = {
        "axisLine":              {"color": "#C9C9C9"},
        "fieldLabelDividerLine": {"color": "#C9C9C9"},
        "separatorLine":         {"color": "#C9C9C9"},
        "zeroLine":              {"color": "#C9C9C9"},
    }

    viz_names = []

    def _marks_headers_style():
        return {
            "color": {"color": ""}, "isAutomaticSize": True,
            "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
            "range": {"reverse": False},
            "size": {"isAutomatic": True, "type": "Pixel", "value": 13},
        }

    def _vizql_mark_headers():
        return {
            "encodings": [], "isAutomatic": True,
            "stack": {"isAutomatic": True, "isStacked": False}, "type": "Text",
        }

    FM = field_map

    v = make_viz(
        "Engine_CSAT_Score_Trend", "CSAT Score Trend by Segment",
        fields={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("date", "date"), "function": "DatePartMonth"},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": FM.get("csat_score", "csat_score"), "function": "Avg"},
            "F3": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("segment_name", "segment_name")},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {"F3": {"isVisible": True, "position": "Right", "title": {"isVisible": True}}},
            "marks": {
                "fields": {}, "headers": _vizql_mark_headers(),
                "panes": {"encodings": [{"fieldKey": "F3", "type": "Color"}],
                          "isAutomatic": False, "type": "Line",
                          "stack": {"isAutomatic": True, "isStacked": False}}
            },
            "style": {
                "axis": {"fields": {"F2": {
                    "isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": False, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 2, "displayUnits": "Auto",
                        "includeThousandSeparator": False, "negativeValuesFormat": "Auto",
                        "prefix": "", "suffix": "", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}
                }}},
                "encodings": {"fields": _style_number("F2")},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                "rows": {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {
                    "columns": {"mergeRepeatedCells": True, "showIndex": False},
                    "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                    "rows": {"mergeRepeatedCells": True, "showIndex": False}
                },
                "lines": LINES,
                "marks": {
                    "fields": {}, "headers": _marks_headers_style(),
                    "panes": {"color": {"color": ""}, "isAutomaticSize": False,
                              "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                              "range": {"reverse": False},
                              "size": {"isAutomatic": False, "type": "Pixel", "value": 3}}
                },
                "referenceLines": {},
                "shading": {"backgroundColor": "#FFFFFF", "banding": {}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        }
    )
    if v: viz_names.append(v)

    v = make_viz(
        "Engine_Issues_By_Segment", "Issues Reported by Segment",
        fields={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("segment_name", "segment_name")},
            "F2": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("region", "region")},
            "F3": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": FM.get("issues_reported", "issues_reported"), "function": "Sum"},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F3"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {"F2": {"isVisible": True, "position": "Right", "title": {"isVisible": True}}},
            "marks": {
                "fields": {},
                "headers": {**_vizql_mark_headers(), "stack": {"isAutomatic": True, "isStacked": True}},
                "panes": {"encodings": [{"fieldKey": "F2", "type": "Color"}],
                          "isAutomatic": False, "type": "Bar",
                          "stack": {"isAutomatic": True, "isStacked": True}}
            },
            "style": {
                "axis": {"fields": {"F3": {
                    "isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": True, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 0, "displayUnits": "Auto",
                        "includeThousandSeparator": True, "negativeValuesFormat": "Auto",
                        "prefix": "", "suffix": "", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}
                }}},
                "encodings": {"fields": _style_number("F3")},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                "rows": {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {
                    "columns": {"mergeRepeatedCells": True, "showIndex": False},
                    "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                    "rows": {"mergeRepeatedCells": True, "showIndex": False}
                },
                "lines": LINES,
                "marks": {
                    "fields": {}, "headers": _marks_headers_style(),
                    "panes": {"color": {"color": ""}, "isAutomaticSize": True,
                              "isStackingAxisCentered": False,
                              "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                              "range": {"reverse": True},
                              "size": {"isAutomatic": True, "type": "Percentage", "value": 75}}
                },
                "referenceLines": {},
                "shading": {"backgroundColor": "#FFFFFF", "banding": {"rows": {"color": "#E5E5E5"}}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        }
    )
    if v: viz_names.append(v)

    v = make_viz(
        "Engine_Platform_Booking_Trend", "Platform Booking Rate Trend",
        fields={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("date", "date"), "function": "DatePartMonth"},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": FM.get("platform_booking_rate", "platform_booking_rate"), "function": "Avg"},
            "F3": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("segment_name", "segment_name")},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {"F3": {"isVisible": True, "position": "Right", "title": {"isVisible": True}}},
            "marks": {
                "fields": {}, "headers": _vizql_mark_headers(),
                "panes": {"encodings": [{"fieldKey": "F3", "type": "Color"}],
                          "isAutomatic": False, "type": "Line",
                          "stack": {"isAutomatic": True, "isStacked": False}}
            },
            "style": {
                "axis": {"fields": {"F2": {
                    "isVisible": True, "isZeroLineVisible": False,
                    "range": {"includeZero": False, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 1, "displayUnits": "Auto",
                        "includeThousandSeparator": False, "negativeValuesFormat": "Auto",
                        "prefix": "", "suffix": "%", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}
                }}},
                "encodings": {"fields": _style_percent("F2")},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                "rows": {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {
                    "columns": {"mergeRepeatedCells": True, "showIndex": False},
                    "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                    "rows": {"mergeRepeatedCells": True, "showIndex": False}
                },
                "lines": LINES,
                "marks": {
                    "fields": {}, "headers": _marks_headers_style(),
                    "panes": {"color": {"color": ""}, "isAutomaticSize": False,
                              "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                              "range": {"reverse": False},
                              "size": {"isAutomatic": False, "type": "Pixel", "value": 3}}
                },
                "referenceLines": {},
                "shading": {"backgroundColor": "#FFFFFF", "banding": {}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        }
    )
    if v: viz_names.append(v)

    v = make_viz(
        "Engine_Resolution_Hours", "Avg Resolution Hours by Segment",
        fields={
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": OBJ, "fieldName": FM.get("segment_name", "segment_name")},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": OBJ, "fieldName": FM.get("avg_resolution_hours", "avg_resolution_hours"), "function": "Avg"},
        },
        vis_spec={
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {},
            "marks": {
                "fields": {}, "headers": _vizql_mark_headers(),
                "panes": {"encodings": [], "isAutomatic": True, "type": "Bar",
                          "stack": {"isAutomatic": True, "isStacked": False}}
            },
            "style": {
                "axis": {"fields": {"F2": {
                    "isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": True, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": 1, "displayUnits": "Auto",
                        "includeThousandSeparator": False, "negativeValuesFormat": "Auto",
                        "prefix": "", "suffix": "h", "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}}
                }}},
                "encodings": {"fields": _style_number("F2")},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                "rows": {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {
                    "columns": {"mergeRepeatedCells": True, "showIndex": False},
                    "fields": {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                    "rows": {"mergeRepeatedCells": True, "showIndex": False}
                },
                "lines": LINES,
                "marks": {
                    "fields": {}, "headers": _marks_headers_style(),
                    "panes": {"color": {"color": ""}, "isAutomaticSize": True,
                              "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": True},
                              "range": {"reverse": True},
                              "size": {"isAutomatic": True, "type": "Percentage", "value": 75}}
                },
                "referenceLines": {},
                "shading": {"backgroundColor": "#FFFFFF", "banding": {"rows": {"color": "#E5E5E5"}}},
                "showDataPlaceholder": False, "title": {"isVisible": True}
            }
        }
    )
    if v: viz_names.append(v)

    ok(f"Visualizations created: {len(viz_names)}/{4}")

    # ── PHASE 10: Build dashboard ──────────────────────────────────────────────
    phase("Building dashboard")

    company_title  = COMPANY_NAME.replace(" ", "_")
    use_case_title = USE_CASE.replace(" ", "_")
    dashboard_name  = f"{company_title}_{use_case_title}_Dashboard"
    dashboard_label = f"{COMPANY_NAME} {USE_CASE} Dashboard"

    requests.delete(f"{VIZ_BASE}/tableau/dashboards/{dashboard_name}", headers=SF_HDRS, params=VIZ_PARAMS)
    _time.sleep(1)

    COL_COUNT = 72
    widgets = {}

    def _metric_widget_style():
        return {"borderColor": "#C9C9C9", "borderEdges": ["all"], "borderRadius": 20}

    def _viz_widget_style():
        return {"borderColor": "#C9C9C9", "borderEdges": [], "borderRadius": 16}

    def _container_widget_style():
        return {"borderColor": "#c9c9c9", "borderEdges": ["all"], "borderRadius": 16}

    n_metrics = len(metric_names)
    METRICS_PER_ROW = 3
    metric_col_width = COL_COUNT // METRICS_PER_ROW
    for i, mn in enumerate(metric_names):
        k = f"metric_{i+1}"
        widgets[k] = {
            "actions": [], "name": k, "type": "metric",
            "source": {"name": mn},
            "parameters": {
                "metricOption": {
                    "sdmApiName": sdm_api_name,
                    "layout": {"componentVisibility": {
                        "title": True, "value": True, "comparison": True,
                        "chart": True, "insights": True, "details": True,
                    }}
                },
                "receiveFilterSource": {"filterMode": "all", "widgetIds": []},
                "widgetStyle": _metric_widget_style(),
            }
        }

    widgets["text_title"] = {
        "actions": [], "name": "text_title", "type": "text",
        "parameters": {
            "content": [
                {"attributes": {"size": "20px", "color": "#03234d"}, "insert": f"{COMPANY_NAME} {USE_CASE}"},
                {"insert": "\n"},
                {"attributes": {"color": "#5c5c5c", "size": "14px"}, "insert": STORY},
                {"attributes": {"align": "left"}, "insert": "\n"},
            ],
            "widgetStyle": {"borderColor": "#C9C9C9", "borderEdges": []},
        }
    }

    for i, vn in enumerate(viz_names):
        k = f"visualization_{i+1}"
        widgets[k] = {
            "actions": [], "name": k, "type": "visualization",
            "source": {"name": vn},
            "parameters": {
                "legendPosition": "Bottom" if i == 0 else "Right",
                "receiveFilterSource": {"filterMode": "all", "widgetIds": []},
                "widgetStyle": _viz_widget_style(),
            }
        }
        ck = f"container_{i+1}"
        widgets[ck] = {
            "actions": [], "name": ck, "type": "container",
            "parameters": {"widgetStyle": _container_widget_style()}
        }

    page_widgets = []
    layout_row = 0

    n_rows = (n_metrics + METRICS_PER_ROW - 1) // METRICS_PER_ROW
    for i in range(n_metrics):
        row_idx = i // METRICS_PER_ROW
        col_idx = i % METRICS_PER_ROW
        page_widgets.append({
            "name": f"metric_{i+1}",
            "column": col_idx * metric_col_width, "row": layout_row + row_idx * 15,
            "colspan": metric_col_width, "rowspan": 15,
        })
    layout_row += n_rows * 15

    page_widgets.append({"name": "text_title", "column": 1, "row": layout_row, "colspan": 45, "rowspan": 5})
    layout_row += 5

    VIZ_W = 35
    VIZ_H = 28
    for i in range(len(viz_names)):
        col_start = i * (VIZ_W + 2)
        page_widgets.append({"name": f"container_{i+1}", "column": col_start, "row": layout_row, "colspan": VIZ_W, "rowspan": VIZ_H})
        page_widgets.append({"name": f"visualization_{i+1}", "column": col_start + 1, "row": layout_row + 1, "colspan": VIZ_W - 2, "rowspan": VIZ_H - 2})
    layout_row += VIZ_H

    dash_payload = {
        "name": dashboard_name, "label": dashboard_label,
        "workspaceIdOrApiName": workspace_name,
        "widgets": widgets,
        "layouts": [{
            "name": "default", "columnCount": COL_COUNT, "rowHeight": 10, "maxWidth": 1200,
            "style": {"backgroundColor": "#f3f3f3", "cellSpacingX": 8, "cellSpacingY": 8, "gutterColor": "#f3f3f3"},
            "pages": [{"name": str(uuid.uuid4()), "label": "Overview", "widgets": page_widgets}],
        }],
    }

    r = requests.post(f"{VIZ_BASE}/tableau/dashboards", headers=SF_HDRS, params=VIZ_PARAMS, json=dash_payload)
    if r.status_code in (200, 201):
        dashboard_id = r.json().get("id") or r.json().get("name")
        ok(f"Dashboard created: {dashboard_name} (id: {dashboard_id})")
    else:
        warn(f"Dashboard creation failed: {r.status_code} {r.text[:300]}")
        info("You can build the dashboard manually in the Tableau Next UI.")
        dashboard_id = None

# ── Final summary ──────────────────────────────────────────────────────────────
elapsed = int(_time.time() - _SCRIPT_START)
print(f"\n{'='*66}")
print(f"  ✅ Engine Member CSAT Demo — BUILD COMPLETE ({elapsed}s)")
print(f"  {'─'*62}")
if BUILD_PULSE:
    print(f"  PULSE")
    print(f"  Project:    {pulse_project_name}")
    print(f"  Metrics:    {pulse_metric_count}/6 created")
    print(f"  Group:      {pulse_group_name}")
    print(f"  🔗 {TC_SERVER_URL}/pulse")
    print(f"  {'─'*62}")
if BUILD_NEXT:
    print(f"  NEXT")
    print(f"  Workspace:  {workspace_name}")
    print(f"  SDM:        {SDM_NAME}")
    print(f"  Dashboard:  {dashboard_id or (dashboard_name + ' (check workspace)')}")
    print(f"  🔗 {sf_instance}/tableau/workspace/{workspace_name}")
    print(f"  {'─'*62}")
    print(f"  ⚡ Enable Analytics Agent Readiness:")
    print(f"     Data 360 → Semantic Model → {SDM_NAME} → Settings → Analytics Agent Readiness → ON")
    print(f"  {'─'*62}")
print(f"{'='*66}\n")

# All output goes into this script's folder (demos/engine_member_csat/)
DEMO_DIR = Path(__file__).parent

# Write demo guide
guide_path = DEMO_DIR / f"{company_slug}_{use_case_slug}_guide.md"
guide_path.write_text(f"""# Engine — Member CSAT Demo Guide

**Persona:** {PERSONA}
**Story:** {STORY}
**Built:** {_dt.now().strftime("%Y-%m-%d %H:%M")}

## The Story

Member CSAT scores at Engine have been declining for the past 6 months.
Enterprise members are most affected. Issues reported are up, resolution
times are climbing, and off-platform booking rates are creeping upward —
suggesting friction is pushing members to book outside the platform.

## Key Metrics

| Metric | Trend |
|--------|-------|
| Avg CSAT Score | ↓ Declining (from ~4.3 to ~3.9) |
| Net Promoter Score | ↓ Declining |
| Issues Reported | ↑ Increasing |
| Avg Resolution Hours | ↑ Increasing |
| Platform Booking Rate | ↓ Declining |

## Demo Talking Points

1. **Open CSAT Trend** — show the 6-month decline, segment breakdown
2. **Enterprise impact** — Enterprise segment hit hardest (highest CSAT to start, biggest drop)
3. **Issues & resolution** — issues up 80%, resolution time up 6+ hrs
4. **Platform leakage** — 12% drop in platform booking rate = members booking elsewhere

## Concierge Prompts

- "What's happening with member CSAT?"
- "Which segments have the lowest CSAT scores?"
- "How has the platform booking rate changed this year?"
- "What's driving the increase in issues reported?"

## Assets

- Workspace: `{"" if not BUILD_NEXT else workspace_name}`
- SDM: `{"" if not BUILD_NEXT else SDM_NAME}`
- Dashboard: Engine Member CSAT Dashboard

## Workspace URL

{"N/A — Pulse only build" if not BUILD_NEXT else sf_instance + "/tableau/workspace/" + workspace_name}

## Post-Build Step

{"N/A — Pulse only build" if not BUILD_NEXT else "Enable Analytics Agent Readiness:\nData 360 → Semantic Model → " + SDM_NAME + " → Settings → Analytics Agent Readiness → ON"}
""")
ok(f"Demo guide written: {guide_path.name}")

# Write Concierge walkthrough docx
def _add_heading(doc, text, level=1, color=None):
    p = doc.add_heading(text, level=level)
    if color:
        for run in p.runs:
            run.font.color.rgb = RGBColor(*color)
    return p

def _add_para(doc, text, bold=False, italic=False):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    return p

def _add_question(doc, question, expected):
    p = doc.add_paragraph()
    p.add_run("Ask: ").bold = True
    p.add_run(f'"{question}"').italic = True
    _add_para(doc, expected)
    doc.add_paragraph()

_built_modes = []
if BUILD_PULSE: _built_modes.append("Pulse")
if BUILD_NEXT:  _built_modes.append("Tableau Next")
_mode_label = " + ".join(_built_modes)

docx_path = DEMO_DIR / f"{company_slug}_{use_case_slug}_demo_walkthrough.docx"
doc = Document()

# ── Cover ──────────────────────────────────────────────────────────────────────
t = doc.add_heading(f"{COMPANY_NAME} — {USE_CASE}", 0)
for run in t.runs:
    run.font.color.rgb = RGBColor(2, 35, 77)
t2 = doc.add_heading("Demo Walkthrough", 1)
for run in t2.runs:
    run.font.color.rgb = RGBColor(80, 80, 80)

doc.add_paragraph(f"Output: {_mode_label}  |  Persona: {PERSONA}  |  Built: {_dt.now().strftime('%Y-%m-%d %H:%M')}")
doc.add_paragraph(f"Story: {STORY}")
doc.add_paragraph()

# ══════════════════════════════════════════════════════════════════════════════
# TABLEAU PULSE SECTION
# ══════════════════════════════════════════════════════════════════════════════
if BUILD_PULSE:
    _add_heading(doc, "Tableau Pulse", 1, color=(2, 35, 77))
    doc.add_paragraph(
        "Tableau Pulse delivers metric digests and trend intelligence directly to "
        "stakeholders — no dashboard required. Use this section to walk through the "
        "Pulse experience end-to-end."
    )

    # Setup
    _add_heading(doc, "Setup", 2)
    pulse_url = f"{TC_SERVER_URL}/pulse"
    for item in [
        f"Navigate to Tableau Pulse: {pulse_url}",
        f'Find the group "{pulse_group_name}" — it should appear in your subscriptions',
        "Confirm all 6 metrics are visible on the overview screen",
        "Set the time range to Last 6 months to make the signal visible",
    ]:
        doc.add_paragraph(item, style="List Bullet")

    # Part 1: Orient
    _add_heading(doc, "Part 1 — Orient the audience (30 seconds)", 2)
    _add_para(doc,
        "Briefly name the metrics on screen — don't dwell. The goal is to set context, "
        "not explain every card. Land on CSAT and stay there.",
        bold=False)
    metrics_intro = [
        "Avg CSAT Score ← PRIMARY. This is the story. Healthy above 4.2.",
        "Avg NPS Score — supporting context. Shows loyalty is also softening.",
        "Issues Reported — supporting context. Explains the CSAT drop when asked.",
        "Avg Resolution Hours — supporting context. Same role as Issues.",
        "Platform Booking Rate — supporting context. A leading indicator worth mentioning at the close.",
        "Survey Response Rate — background signal. Only relevant if someone asks about data quality.",
    ]
    for m in metrics_intro:
        doc.add_paragraph(f"• {m}")
    _add_para(doc,
        'Talking point: "I\'m going to focus on CSAT — it\'s the clearest signal in the data '
        'and the one that has the most direct business impact. The other metrics will help us '
        'understand why it\'s moving."',
        bold=True)

    # Part 2: Drill into CSAT
    _add_heading(doc, "Part 2 — Lead with the primary metric: CSAT", 2)
    _add_para(doc, "Click on the Avg CSAT Score metric card.", bold=True)
    for step in [
        "Show the time-series chart — the 6-month downtrend should be immediately obvious.",
        "Point out the current value vs. the 4.2 healthy threshold. Enterprise is now below it.",
        "Expand the Breakdown panel — CSAT by Segment surfaces Enterprise as the underperformer.",
        "Expand Breakdown by Region — one region is pulling Enterprise down disproportionately.",
        'Talking point: "Pulse found the breakdown automatically. I didn\'t have to build a filter '
        '— it identified that Segment and Region are the most meaningful dimensions for this metric."',
    ]:
        doc.add_paragraph(f"• {step}")

    # Part 3: Discover questions — CSAT focused, others used to explain why
    _add_heading(doc, "Part 3 — Pulse Discover questions", 2)
    _add_para(doc,
        'Use the "Ask a question" field on the CSAT card. '
        'Start with the primary metric, then use supporting metrics to answer why.',
        bold=True)
    pulse_questions = [
        ("How has CSAT trended over the last 6 months?",
         "Time-series breakdown confirming the decline — quantifies the drop and calls out the acceleration in the last 3 months."),
        ("Which segment has the lowest CSAT?",
         "Enterprise surfaces immediately. This is the 'uh oh' moment — your highest-value segment is the most affected."),
        ("Why is CSAT declining in Enterprise?",
         "Pulse cross-references Issues Reported and Avg Resolution Hours as the correlated drivers — surfaces the causal story without you having to build it."),
        ("Show me CSAT by region for Enterprise",
         "Isolates the regional concentration — identifies which region to investigate first."),
        ("How did CSAT compare this quarter vs last quarter?",
         "Period-over-period — quantifies the magnitude and gives the audience a number to take back to their team."),
    ]
    for q, expected in pulse_questions:
        _add_question(doc, q, f"What to expect: {expected}")

    # Part 4: Pulse talking points
    _add_heading(doc, "Key Pulse Talking Points", 2)
    for pt in [
        '"The CSAT decline is the headline — everything else in this dashboard supports that story. Pulse lets me stay focused on one metric without losing the context around it."',
        '"Pulse brings the insight to you — stakeholders get a digest in their inbox the moment something moves. They don\'t have to open a dashboard to know CSAT is declining."',
        '"The Discover questions make this conversational. The SVP doesn\'t need to know how to filter data — they just ask what they want to know."',
        '"This scales to hundreds of metrics. Each person in the org sees only the metrics relevant to their role, with the context they need to act."',
    ]:
        doc.add_paragraph(pt, style="List Bullet")

    doc.add_page_break()

# ══════════════════════════════════════════════════════════════════════════════
# TABLEAU NEXT / CONCIERGE SECTION
# ══════════════════════════════════════════════════════════════════════════════
if BUILD_NEXT:
    _add_heading(doc, "Tableau Next — Concierge", 1, color=(2, 35, 77))
    doc.add_paragraph(
        "Tableau Next combines a Semantic Data Model with an AI Concierge that can "
        "answer natural-language questions, surface insights, and make recommendations — "
        "all grounded in governed business metrics."
    )

    # Setup
    _add_heading(doc, "Setup", 2)
    for item in [
        f"Open the Tableau Next workspace: {sf_instance}/tableau/workspace/{workspace_name}",
        "Open the Engine Member CSAT Dashboard",
        "Open the Concierge panel — chat icon in the top right",
        f"Confirm the SDM shown is {SDM_NAME}",
        "Remind the audience: Analytics Agent Readiness must be ON in Data 360 → Semantic Model → Settings",
    ]:
        doc.add_paragraph(item, style="List Bullet")

    # Part 1: Orient
    _add_heading(doc, "Part 1 — Orient the audience (30 seconds)", 2)
    _add_para(doc,
        "Name the metric tiles quickly — don't explain each one. The goal is to land on "
        "CSAT immediately and let the audience register the sparkline decline before you say a word.",
        bold=False)
    for m in metrics_intro:
        doc.add_paragraph(f"• {m}")
    _add_para(doc,
        'Talking point: "I\'m going to focus on CSAT — it\'s the headline metric here. '
        'The sparkline tells the story before I even ask a question. Let\'s use Concierge '
        'to find out what\'s driving it."',
        bold=True)

    # Part 2: Open on CSAT
    _add_heading(doc, "Part 2 — Lead with the primary metric: CSAT", 2)
    _add_para(doc, "Click on the CSAT metric tile to expand it, then open Concierge.", bold=True)
    for q, e in [
        ("How has our CSAT score trended over the last 6 months?",
         "Time-series breakdown confirming the decline with magnitude called out. The audience sees a number — e.g. 'down 0.5 points since May'."),
        ("Which segment is most affected?",
         "Enterprise surfaces as the underperformer. This is the 'uh oh' moment — your highest-value segment is the most at risk."),
    ]:
        _add_question(doc, q, f"What to expect: {e}")

    # Part 3: Use supporting metrics to explain why
    _add_heading(doc, "Part 3 — Use supporting metrics to answer why", 2)
    _add_para(doc,
        "Now bring in the other metrics — not as co-headliners, but as evidence. "
        "Let Concierge connect the dots.",
        bold=False)
    for q, e in [
        ("What should I be worried about?",
         "Concierge cross-references CSAT with Issues Reported and Resolution Hours — surfaces Enterprise + the highest-risk region as a combined risk signal."),
        ("Show me CSAT by region for the Enterprise segment",
         "Isolates the region pulling the score down. Now the audience has a specific place to act."),
        ("What is driving the CSAT decline in that region?",
         "Resolution time called out as the primary driver — concrete and actionable."),
    ]:
        _add_question(doc, q, f"What to expect: {e}")

    # Part 4: Quantify and close
    _add_heading(doc, "Part 4 — Quantify and close", 2)
    _add_para(doc,
        "One or two more questions to put a number on the risk and set up the recommendation.",
        bold=False)
    for q, e in [
        ("How does our resolution time compare to the healthy threshold?",
         "Avg Resolution Hours surfaced against the 12-hour benchmark — makes the gap concrete."),
        ("What should the SVP Operations prioritize to improve CSAT next quarter?",
         "Three-part recommendation: (1) reduce resolution time in the affected region, "
         "(2) drive platform adoption in Enterprise, (3) increase survey response rate to improve data confidence."),
    ]:
        _add_question(doc, q, f"What to expect: {e}")

    # Key talking points
    _add_heading(doc, "Key Talking Points", 2)
    for pt in [
        '"The dashboard shows you the what — Concierge shows you the why and the so what."',
        '"The business preferences make this contextual. The agent knows Enterprise is your highest-value segment, that a score below 3.8 requires immediate attention, and that platform booking rate is a leading indicator of churn."',
        '"This isn\'t a search engine — it\'s an analyst who already knows your business."',
        '"Every answer is grounded in the Semantic Data Model — the same governed definitions your analysts use."',
    ]:
        doc.add_paragraph(pt, style="List Bullet")

    # Live audience prompts
    _add_heading(doc, "Suggested Live Audience Prompts", 2)
    for prompt in [
        '"Ask it something you\'d normally ask your analyst on a Monday morning."',
        '"Ask it which region you should investigate first."',
        '"Ask it to compare Enterprise CSAT this quarter to the same period last year."',
        '"Ask it what would happen to overall CSAT if we fixed the resolution time issue."',
    ]:
        doc.add_paragraph(prompt, style="List Bullet")

    # Business preferences appendix
    _add_heading(doc, "Appendix — Business Preferences (SDM Configuration)", 2)
    doc.add_paragraph(
        "The following context is configured on the Semantic Data Model to enable "
        "Concierge to answer questions with business-specific framing:"
    )
    doc.add_paragraph()
    for line in [
        "Engine is a corporate travel management platform serving enterprise, mid-market, and SMB members.",
        "The most important metric is CSAT Score. A healthy score is above 4.2. Scores below 3.8 require immediate attention.",
        "Enterprise is the highest-value segment — it generates approximately 60% of revenue and has the highest churn cost.",
        "Platform Booking Rate is a leading indicator of member disengagement: when members book off-platform, it signals friction and increases churn risk.",
        "Avg Resolution Hours above 12 hours is considered slow and directly correlates with lower CSAT scores.",
        "Survey Response Rate below 20% makes CSAT data statistically unreliable for that segment.",
        "When CSAT declines in Enterprise, always check resolution time and platform booking rate first — these are the two primary drivers historically.",
        "The West and Northeast regions have historically been most sensitive to hotel quality issues.",
        "A 1-point decline in CSAT correlates with approximately 8% increase in voluntary cancellations in the following quarter.",
    ]:
        doc.add_paragraph(f"• {line}")

doc.save(str(docx_path))
ok(f"Demo walkthrough saved: {docx_path}")

mac_notify("Analytics Builder", f"Engine Member CSAT demo ready! ({elapsed}s)")
print(f"\n  📄 Demo walkthrough: {docx_path}\n")
