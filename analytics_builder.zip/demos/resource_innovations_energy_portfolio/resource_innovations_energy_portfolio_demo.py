#!/usr/bin/env python3
"""
Resource Innovations — Energy Portfolio Performance Demo
Persona: Head of Energy Services
Output: Tableau Pulse

Signal: kWh savings delivery rate declining 35% over last 6 months while
        cost-per-participant is climbing — a margin + compliance squeeze narrative.
"""

import json, sys, uuid, os, requests, subprocess, tempfile, shutil
import pandas as pd
import numpy as np
import time as _time
from datetime import date, datetime as _dt
from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor
from xml.etree import ElementTree as ET

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "../.."))

# ── Demo parameters ────────────────────────────────────────────────────────────
COMPANY_NAME  = "Resource Innovations"
USE_CASE      = "Energy Portfolio Performance"
PERSONA       = "Head of Energy Services"
STORY         = "kWh savings delivery falling short of contracted targets while cost-per-participant rises — a margin and compliance squeeze across the program portfolio"
SIGNAL_ONSET  = -6

company_slug  = "resource_innovations"
use_case_slug = "energy_portfolio"
TODAY         = date.today()
START_DATE    = date(TODAY.year - 2, TODAY.month, 1)
TIMESTAMP     = _dt.now().strftime("%Y-%m-%d %H:%M")

BUILD_PULSE = True
BUILD_NEXT  = False
BUILD_CSV   = False

# ── Advanced settings ──────────────────────────────────────────────────────────
HISTORY_MONTHS       = 24
GRAIN                = "monthly"
SIGNAL_MAGNITUDE     = 0.37
SIGNAL_ONSET_VAL     = -6
SIGNAL_SHAPE         = "ramp"
SUPPORTING_MAGNITUDE = 0.12

print(f"\n{'='*66}")
print(f"  RESOURCE INNOVATIONS — ENERGY PORTFOLIO PERFORMANCE")
print(f"  {'─'*62}")
print(f"  Advanced settings:")
print(f"    History:    {HISTORY_MONTHS} months")
print(f"    Grain:      {GRAIN}")
print(f"    Signal:     {int(SIGNAL_MAGNITUDE*100)}% primary decline, onset {SIGNAL_ONSET_VAL}mo, shape {SIGNAL_SHAPE}")
print(f"    Supporting: {int(SUPPORTING_MAGNITUDE*100)}% movement")
print(f"  {'─'*62}")
print(f"  Building: PULSE")
print(f"{'='*66}\n")

# ── Diagnostics ────────────────────────────────────────────────────────────────
_SCRIPT_START = _time.time()
def _ts(): return _dt.now().strftime("%H:%M:%S")
def ok(m):   print(f"  [{_ts()}] ✅ {m}")
def info(m): print(f"  [{_ts()}] ℹ️  {m}")
def warn(m): print(f"  [{_ts()}] ⚠️  {m}")
def die(m, r=None):
    print(f"\n  ❌ FAILED: {m}")
    if r is not None: print(f"  HTTP {r.status_code}: {r.text[:600]}")
    sys.exit(1)

_phase_counter = [0]
TOTAL_PHASES = 4
def phase(label):
    _phase_counter[0] += 1
    print(f"\n[{_phase_counter[0]}/{TOTAL_PHASES}] {label}...")

def mac_notify(title, message):
    try:
        script = f'display notification "{message}" with title "{title}" sound name "Glass"'
        with tempfile.NamedTemporaryFile(mode="w", suffix=".applescript", delete=False) as f:
            f.write(script); fpath = f.name
        subprocess.run(["osascript", fpath], check=False, capture_output=True)
        os.unlink(fpath)
    except Exception:
        pass

# ── Auth ───────────────────────────────────────────────────────────────────────
from connections import load_config, get_tableau_token, tableau_headers
import tableauserverclient as TSC

config = load_config()
tc = config["tableau"]
TC_SERVER_URL = tc["server_url"].rstrip("/")

# ── PHASE 1: Generate synthetic data ──────────────────────────────────────────
phase("Generating synthetic data")

np.random.seed(42)
months = pd.date_range(START_DATE, TODAY, freq="MS")

# Real utility clients that Resource Innovations works with
utility_clients = [
    {"client_id": "CLI01", "client_name": "ComEd",                   "region": "Midwest",    "program_count": 12, "contracted_mwh": 45000},
    {"client_id": "CLI02", "client_name": "National Grid",           "region": "Northeast",  "program_count": 9,  "contracted_mwh": 38000},
    {"client_id": "CLI03", "client_name": "Southern California Edison","region": "West",      "program_count": 15, "contracted_mwh": 52000},
    {"client_id": "CLI04", "client_name": "ERCOT Partners",          "region": "South",      "program_count": 7,  "contracted_mwh": 28000},
    {"client_id": "CLI05", "client_name": "Eversource",              "region": "Northeast",  "program_count": 6,  "contracted_mwh": 22000},
]

# Program types Resource Innovations actually manages
program_types = ["Residential Retrofit", "HVAC Upgrade", "Commercial Lighting", "EV Charging Enablement", "Load Flexibility"]

def signal_ramp(d, onset=SIGNAL_ONSET_VAL, duration=6, shape=SIGNAL_SHAPE):
    mft = (d.year - TODAY.year) * 12 + (d.month - TODAY.month)
    if mft <= onset: return 0.0
    progress = min(1.0, (mft - onset) / duration)
    if shape == "ramp":        return progress
    if shape == "accelerating": return progress ** 2
    if shape == "step":         return 1.0 if progress >= 0.3 else 0.0
    return progress

fact_rows = []
for month in months:
    for client in utility_clients:
        signal = signal_ramp(month)
        cid = client["client_id"]

        # ── PRIMARY 1: kWh Savings Delivery Rate ──────────────────────────────
        # Contracted vs. delivered — the compliance story. Healthy ~94–98%.
        # Signal drop: ~37% relative decline → from ~96% to ~60% at worst.
        base_delivery = {"CLI01": 0.96, "CLI02": 0.94, "CLI03": 0.97, "CLI04": 0.93, "CLI05": 0.95}[cid]
        delivery_rate = round(base_delivery - (signal * SIGNAL_MAGNITUDE * base_delivery) + np.random.uniform(-0.01, 0.01), 4)
        delivery_rate = max(0.30, min(1.0, delivery_rate))

        # Contracted kWh for month (annualized / 12 with seasonal variation)
        seasonal = 1.0 + 0.08 * np.sin((month.month - 1) * np.pi / 6)
        contracted_kwh = round(client["contracted_mwh"] * 1000 / 12 * seasonal + np.random.uniform(-2000, 2000))
        delivered_kwh  = round(contracted_kwh * delivery_rate)

        # ── PRIMARY 2: Cost per Participant ───────────────────────────────────
        # Rises as completion rates fall (fixed costs spread over fewer completions).
        # Healthy ~$180–$210 depending on client. Signal rise: ~37% increase.
        base_cpp = {"CLI01": 192.0, "CLI02": 205.0, "CLI03": 188.0, "CLI04": 178.0, "CLI05": 198.0}[cid]
        cost_per_participant = round(base_cpp * (1 + signal * SIGNAL_MAGNITUDE) + np.random.uniform(-5, 5), 2)

        # ── SUPPORTING: Program completion rate ───────────────────────────────
        base_completion = {"CLI01": 0.82, "CLI02": 0.79, "CLI03": 0.84, "CLI04": 0.78, "CLI05": 0.81}[cid]
        completion_rate = round(base_completion - (signal * SUPPORTING_MAGNITUDE * 1.2) + np.random.uniform(-0.015, 0.015), 4)
        completion_rate = max(0.40, min(1.0, completion_rate))

        # ── SUPPORTING: Participant enrollment ────────────────────────────────
        base_enrollments = {"CLI01": 3800, "CLI02": 2900, "CLI03": 4200, "CLI04": 2100, "CLI05": 1800}[cid]
        enrollments = int(base_enrollments * (1 - signal * SUPPORTING_MAGNITUDE * 0.8) + np.random.randint(-80, 80))

        # ── SUPPORTING: Customer satisfaction (utility partner NPS) ───────────
        base_nps = {"CLI01": 48, "CLI02": 45, "CLI03": 51, "CLI04": 43, "CLI05": 46}[cid]
        partner_nps = round(base_nps - (signal * 10 * SUPPORTING_MAGNITUDE / 0.12) + np.random.uniform(-3, 3), 1)

        # ── SUPPORTING: Average incentive per kWh (efficiency metric) ─────────
        # Rises as delivery falls — more incentive spend per unit of savings achieved
        base_incentive = {"CLI01": 0.082, "CLI02": 0.091, "CLI03": 0.078, "CLI04": 0.095, "CLI05": 0.087}[cid]
        incentive_per_kwh = round(base_incentive * (1 + signal * SUPPORTING_MAGNITUDE) + np.random.uniform(-0.003, 0.003), 4)

        # Program type assignment by client/month hash for realistic segmentation
        prog_type = program_types[hash(cid + month.strftime("%Y%m")) % len(program_types)]

        fact_rows.append({
            "record_id":           f"{cid}_{month.strftime('%Y%m')}",
            "Date":                str(month.date()),
            "Client ID":           cid,
            "Client Name":         client["client_name"],
            "Region":              client["region"],
            "Program Type":        prog_type,
            "Contracted kWh":      float(contracted_kwh),
            "Delivered kWh":       float(delivered_kwh),
            "Savings Delivery Rate": delivery_rate,
            "Cost per Participant": cost_per_participant,
            "Completion Rate":     completion_rate,
            "Enrollments":         float(enrollments),
            "Partner NPS":         partner_nps,
            "Incentive per kWh":   incentive_per_kwh,
        })

df_fact = pd.DataFrame(fact_rows)

# Sanity check
sample = df_fact[df_fact["Client ID"] == "CLI03"].sort_values("Date")
_first6 = sample.head(6)["Savings Delivery Rate"].mean()
_last6  = sample.tail(6)["Savings Delivery Rate"].mean()
_cpp_first = sample.head(6)["Cost per Participant"].mean()
_cpp_last  = sample.tail(6)["Cost per Participant"].mean()
info(f"SCE Savings Delivery Rate: first 6mo avg={_first6:.1%}  last 6mo avg={_last6:.1%}  drop={(_first6-_last6)/_first6:.1%}")
info(f"SCE Cost per Participant:  first 6mo avg=${_cpp_first:.0f}  last 6mo avg=${_cpp_last:.0f}  rise={(_cpp_last-_cpp_first)/_cpp_first:.1%}")
ok(f"Fact table: {len(df_fact)} rows ({len(utility_clients)} clients × {len(months)} months)")

# ── PULSE PHASES ───────────────────────────────────────────────────────────────
from tableauhyperapi import (HyperProcess, Telemetry, Connection, TableDefinition,
                              SqlType, TableName, Inserter, CreateMode, Date, NOT_NULLABLE)

# ── PHASE 2: Publish datasource ────────────────────────────────────────────────
phase("Publishing datasource to Tableau Cloud")

tc_server, tc_auth_token, tc_site_id = get_tableau_token(config)
tc_pulse_base = f"{TC_SERVER_URL}/api/-/pulse"
tc_base_url   = f"{TC_SERVER_URL}/api/{tc_server.version}/sites/{tc_site_id}"
tc_hdrs        = {"X-Tableau-Auth": tc_auth_token, "Accept": "application/json"}
tc_hdrs_create = {**tc_hdrs, "Content-Type": "application/vnd.tableau.metricqueryservice.v1.CreateDefinitionRequest+json"}
tc_hdrs_xml    = {**tc_hdrs, "Content-Type": "application/xml", "Accept": "application/xml"}

# Clean up previous RI projects + definitions
all_projects, _ = tc_server.projects.get()
for p in all_projects:
    if p.name.startswith("Resource Innovations |"):
        tc_server.projects.delete(p.id)
        info(f"Deleted old project: {p.name}")

# Paginate through all Pulse definitions, delete RI ones
npt = ""
while True:
    params = {"page_size": 100}
    if npt: params["page_token"] = npt
    r_defs = requests.get(f"{tc_pulse_base}/definitions", headers=tc_hdrs, params=params)
    defs_page = r_defs.json().get("definitions", []) if r_defs.ok else []
    for d in defs_page:
        if d.get("name", "").startswith("RI "):
            requests.delete(f"{tc_pulse_base}/definitions/{d['metadata']['id']}", headers=tc_hdrs)
            info(f"Deleted old definition: {d.get('name')}")
    npt = r_defs.json().get("next_page_token", "") if r_defs.ok else ""
    if not npt:
        break

# Clean up existing RI groups
r_grps = requests.get(f"{tc_base_url}/groups?pageSize=100", headers=tc_hdrs_xml)
if r_grps.ok:
    root_g = ET.fromstring(r_grps.content)
    ns = "{http://tableau.com/api}"
    for grp_el in root_g.findall(f".//{ns}group") or root_g.findall(".//group"):
        grp_name = grp_el.get("name", "")
        grp_id   = grp_el.get("id", "")
        if grp_name.startswith("Resource Innovations |") and grp_id:
            requests.delete(f"{tc_base_url}/groups/{grp_id}", headers=tc_hdrs)
            info(f"Deleted old group: {grp_name}")

# Create project
pulse_project_name = f"Resource Innovations | {TIMESTAMP}"
proj = tc_server.projects.create(TSC.ProjectItem(name=pulse_project_name))
ok(f"Project created: {pulse_project_name}")

PULSE_DS_NAME = "Resource Innovations - Energy Portfolio"
hyper_path = Path(tempfile.mkdtemp()) / "resource_innovations_energy_portfolio.hyper"

with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hyper:
    with Connection(hyper.endpoint, str(hyper_path), CreateMode.CREATE_AND_REPLACE) as conn:
        conn.catalog.create_schema_if_not_exists("Extract")
        tbl = TableDefinition(TableName("Extract", "Extract"), [
            TableDefinition.Column("Record ID",             SqlType.text(),   NOT_NULLABLE),
            TableDefinition.Column("Date",                  SqlType.date(),   NOT_NULLABLE),
            TableDefinition.Column("Client ID",             SqlType.text(),   NOT_NULLABLE),
            TableDefinition.Column("Client Name",           SqlType.text(),   NOT_NULLABLE),
            TableDefinition.Column("Region",                SqlType.text(),   NOT_NULLABLE),
            TableDefinition.Column("Program Type",          SqlType.text(),   NOT_NULLABLE),
            TableDefinition.Column("Contracted kWh",        SqlType.double(), NOT_NULLABLE),
            TableDefinition.Column("Delivered kWh",         SqlType.double(), NOT_NULLABLE),
            TableDefinition.Column("Savings Delivery Rate", SqlType.double(), NOT_NULLABLE),
            TableDefinition.Column("Cost per Participant",  SqlType.double(), NOT_NULLABLE),
            TableDefinition.Column("Completion Rate",       SqlType.double(), NOT_NULLABLE),
            TableDefinition.Column("Enrollments",           SqlType.double(), NOT_NULLABLE),
            TableDefinition.Column("Partner NPS",           SqlType.double(), NOT_NULLABLE),
            TableDefinition.Column("Incentive per kWh",     SqlType.double(), NOT_NULLABLE),
        ])
        conn.catalog.create_table(tbl)
        col_map = {
            "Record ID":             "record_id",
            "Date":                  "Date",
            "Client ID":             "Client ID",
            "Client Name":           "Client Name",
            "Region":                "Region",
            "Program Type":          "Program Type",
            "Contracted kWh":        "Contracted kWh",
            "Delivered kWh":         "Delivered kWh",
            "Savings Delivery Rate": "Savings Delivery Rate",
            "Cost per Participant":  "Cost per Participant",
            "Completion Rate":       "Completion Rate",
            "Enrollments":           "Enrollments",
            "Partner NPS":           "Partner NPS",
            "Incentive per kWh":     "Incentive per kWh",
        }
        with Inserter(conn, tbl) as ins:
            for _, row in df_fact.iterrows():
                d_raw = row["Date"]
                d = d_raw if hasattr(d_raw, "year") else _dt.strptime(str(d_raw), "%Y-%m-%d").date()
                ins.add_row([
                    str(row["record_id"]),
                    Date(d.year, d.month, d.day),
                    str(row["Client ID"]),
                    str(row["Client Name"]),
                    str(row["Region"]),
                    str(row["Program Type"]),
                    float(row["Contracted kWh"]),
                    float(row["Delivered kWh"]),
                    float(row["Savings Delivery Rate"]),
                    float(row["Cost per Participant"]),
                    float(row["Completion Rate"]),
                    float(row["Enrollments"]),
                    float(row["Partner NPS"]),
                    float(row["Incentive per kWh"]),
                ])
            ins.execute()

ds_item = TSC.DatasourceItem(project_id=proj.id, name=PULSE_DS_NAME)
ds_item = tc_server.datasources.publish(ds_item, str(hyper_path), mode=TSC.Server.PublishMode.Overwrite)
PULSE_DS_LUID = ds_item.id
ok(f"Datasource published: {PULSE_DS_NAME} (luid: {PULSE_DS_LUID})")

# ── PHASE 3: Create Pulse metrics ──────────────────────────────────────────────
phase("Creating Pulse metrics")

PULSE_METRICS = [
    # (name, description, field, aggregation, format, sentiment)
    (
        "RI Savings Delivery Rate",
        "% of contracted kWh savings actually delivered. Target ≥94%. Compliance risk below 85%.",
        "Savings Delivery Rate", "AGGREGATION_AVERAGE",
        "NUMBER_FORMAT_TYPE_PERCENT", "SENTIMENT_TYPE_UP_IS_GOOD",
    ),
    (
        "RI Cost per Participant",
        "Program delivery cost per enrolled participant. Rising cost = falling efficiency.",
        "Cost per Participant", "AGGREGATION_AVERAGE",
        "NUMBER_FORMAT_TYPE_NUMBER", "SENTIMENT_TYPE_UP_IS_GOOD",
    ),
    (
        "RI Program Completion Rate",
        "% of enrolled participants who complete the program. Drives savings delivery.",
        "Completion Rate", "AGGREGATION_AVERAGE",
        "NUMBER_FORMAT_TYPE_PERCENT", "SENTIMENT_TYPE_UP_IS_GOOD",
    ),
    (
        "RI Total Enrollments",
        "Monthly program enrollments across all utility clients.",
        "Enrollments", "AGGREGATION_SUM",
        "NUMBER_FORMAT_TYPE_NUMBER", "SENTIMENT_TYPE_UP_IS_GOOD",
    ),
    (
        "RI Delivered kWh",
        "Total kWh savings delivered across the portfolio this period.",
        "Delivered kWh", "AGGREGATION_SUM",
        "NUMBER_FORMAT_TYPE_NUMBER", "SENTIMENT_TYPE_UP_IS_GOOD",
    ),
    (
        "RI Partner NPS",
        "Utility client satisfaction score (Net Promoter Score). Healthy above 40.",
        "Partner NPS", "AGGREGATION_AVERAGE",
        "NUMBER_FORMAT_TYPE_NUMBER", "SENTIMENT_TYPE_UP_IS_GOOD",
    ),
]

pulse_metric_ids = []
for name, desc, field, agg, fmt, sentiment in PULSE_METRICS:
    payload = {
        "name": name,
        "specification": {
            "datasource": {"id": PULSE_DS_LUID},
            "basic_specification": {
                "measure": {"field": field, "aggregation": agg},
                "time_dimension": {"field": "Date"},
                "filters": [],
            },
            "is_running_total": False,
        },
        "extension_options": {
            "allowed_dimensions": ["Client Name", "Region", "Program Type"],
            "allowed_granularities": ["GRANULARITY_BY_MONTH", "GRANULARITY_BY_QUARTER", "GRANULARITY_BY_YEAR"],
            "offset_from_today": 1,
            "correlation_candidate_definition_ids": [],
            "use_dynamic_offset": False,
        },
        "representation_options": {"type": fmt, "sentiment_type": sentiment},
        "insights_options": {"show_insights": True},
        "comparisons": {"comparisons": [{"compare_config": {"comparison": "TIME_COMPARISON_PREVIOUS_PERIOD"}, "index": 0}]},
        "certification": {"is_certified": False},
        "datasource_goals": [],
        "related_links": [],
    }
    r = requests.post(f"{tc_pulse_base}/definitions", headers=tc_hdrs_create, json=payload)
    if r.status_code in (200, 201):
        def_id = r.json()["definition"]["metadata"]["id"]
        r2 = requests.get(f"{tc_pulse_base}/definitions/{def_id}/metrics", headers=tc_hdrs)
        ml = r2.json().get("metrics", []) if r2.ok else []
        if ml:
            mid = ml[0]["id"]
            pulse_metric_ids.append({"name": name, "metric_id": mid})
            ok(f"Pulse metric: {name}")
        else:
            warn(f"Metric created but no metric_id: {name}")
    else:
        warn(f"Metric failed: {name} — {r.status_code} {r.text[:200]}")

pulse_metric_count = len(pulse_metric_ids)

# ── PHASE 4: Create group + subscribe ──────────────────────────────────────────
phase("Creating group and subscribing to metrics")

pulse_group_name = f"Resource Innovations | {TIMESTAMP}"
r = requests.post(
    f"{tc_base_url}/groups", headers=tc_hdrs_xml,
    data=f'<?xml version="1.0" encoding="UTF-8"?><tsRequest><group name="{pulse_group_name}"/></tsRequest>'.encode()
)
tc_group_id = None
if r.ok:
    root = ET.fromstring(r.content)
    grp = root.find(".//{http://tableau.com/api}group")
    if grp is None:
        grp = root.find(".//group")
    if grp is None:
        die("Group was created but could not parse group ID from response")
    tc_group_id = grp.get("id")
    if tc_group_id is None:
        die("Group element found but 'id' attribute is missing")
    ok(f"Group created: {pulse_group_name} ({tc_group_id})")
else:
    die("Group creation failed", r)

for m in pulse_metric_ids:
    sub_payload = {"metric_id": m["metric_id"], "followers": [{"group_id": tc_group_id}]}
    sub_r = requests.post(f"{tc_pulse_base}/subscriptions:batchCreate", headers=tc_hdrs, json=sub_payload)
    if sub_r.ok:
        sub_data = sub_r.json()
        subs = sub_data.get("subscriptions", [])
        if subs:
            gid = subs[0].get("group_id") or subs[0].get("follower", {}).get("group_id")
            if gid is None:
                warn(f"Subscription for {m['name']} — group_id null in response; raw: {str(sub_data)[:200]}")
            else:
                ok(f"Subscribed: {m['name']}")
        else:
            ok(f"Subscribed: {m['name']} (no subs array in response — may be normal)")
    else:
        warn(f"Subscription failed for {m['name']}: {sub_r.status_code} {sub_r.text[:150]}")

tc_server.auth.sign_out()

# ── Post-build docs ────────────────────────────────────────────────────────────
elapsed = int(_time.time() - _SCRIPT_START)

DEMO_DIR = Path(__file__).parent

# ── Guide markdown ─────────────────────────────────────────────────────────────
guide_path = DEMO_DIR / f"{company_slug}_{use_case_slug}_guide.md"
guide_path.write_text(f"""# Resource Innovations — Energy Portfolio Performance Demo Guide

**Persona:** {PERSONA}
**Story:** {STORY}
**Built:** {_dt.now().strftime("%Y-%m-%d %H:%M")}

## The Story

Resource Innovations manages 800+ energy programs for 205 utility clients globally.
This demo shows the Head of Energy Services a portfolio in distress: kWh savings
delivery rates have declined ~35% over the last 6 months — driven primarily by
falling completion rates in Residential Retrofit and HVAC Upgrade programs. As
completion falls, fixed costs are spread over fewer participants, so cost-per-participant
is climbing even as delivery suffers. This is a margin squeeze and a compliance risk
(many utility contracts include savings guarantees with financial penalties for shortfall).

## Primary Metrics (the "uh oh" signal)

| Metric | Trend | Story |
|--------|-------|-------|
| Savings Delivery Rate | ↓ ~35% drop over 6mo | Compliance risk — contracts have savings guarantees |
| Cost per Participant | ↑ ~37% rise over 6mo | Margin squeeze — same fixed cost, fewer completions |

## Supporting Metrics (the "why")

| Metric | Trend | Story |
|--------|-------|-------|
| Program Completion Rate | ↓ Declining | Root cause — fewer participants finishing = less kWh delivered |
| Total Enrollments | ↓ Declining | Leading indicator — pipeline is thinning |
| Partner NPS | ↓ Softening | Lagging consequence — utility clients are noticing |
| Delivered kWh | ↓ Falling | Volume confirmation of the delivery rate story |

## Demo Flow

1. **Open Savings Delivery Rate** — show the 6-month decline. Point to the 94% healthy threshold.
   "We're contracted to deliver. Falling below 85% triggers penalty clauses with several clients."
2. **Segment by Client** — SCE and ComEd are the most affected. Both are large, high-value contracts.
3. **Segment by Program Type** — Residential Retrofit and HVAC Upgrade are dragging the portfolio.
4. **Open Cost per Participant** — rising in lockstep. "It's costing us more to deliver less."
5. **Show Completion Rate** — the causal link. "Participants aren't finishing programs. That's why both metrics are moving."
6. **Show Partner NPS** — "Our clients are starting to feel it. This is a retention risk."

## Pulse Questions to Demo

- "Which client has the lowest savings delivery rate?"
- "How has our cost per participant trended this year?"
- "Which program type has the worst completion rate?"
- "Compare this quarter's delivery rate to last quarter"
- "Which region is underperforming on enrollments?"

## Tableau Pulse Assets

- **Project:** {pulse_project_name}
- **Datasource:** {PULSE_DS_NAME}
- **Group:** {pulse_group_name}
- **Metrics created:** {pulse_metric_count}/6
- **URL:** {TC_SERVER_URL}/pulse
""")
ok(f"Guide written: {guide_path.name}")

# ── Concierge walkthrough .docx ────────────────────────────────────────────────
def _add_heading(doc, text, level=1, color=None):
    p = doc.add_heading(text, level=level)
    if color:
        for run in p.runs:
            run.font.color.rgb = RGBColor(*color)
    return p

def _add_para(doc, text, bold=False):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold
    return p

def _add_question(doc, question, expected):
    p = doc.add_paragraph()
    p.add_run("Ask: ").bold = True
    p.add_run(f'"{question}"').italic = True
    _add_para(doc, expected)
    doc.add_paragraph()

docx_path = DEMO_DIR / f"{company_slug}_{use_case_slug}_demo_walkthrough.docx"
doc = Document()

t = doc.add_heading(f"{COMPANY_NAME} — {USE_CASE}", 0)
for run in t.runs:
    run.font.color.rgb = RGBColor(2, 35, 77)
t2 = doc.add_heading("Demo Walkthrough — Tableau Pulse", 1)
for run in t2.runs:
    run.font.color.rgb = RGBColor(80, 80, 80)

doc.add_paragraph(f"Persona: {PERSONA}  |  Built: {_dt.now().strftime('%Y-%m-%d %H:%M')}")
doc.add_paragraph(f"Story: {STORY}")
doc.add_paragraph()

_add_heading(doc, "Tableau Pulse", 1, color=(2, 35, 77))
doc.add_paragraph(
    "Resource Innovations manages over 800 active energy programs. Pulse surfaces "
    "the portfolio-level story — savings delivery shortfalls and rising costs — "
    "the moment they start moving, without requiring anyone to open a dashboard."
)

_add_heading(doc, "Setup", 2)
for item in [
    f"Navigate to Tableau Pulse: {TC_SERVER_URL}/pulse",
    f'Find the group "{pulse_group_name}" in your subscriptions',
    "Confirm all 6 metrics are visible",
    "Set the time range to Last 6 months",
]:
    doc.add_paragraph(item, style="List Bullet")

_add_heading(doc, "Part 1 — Orient the audience (30 seconds)", 2)
_add_para(doc,
    "Name the 6 metrics quickly. The goal is to get to Savings Delivery Rate and "
    "Cost per Participant in the first 30 seconds — those two together tell the whole story.")
for m in [
    "Savings Delivery Rate ← PRIMARY. This is the compliance story. Healthy ≥94%.",
    "Cost per Participant ← PRIMARY. The margin story. Rising in lockstep with the delivery drop.",
    "Program Completion Rate — the root cause. Explains why both primaries are moving.",
    "Total Enrollments — leading indicator. The pipeline is thinning.",
    "Partner NPS — lagging indicator. Utility clients are beginning to feel it.",
    "Delivered kWh — volume confirmation.",
]:
    doc.add_paragraph(f"• {m}")
_add_para(doc,
    '"I\'m going to focus on Savings Delivery Rate first — it\'s the compliance risk. '
    'Then Cost per Participant — that\'s the margin story. Everything else explains why."',
    bold=True)

_add_heading(doc, "Part 2 — Lead with Savings Delivery Rate", 2)
_add_para(doc, "Click on the Savings Delivery Rate metric card.", bold=True)
for step in [
    "Show the 6-month time-series — the decline should be immediately obvious.",
    "Point to the 94% healthy threshold. Several clients are now in penalty territory.",
    "Expand Breakdown by Client — SCE and ComEd are the most affected.",
    "Expand Breakdown by Program Type — Residential Retrofit and HVAC Upgrade are the drivers.",
    '"Pulse identified the breakdown automatically. I didn\'t build a filter — it found the most diagnostic dimensions."',
]:
    doc.add_paragraph(f"• {step}")

_add_heading(doc, "Part 3 — Pivot to Cost per Participant", 2)
_add_para(doc, "Navigate to the Cost per Participant metric card.", bold=True)
for step in [
    "Show the rising trend — mirrors the delivery decline almost exactly.",
    "Point out: fixed program costs are spreading over fewer completions.",
    '"When delivery falls, costs don\'t fall with it. The result is an efficiency spiral — we\'re paying more to deliver less."',
    "Expand by Program Type — same culprits: Residential Retrofit and HVAC Upgrade.",
]:
    doc.add_paragraph(f"• {step}")

_add_heading(doc, "Part 4 — Pulse Discover questions", 2)
_add_para(doc, "Use the 'Ask a question' field. Lead with delivery, pivot to cost, close on risk.", bold=True)

questions = [
    ("How has savings delivery rate trended over the last 6 months?",
     "Quantifies the decline with period-over-period comparison. Surfaces the acceleration in the last 3 months."),
    ("Which client has the lowest savings delivery rate?",
     "SCE or ComEd surfaces — high-value contracts with the deepest shortfall. 'Uh oh' moment."),
    ("Which program type is driving the delivery shortfall?",
     "Residential Retrofit and HVAC Upgrade called out. Now the team has a specific program category to investigate."),
    ("What is driving cost per participant up?",
     "Pulse cross-references completion rate as the correlated driver — surfaces the causal story."),
    ("How does this quarter's delivered kWh compare to last quarter?",
     "Period-over-period — gives the audience a concrete number to take back to leadership."),
    ("Which region has the lowest partner NPS?",
     "Shows which utility relationships are at risk — sets up the retention conversation."),
]
for q, e in questions:
    _add_question(doc, q, f"What to expect: {e}")

_add_heading(doc, "Key Talking Points", 2)
for pt in [
    '"Two metrics, one story: delivery is down, cost is up. That\'s a margin squeeze and a compliance risk happening simultaneously."',
    '"Pulse flags this the moment the trend starts. The Head of Energy Services doesn\'t wait for a quarterly review — they know in real time."',
    '"The breakdown by program type tells us exactly where to act. Residential Retrofit and HVAC are fixable — they\'re completion problems, not enrollment problems."',
    '"Partner NPS is a lagging indicator here. By the time it moves, the client relationship is already at risk. Pulse catches the leading signal — delivery rate — weeks earlier."',
]:
    doc.add_paragraph(pt, style="List Bullet")

_add_heading(doc, "Business Preferences (SDM) — For Tableau Next Builds", 2)
doc.add_paragraph(
    "If this demo is extended to Tableau Next, paste the following into: "
    "Data 360 → Semantic Model → [SDM] → AI Optimization → Manage Business Preferences"
)
doc.add_paragraph()

business_prefs = [
    "# Resource Innovations manages energy efficiency and demand-side management programs for utility clients across the US.",
    "# The most important metric is Savings Delivery Rate — it measures how much of contracted kWh savings was actually delivered.",
    "# A healthy Savings Delivery Rate is ≥94%. Below 85% triggers financial penalty clauses in most utility contracts.",
    "# Cost per Participant rises when completion rates fall — these two metrics are inversely correlated and should always be analyzed together.",
    "# Program Completion Rate is the primary root-cause dimension for both delivery and cost problems.",
    "# The most diagnostically useful dimensions are: Client Name, Program Type, and Region.",
    "# Residential Retrofit and HVAC Upgrade programs have the most variability in completion rates and are the most common sources of portfolio underperformance.",
    "# Partner NPS is a lagging indicator — it moves 2–3 months after delivery rate declines begin. Use it to gauge relationship risk, not operational performance.",
    "# When Savings Delivery Rate declines, always check Completion Rate and Program Type first — these explain the majority of historical shortfalls.",
    "# The default comparison period for trend analysis is last 6 months vs. prior 6 months.",
    "# Total Enrollments is a leading indicator — a decline in enrollments today will translate to delivery shortfalls in 2–3 months.",
]
for line in business_prefs:
    doc.add_paragraph(line)

doc.save(str(docx_path))
ok(f"Walkthrough saved: {docx_path.name}")

# ── Final summary ──────────────────────────────────────────────────────────────
print(f"\n{'='*66}")
print(f"  ✅ Resource Innovations Energy Portfolio — BUILD COMPLETE ({elapsed}s)")
print(f"  {'─'*62}")
print(f"  PULSE")
print(f"  Project:    {pulse_project_name}")
print(f"  Datasource: {PULSE_DS_NAME}")
print(f"  Metrics:    {pulse_metric_count}/6 created")
print(f"  Group:      {pulse_group_name}")
print(f"  🔗 {TC_SERVER_URL}/pulse")
print(f"  {'─'*62}")
print(f"  FILES")
print(f"  Guide:      {guide_path}")
print(f"  Walkthrough: {docx_path}")
print(f"  {'─'*62}")
print(f"{'='*66}\n")

mac_notify("Analytics Builder", f"Resource Innovations demo ready! ({elapsed}s)")
