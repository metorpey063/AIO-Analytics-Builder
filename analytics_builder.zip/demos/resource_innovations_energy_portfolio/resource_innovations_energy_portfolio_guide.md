# Resource Innovations — Energy Portfolio Performance Demo Guide

**Persona:** Head of Energy Services
**Story:** kWh savings delivery falling short of contracted targets while cost-per-participant rises — a margin and compliance squeeze across the program portfolio
**Built:** 2026-05-21 12:48

## The Story

Resource Innovations manages 800+ energy programs for 205 utility clients globally.
This demo shows the Head of Energy Services a portfolio in distress: kWh savings
delivery rates have declined ~35% over the last 6 months — driven primarily by
falling completion rates in Residential Retrofit and HVAC Upgrade programs. As
completion falls, fixed costs are spread over fewer participants, so cost-per-participant
is climbing even as delivery suffers. This is a margin squeeze and a compliance risk
(many utility contracts include savings guarantees with financial penalties for shortfall).

## Primary Metrics (the "uh oh" signal)

| Metric | Trend | Story |
|--------|-------|-------|
| Savings Delivery Rate | ↓ ~35% drop over 6mo | Compliance risk — contracts have savings guarantees |
| Cost per Participant | ↑ ~37% rise over 6mo | Margin squeeze — same fixed cost, fewer completions |

## Supporting Metrics (the "why")

| Metric | Trend | Story |
|--------|-------|-------|
| Program Completion Rate | ↓ Declining | Root cause — fewer participants finishing = less kWh delivered |
| Total Enrollments | ↓ Declining | Leading indicator — pipeline is thinning |
| Partner NPS | ↓ Softening | Lagging consequence — utility clients are noticing |
| Delivered kWh | ↓ Falling | Volume confirmation of the delivery rate story |

## Demo Flow

1. **Open Savings Delivery Rate** — show the 6-month decline. Point to the 94% healthy threshold.
   "We're contracted to deliver. Falling below 85% triggers penalty clauses with several clients."
2. **Segment by Client** — SCE and ComEd are the most affected. Both are large, high-value contracts.
3. **Segment by Program Type** — Residential Retrofit and HVAC Upgrade are dragging the portfolio.
4. **Open Cost per Participant** — rising in lockstep. "It's costing us more to deliver less."
5. **Show Completion Rate** — the causal link. "Participants aren't finishing programs. That's why both metrics are moving."
6. **Show Partner NPS** — "Our clients are starting to feel it. This is a retention risk."

## Pulse Questions to Demo

- "Which client has the lowest savings delivery rate?"
- "How has our cost per participant trended this year?"
- "Which program type has the worst completion rate?"
- "Compare this quarter's delivery rate to last quarter"
- "Which region is underperforming on enrollments?"

## Tableau Pulse Assets

- **Project:** Resource Innovations | 2026-05-21 12:48
- **Datasource:** Resource Innovations - Energy Portfolio
- **Group:** Resource Innovations | 2026-05-21 12:48
- **Metrics created:** 6/6
- **URL:** https://us-east-1.online.tableau.com/pulse
