# TriNet Benefits Enrollment Demo Guide

## Overview
This demo tells the story of **benefits enrollment rates dropping among SMB clients** — a signal
that directly impacts client retention and TriNet's revenue. The primary audience is a **VP of Benefits**.

## Story arc
1. **Open with the problem** — Benefits Enrollment Rate sparkline shows a clear step-down ~3 months ago
2. **Confirm with voluntary opt-in** — Voluntary Benefits Opt-in Rate shows the same pattern
3. **Dig into why** — filter by Vertical → Technology and Life Sciences clients are driving the decline
4. **Size matters** — filter by Size Band → Micro clients (3-25 employees) are highest risk
5. **The business impact** — Client Retention Rate is beginning to drift as a lagging consequence

## Key metrics
| Metric | Type | Healthy range | Current story |
|--------|------|--------------|---------------|
| Benefits Enrollment Rate | Primary | 68–82% | Dropped ~25% from baseline |
| Voluntary Benefits Opt-in Rate | Primary | 48–64% | Dropped ~25% from baseline |
| Benefits Utilization Rate | Supporting | 55–72% | Soft ~12% decline |
| Employee Satisfaction Score | Supporting | 4.1–4.5 | Soft ~12% decline |
| Open Enrollment Completion Rate | Supporting | 72–88% | Soft ~12% decline |
| Client Retention Rate | Supporting | 88–96% | Early drift visible |

## Demo click path (Tableau Next)
1. Open **TriNet Benefits Enrollment Dashboard**
2. Point to the Benefits Enrollment Rate metric tile — "something changed about 3 months ago"
3. Click through to the trend viz — confirm the step change
4. Filter by **Vertical = Technology** — the decline is concentrated here
5. Filter by **Size Band = Micro (3-25)** — highest severity
6. Switch to Voluntary Opt-in Rate — same pattern confirms it's systemic
7. Show Client Retention Rate beginning to move — "this is the business consequence"

## Concierge prompts
- "Which client segment has the biggest drop in benefits enrollment?"
- "What's driving the decline in voluntary opt-in rates over the last 3 months?"
- "Show me clients at risk of churning based on their enrollment trends"
- "Compare benefits utilization between Technology and Professional Services clients"

## Assets created
- Workspace: `trinet_benefits_enrollment`
- SDM: `TriNet_Benefits_Analytics_07a`
- Data Object: `Benefits_Activity`
- Dashboard: `trinet_benefits_dashboard`

## Post-build checklist
- [ ] Enable Analytics Agent Readiness: Data 360 → Semantic Model → Settings → Analytics Agent Readiness → ON
- [ ] Paste Business Preferences into the SDM (see walkthrough .docx)
- [ ] Verify dashboard loads in your Tableau Next workspace
