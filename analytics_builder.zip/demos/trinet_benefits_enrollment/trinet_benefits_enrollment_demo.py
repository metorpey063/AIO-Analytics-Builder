"""
TriNet — Benefits Enrollment Demo
Use case : Benefits enrollment rates dropping among SMB clients
Persona  : VP of Benefits
Output   : Tableau Next (Data Cloud + Semantic Model + Dashboard)
"""

import sys, os, json, time, uuid, math, requests
import pandas as pd
import numpy as np
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from connections import load_config, get_sf_token, get_dc_token, sf_headers, dc_headers

# ── Advanced settings ─────────────────────────────────────────────────────────
HISTORY_MONTHS        = 12       # 12 months daily grain
GRAIN                 = "daily"  # daily / weekly / monthly
SIGNAL_MAGNITUDE      = 0.25    # 25% drop on primary metrics
SIGNAL_ONSET          = -3      # 3 months ago
SIGNAL_SHAPE          = "step"  # ramp / accelerating / step
SUPPORTING_MAGNITUDE  = 0.12    # 12% movement on supporting metrics

TODAY        = date.today()
COMPANY      = "TriNet"
SLUG         = "trinet"
USE_CASE     = "benefits_enrollment"
SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
CHECKPOINT_F = os.path.join(SCRIPT_DIR, f"{SLUG}_{USE_CASE}_checkpoint.json")

print(f"""
╔══════════════════════════════════════════════════════════╗
  TriNet — Benefits Enrollment Demo
  History: {HISTORY_MONTHS}mo  Grain: {GRAIN}
  Signal: {int(SIGNAL_MAGNITUDE*100)}% step drop, onset {SIGNAL_ONSET}mo
  Supporting: {int(SUPPORTING_MAGNITUDE*100)}% movement
╚══════════════════════════════════════════════════════════╝
""")

# ── Checkpoint helpers ────────────────────────────────────────────────────────
def load_cp():
    if os.path.exists(CHECKPOINT_F):
        with open(CHECKPOINT_F) as f:
            return json.load(f)
    return {"all_ws_apis": [], "all_sdm_apis": [], "all_viz_apis": [], "all_dash_apis": []}

def save_cp(cp):
    with open(CHECKPOINT_F, "w") as f:
        json.dump(cp, f, indent=2)

cp = load_cp()

# ── Signal function ───────────────────────────────────────────────────────────
def signal_ramp(d, onset=SIGNAL_ONSET, duration=6, shape=SIGNAL_SHAPE):
    if isinstance(d, (datetime, pd.Timestamp)):
        d = d.date()
    months_from_today = (d.year - TODAY.year) * 12 + (d.month - TODAY.month)
    months_from_onset = months_from_today - onset
    if months_from_onset <= 0:
        return 0.0
    progress = months_from_onset / duration
    if shape == "ramp":
        return min(1.0, progress)
    elif shape == "accelerating":
        return min(1.0, progress ** 2)
    elif shape == "step":
        return 1.0 if progress >= 0.3 else 0.0
    return min(1.0, progress)

# ── Data generation ───────────────────────────────────────────────────────────
print("Phase 0 — Generating synthetic data...")

np.random.seed(42)

# TriNet industry verticals
VERTICALS = ["Technology", "Professional Services", "Life Sciences", "Nonprofit", "Financial Services"]

# Client size bands (SMB)
SIZE_BANDS = ["Micro (3-25)", "Small (26-100)", "Mid-Market (101-500)"]

# US regions TriNet focuses on
REGIONS = ["West", "Southwest", "Southeast", "Northeast", "Midwest"]

# States per region (realistic TriNet markets)
REGION_STATES = {
    "West":       ["California", "Washington", "Oregon"],
    "Southwest":  ["Texas", "Arizona", "Nevada"],
    "Southeast":  ["Florida", "Georgia", "North Carolina"],
    "Northeast":  ["New York", "Massachusetts", "Pennsylvania"],
    "Midwest":    ["Illinois", "Ohio", "Michigan"],
}

# Plan cost tier — high-cost plans drive the sharpest enrollment drops
PLAN_COST_TIERS = ["Low", "Mid", "High"]

# Workforce type — proxy for job role composition
WORKFORCE_TYPES = ["Technical", "Administrative", "Sales", "Mixed"]

# Generate client universe
np.random.seed(42)
N_CLIENTS = 120
clients = []
for i in range(N_CLIENTS):
    vertical       = np.random.choice(VERTICALS)
    size_band      = np.random.choice(SIZE_BANDS, p=[0.35, 0.45, 0.20])
    region         = np.random.choice(REGIONS)
    state          = np.random.choice(REGION_STATES[region])
    # High-cost plans over-represented in Tech/Life Sciences; low-cost in Nonprofits
    cost_weights   = {"Technology": [0.20, 0.35, 0.45], "Life Sciences": [0.15, 0.40, 0.45],
                      "Nonprofit": [0.55, 0.35, 0.10]}.get(vertical, [0.30, 0.45, 0.25])
    plan_cost_tier = np.random.choice(PLAN_COST_TIERS, p=cost_weights)
    workforce_type = np.random.choice(WORKFORCE_TYPES,
                         p={"Technology": [0.60, 0.15, 0.10, 0.15],
                            "Professional Services": [0.20, 0.25, 0.30, 0.25],
                            "Life Sciences": [0.50, 0.20, 0.10, 0.20]}.get(vertical, [0.25, 0.25, 0.25, 0.25]))
    n_employees = {
        "Micro (3-25)":        np.random.randint(3, 26),
        "Small (26-100)":      np.random.randint(26, 101),
        "Mid-Market (101-500)": np.random.randint(101, 501),
    }[size_band]
    clients.append({
        "Client ID":       f"TN-{10000+i}",
        "Client Name":     f"{state[:4].upper()}-{vertical[:3].upper()}-{i:03d}",
        "Vertical":        vertical,
        "Size Band":       size_band,
        "Region":          region,
        "State":           state,
        "Plan Cost Tier":  plan_cost_tier,
        "Workforce Type":  workforce_type,
        "Employees":       n_employees,
    })
clients_df = pd.DataFrame(clients)

# Date range — daily for 12 months
start_date = TODAY - relativedelta(months=HISTORY_MONTHS)
dates = pd.date_range(start=start_date, end=TODAY, freq="D")

# Generate daily enrollment metrics per client
# We use month-level signals but daily grain (one snapshot row per client per day)
rows = []
for _, client in clients_df.iterrows():
    # High-cost plans amplify the enrollment signal — the "why is enrollment down?" answer
    cost_signal_mult = {"High": 1.5, "Mid": 1.0, "Low": 0.4}[client["Plan Cost Tier"]]
    # Micro clients also feel premium increases harder
    size_signal_mult = {"Micro (3-25)": 1.3, "Small (26-100)": 1.0, "Mid-Market (101-500)": 0.7}[client["Size Band"]]
    # Tech/Life Sciences clients have higher base enrollment AND steeper drops
    vert_base_boost  = {"Technology": 0.04, "Life Sciences": 0.03}.get(client["Vertical"], 0.0)
    # Northeast/West drive most of the regional signal
    region_signal_mult = {"Northeast": 1.3, "West": 1.2, "Midwest": 1.0, "Southwest": 0.9, "Southeast": 0.8}[client["Region"]]

    # Base enrollment rates (healthy period)
    base_enrollment_rate    = np.random.uniform(0.68, 0.82) + vert_base_boost
    base_voluntary_optin    = np.random.uniform(0.48, 0.64) + vert_base_boost * 0.5
    base_utilization_rate   = np.random.uniform(0.55, 0.72)
    base_satisfaction_score = np.random.uniform(4.1, 4.5)
    base_open_enroll_comp   = np.random.uniform(0.72, 0.88)
    base_retention_rate     = np.random.uniform(0.88, 0.96)
    # Benefit category breakdown — medical stays high, dental moderate, voluntary drops hardest
    base_medical_rate       = np.random.uniform(0.78, 0.91)   # people hold onto health coverage
    base_dental_rate        = np.random.uniform(0.62, 0.76)
    base_voluntary_rate     = np.random.uniform(0.38, 0.55)   # discretionary — drops first when costs rise

    client_sig_scale = cost_signal_mult * size_signal_mult * region_signal_mult

    for d in dates:
        sig   = signal_ramp(d)
        noise = lambda s: np.random.normal(0, s)
        # Effective signal varies by client segment
        eff_sig = min(1.0, sig * client_sig_scale)

        enrollment_rate    = base_enrollment_rate    * (1 - SIGNAL_MAGNITUDE * eff_sig)     + noise(0.008)
        voluntary_optin    = base_voluntary_optin    * (1 - SIGNAL_MAGNITUDE * eff_sig)     + noise(0.007)
        utilization_rate   = base_utilization_rate   * (1 - SUPPORTING_MAGNITUDE * eff_sig) + noise(0.009)
        satisfaction_score = base_satisfaction_score * (1 - SUPPORTING_MAGNITUDE * eff_sig) + noise(0.04)
        open_enroll_comp   = base_open_enroll_comp   * (1 - SUPPORTING_MAGNITUDE * eff_sig) + noise(0.008)
        retention_rate     = base_retention_rate     * (1 - SUPPORTING_MAGNITUDE * eff_sig) + noise(0.005)
        # Category breakdown: voluntary drops at 1.8× the primary signal; dental at 0.8×; medical at 0.2×
        medical_rate       = base_medical_rate    * (1 - SIGNAL_MAGNITUDE * 0.20 * eff_sig) + noise(0.006)
        dental_rate        = base_dental_rate     * (1 - SIGNAL_MAGNITUDE * 0.80 * eff_sig) + noise(0.007)
        voluntary_rate     = base_voluntary_rate  * (1 - SIGNAL_MAGNITUDE * 1.80 * eff_sig) + noise(0.008)

        rows.append({
            "Date":                           d.strftime("%Y-%m-%d"),
            "Client ID":                      client["Client ID"],
            "Vertical":                       client["Vertical"],
            "Size Band":                      client["Size Band"],
            "Region":                         client["Region"],
            "State":                          client["State"],
            "Plan Cost Tier":                 client["Plan Cost Tier"],
            "Workforce Type":                 client["Workforce Type"],
            "Employees":                      int(client["Employees"]),
            "Benefits Enrollment Rate":       round(max(0.0, min(1.0, enrollment_rate)), 4),
            "Voluntary Benefits Opt-in Rate": round(max(0.0, min(1.0, voluntary_optin)), 4),
            "Medical Enrollment Rate":        round(max(0.0, min(1.0, medical_rate)), 4),
            "Dental Enrollment Rate":         round(max(0.0, min(1.0, dental_rate)), 4),
            "Voluntary Plan Enrollment Rate": round(max(0.0, min(1.0, voluntary_rate)), 4),
            "Benefits Utilization Rate":      round(max(0.0, min(1.0, utilization_rate)), 4),
            "Employee Satisfaction Score":    round(max(1.0, min(5.0, satisfaction_score)), 3),
            "Open Enrollment Completion Rate":round(max(0.0, min(1.0, open_enroll_comp)), 4),
            "Client Retention Rate":          round(max(0.0, min(1.0, retention_rate)), 4),
            "Eligible Employees Enrolled":    0,
            "Employees Offered Voluntary":    0,
        })

df = pd.DataFrame(rows)
df["Eligible Employees Enrolled"] = (df["Employees"] * df["Benefits Enrollment Rate"]).astype(int)
df["Employees Offered Voluntary"]  = (df["Employees"] * df["Voluntary Benefits Opt-in Rate"]).astype(int)

# Sanity check
print(f"  Rows generated: {len(df):,}")
print(f"  Benefits Enrollment Rate — min:{df['Benefits Enrollment Rate'].min():.2%}  mean:{df['Benefits Enrollment Rate'].mean():.2%}  max:{df['Benefits Enrollment Rate'].max():.2%}")
print(f"  Voluntary Opt-in Rate    — min:{df['Voluntary Benefits Opt-in Rate'].min():.2%}  mean:{df['Voluntary Benefits Opt-in Rate'].mean():.2%}  max:{df['Voluntary Benefits Opt-in Rate'].max():.2%}")

cp["data_ready"] = True
save_cp(cp)
print("  Data generation complete.\n")

# ── Auth ──────────────────────────────────────────────────────────────────────
config      = load_config()
sf_token, sf_instance = get_sf_token(config)
dc_token,  dc_domain  = get_dc_token(sf_token, sf_instance)
CONNECTOR_NAME = config["salesforce"]["ingestion_connector_name"]  # short name
CONNECTOR_ID   = config["salesforce"]["connector_sf_id"]

SF_HDR = sf_headers(sf_token)
DC_HDR = dc_headers(dc_token)

def refresh_tokens():
    global sf_token, sf_instance, dc_token, dc_domain, SF_HDR, DC_HDR
    sf_token, sf_instance = get_sf_token(config)
    dc_token, dc_domain   = get_dc_token(sf_token, sf_instance)
    SF_HDR = sf_headers(sf_token)
    DC_HDR = dc_headers(dc_token)

print(f"Auth OK — SF: {sf_instance}")
print(f"          DC: {dc_domain}\n")

# ── Schema definition ─────────────────────────────────────────────────────────
FACT_OBJECT  = "trinet_benefits_fact"
DIM_CLIENT   = "trinet_benefits_client_dim"

FACT_FIELDS = [
    {"name": "record_id",                     "type": "text"},   # surrogate PK: date_clientid
    {"name": "date",                          "type": "date"},
    {"name": "client_id",                     "type": "text"},
    # Denormalized dimensions — required because IngestAPI DLO relationships drop join criteria
    {"name": "vertical",                      "type": "text"},
    {"name": "size_band",                     "type": "text"},
    {"name": "region",                        "type": "text"},
    {"name": "state",                         "type": "text"},
    {"name": "plan_cost_tier",                "type": "text"},
    {"name": "workforce_type",                "type": "text"},
    # Metrics
    {"name": "benefits_enrollment_rate",      "type": "number"},
    {"name": "voluntary_benefits_optin_rate", "type": "number"},
    {"name": "medical_enrollment_rate",       "type": "number"},
    {"name": "dental_enrollment_rate",        "type": "number"},
    {"name": "voluntary_plan_enrollment_rate","type": "number"},
    {"name": "benefits_utilization_rate",     "type": "number"},
    {"name": "employee_satisfaction_score",   "type": "number"},
    {"name": "open_enrollment_completion_rate","type": "number"},
    {"name": "client_retention_rate",         "type": "number"},
    {"name": "eligible_employees_enrolled",   "type": "number"},
    {"name": "employees_offered_voluntary",   "type": "number"},
    {"name": "employees",                     "type": "number"},
]

DIM_FIELDS = [
    {"name": "client_id",       "type": "text"},
    {"name": "client_name",     "type": "text"},
    {"name": "vertical",        "type": "text"},
    {"name": "size_band",       "type": "text"},
    {"name": "region",          "type": "text"},
    {"name": "state",           "type": "text"},
    {"name": "plan_cost_tier",  "type": "text"},
    {"name": "workforce_type",  "type": "text"},
    {"name": "employees",       "type": "number"},
]

DC_TYPE_MAP = {"text": "Text", "number": "Number", "date": "Date"}

def make_schema(obj_name, fields):
    return {
        "name":       obj_name,
        "label":      obj_name,
        "schemaType": "IngestApi",
        "fields": [
            {"name": f["name"], "label": f["name"], "dataType": DC_TYPE_MAP[f["type"]]}
            for f in fields
        ],
    }

# ── Phase 1 — Register schema ─────────────────────────────────────────────────
if cp.get("schema_done"):
    print("Phase 1 — Schema already registered, skipping.\n")
else:
    print("Phase 1 — Registering schema on connector...")
    url = f"{sf_instance}/services/data/v62.0/ssot/connections/{CONNECTOR_ID}/schema"
    r = requests.get(url, headers=SF_HDR)
    existing = r.json() if r.status_code == 200 else {"schemas": []}
    existing_names = {o["name"] for o in existing.get("schemas", [])}

    # Always PUT our schemas to ensure they match the current FACT_FIELDS/DIM_FIELDS definitions
    our_schemas = {make_schema(FACT_OBJECT, FACT_FIELDS)["name"]: make_schema(FACT_OBJECT, FACT_FIELDS),
                   make_schema(DIM_CLIENT, DIM_FIELDS)["name"]:   make_schema(DIM_CLIENT, DIM_FIELDS)}
    other_schemas = [s for s in existing.get("schemas", []) if s["name"] not in our_schemas]
    merged = other_schemas + list(our_schemas.values())
    r2 = requests.put(url, headers=SF_HDR, json={"schemas": merged})
    assert r2.status_code in (200, 201), f"Schema PUT failed: {r2.status_code} {r2.text}"
    print(f"  Schema registered/updated: {list(our_schemas.keys())}")

    cp["schema_done"] = True
    save_cp(cp)
    print("  Phase 1 complete.\n")

# ── Phase 2 — Create data streams ─────────────────────────────────────────────
CONNECTOR_UUID = config["salesforce"]["connector_uuid_name"]

def create_or_get_stream(obj_name, label, pk_field):
    url    = f"{sf_instance}/services/data/v62.0/ssot/data-streams"
    sname  = obj_name
    payload = {
        "name":  sname,
        "label": label,
        "datasource": CONNECTOR_NAME[:10],
        "datastreamType": "INGESTAPI",
        "connectorInfo": {
            "connectorType": "IngestApi",
            "connectorDetails": {"name": CONNECTOR_UUID, "events": [obj_name]},
        },
        "dataLakeObjectInfo": {
            "label":     label,
            "category":  "Other",
            "dataspaceInfo": [{"name": "default"}],
            "dataLakeFieldInputRepresentations": [
                {"name": pk_field, "label": pk_field, "dataType": "Text", "isPrimaryKey": True}
            ],
            "eventDateTimeFieldName": "",
            "recordModifiedFieldName": "",
        },
        "mappings": [],
    }
    r = requests.post(url, headers=SF_HDR, json=payload)
    if r.status_code in (200, 201):
        name = r.json().get("name", sname)
        print(f"  Stream created: {name}")
        return name
    elif "already in use" in r.text.lower() or "already exists" in r.text.lower() or r.status_code == 409:
        r2 = requests.get(f"{url}?connectorId={CONNECTOR_ID}&limit=200", headers=SF_HDR)
        for ds in r2.json().get("dataStreams", []):
            if obj_name.lower() in ds.get("name", "").lower():
                print(f"  Stream already exists: {ds['name']}")
                return ds["name"]
        print(f"  Stream exists but not found, using object name: {sname}")
        return sname
    else:
        raise Exception(f"Stream creation failed: {r.status_code} {r.text}")

def wait_for_dlo(stream_name, timeout=300):
    print(f"  Waiting for DLO '{stream_name}' to become ACTIVE...")
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = requests.get(f"{sf_instance}/services/data/v62.0/ssot/data-streams/{stream_name}", headers=SF_HDR)
        body = r.json()
        dlo_info = body.get("dataLakeObjectInfo", {})
        status = dlo_info.get("status") or body.get("status", "UNKNOWN")
        print(f"    status: {status}")
        if status == "ACTIVE":
            return dlo_info.get("name", stream_name)
        if status in ("FAILED", "ERROR"):
            raise Exception(f"DLO failed: {body}")
        time.sleep(10)
    raise Exception(f"DLO '{stream_name}' did not reach ACTIVE within {timeout}s")

if cp.get("streams_done"):
    print("Phase 2 — Streams already created, skipping.\n")
    fact_stream  = cp["fact_stream"]
    dim_stream   = cp["dim_stream"]
    # Recover DLO names if checkpoint was written before this field existed
    if "fact_dlo" not in cp:
        r = requests.get(f"{sf_instance}/services/data/v62.0/ssot/data-streams/{fact_stream}", headers=SF_HDR)
        cp["fact_dlo"] = r.json().get("dataLakeObjectInfo", {}).get("name", fact_stream)
        r = requests.get(f"{sf_instance}/services/data/v62.0/ssot/data-streams/{dim_stream}", headers=SF_HDR)
        cp["dim_dlo"] = r.json().get("dataLakeObjectInfo", {}).get("name", dim_stream)
        save_cp(cp)
    fact_dlo = cp["fact_dlo"]
    dim_dlo  = cp["dim_dlo"]
else:
    print("Phase 2 — Creating data streams...")
    fact_stream = create_or_get_stream(FACT_OBJECT, "TriNet Benefits Fact", "record_id")
    dim_stream  = create_or_get_stream(DIM_CLIENT,  "TriNet Benefits Client Dim", "client_id")

    fact_dlo = wait_for_dlo(fact_stream)
    dim_dlo  = wait_for_dlo(dim_stream)
    print("  Both DLOs ACTIVE. Waiting 30s for schema propagation...")
    time.sleep(30)

    cp["fact_stream"]  = fact_stream
    cp["dim_stream"]   = dim_stream
    cp["fact_dlo"]     = fact_dlo
    cp["dim_dlo"]      = dim_dlo
    cp["streams_done"] = True
    save_cp(cp)
    print(f"  Fact DLO: {fact_dlo}")
    print(f"  Dim DLO:  {dim_dlo}")
    print("  Phase 2 complete.\n")

# ── Phase 3 — Bulk ingest (CSV) ───────────────────────────────────────────────
INGEST_BASE = f"https://{dc_domain}/api/v1/ingest/jobs"

def df_to_csv(df_in):
    return df_in.to_csv(index=False)

def bulk_ingest(df_in, schema_name, label, operation="upsert", max_retries=10):
    csv_data = df_to_csv(df_in)
    hdrs_json = {"Authorization": f"Bearer {dc_token}", "Content-Type": "application/json"}
    hdrs_csv  = {"Authorization": f"Bearer {dc_token}", "Content-Type": "text/csv"}

    job_id = None
    for attempt in range(1, max_retries + 1):
        r = requests.post(INGEST_BASE, headers=hdrs_json,
            json={"object": schema_name, "sourceName": CONNECTOR_NAME, "operation": operation})
        if r.ok:
            resp = r.json()
            job_id = resp.get("id") or resp.get("data", {}).get("id")
            print(f"  {label}: job created ({job_id})")
            break
        if r.status_code == 404:
            wait = 15 * attempt
            print(f"  {label}: schema not ready (attempt {attempt}/{max_retries}), waiting {wait}s...")
            time.sleep(wait)
        elif r.status_code == 409:
            # Find and reuse open job
            r2 = requests.get(INGEST_BASE, headers=hdrs_json)
            for j in r2.json().get("data", []):
                if j.get("object") == schema_name and j.get("state") in ("Open", "UploadComplete", "InProgress"):
                    job_id = j["id"]
                    print(f"  {label}: reusing existing job {job_id}")
                    break
            if job_id:
                break
            time.sleep(15 * attempt)
        else:
            raise Exception(f"{label}: job create failed {r.status_code} {r.text[:300]}")
    else:
        raise Exception(f"{label}: schema never became available after {max_retries} retries")

    # Upload CSV
    r = requests.put(f"{INGEST_BASE}/{job_id}/batches", headers=hdrs_csv,
                     data=csv_data.encode("utf-8"))
    assert r.ok, f"{label}: batch upload failed {r.status_code} {r.text[:200]}"
    print(f"  {label}: {len(df_in):,} rows uploaded")

    # Close
    r = requests.patch(f"{INGEST_BASE}/{job_id}", headers=hdrs_json,
                       json={"state": "UploadComplete"})
    assert r.ok, f"{label}: close failed {r.status_code}"
    return job_id

def poll_job(job_id, label, timeout=900):
    hdrs_json = {"Authorization": f"Bearer {dc_token}", "Content-Type": "application/json"}
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = requests.get(f"{INGEST_BASE}/{job_id}", headers=hdrs_json)
        body = r.json()
        state = body.get("state") or body.get("data", {}).get("state", "UNKNOWN")
        print(f"  {label}: {state}")
        if state == "JobComplete":
            return True
        if state in ("Failed", "Aborted"):
            raise Exception(f"{label}: ingest failed — {body}")
        time.sleep(20)
    raise Exception(f"{label}: timed out after {timeout}s")

if cp.get("ingest_done"):
    print("Phase 3 — Ingest already complete, skipping.\n")
else:
    print("Phase 3 — Bulk ingest...")
    refresh_tokens()

    # Build fact dataframe with API field names — dimensions denormalized for SDM filterability
    fact_df = df[[
        "Date", "Client ID",
        "Vertical", "Size Band", "Region", "State", "Plan Cost Tier", "Workforce Type",
        "Benefits Enrollment Rate", "Voluntary Benefits Opt-in Rate",
        "Medical Enrollment Rate", "Dental Enrollment Rate", "Voluntary Plan Enrollment Rate",
        "Benefits Utilization Rate", "Employee Satisfaction Score",
        "Open Enrollment Completion Rate", "Client Retention Rate",
        "Eligible Employees Enrolled", "Employees Offered Voluntary", "Employees",
    ]].copy()
    fact_df.columns = [
        "date", "client_id",
        "vertical", "size_band", "region", "state", "plan_cost_tier", "workforce_type",
        "benefits_enrollment_rate", "voluntary_benefits_optin_rate",
        "medical_enrollment_rate", "dental_enrollment_rate", "voluntary_plan_enrollment_rate",
        "benefits_utilization_rate", "employee_satisfaction_score",
        "open_enrollment_completion_rate", "client_retention_rate",
        "eligible_employees_enrolled", "employees_offered_voluntary", "employees",
    ]
    # Surrogate PK: date_clientid ensures upsert stores one row per client per day
    fact_df.insert(0, "record_id", fact_df["date"].astype(str) + "_" + fact_df["client_id"])

    dim_df = clients_df[["Client ID","Client Name","Vertical","Size Band","Region","State","Plan Cost Tier","Workforce Type","Employees"]].copy()
    dim_df.columns = ["client_id","client_name","vertical","size_band","region","state","plan_cost_tier","workforce_type","employees"]

    print(f"  Fact rows: {len(fact_df):,}  |  Dim rows: {len(dim_df):,}")

    fact_job = bulk_ingest(fact_df, FACT_OBJECT, "Fact", operation="upsert")
    dim_job  = bulk_ingest(dim_df,  DIM_CLIENT,  "Dim", operation="upsert")

    print("  Polling jobs to completion (this may take 5-10 minutes)...")
    poll_job(fact_job, "Fact")
    poll_job(dim_job,  "Dim")

    cp["ingest_done"] = True
    save_cp(cp)
    print("  Phase 3 complete.\n")

# ── Phase 4 — Workspace + SDM ─────────────────────────────────────────────────
WORKSPACE_LABEL = f"trinet_{USE_CASE}"
SDM_LABEL       = "TriNet Benefits Analytics"

METRIC_CONFIG = [
    {
        "label":         "Benefits Enrollment Rate",
        "field":         "benefits_enrollment_rate",
        "agg":           "Average",
        "is_rate":       True,   # stored as decimal; multiply CLC by 100
        "sentiment":     "SentimentTypeUpIsGood",
        "singular_noun": "benefits enrollment rate",
        "plural_noun":   "benefits enrollment rates",
        "description":   "Average % of eligible employees enrolled in core benefits across SMB clients",
    },
    {
        "label":         "Voluntary Benefits Opt-in Rate",
        "field":         "voluntary_benefits_optin_rate",
        "agg":           "Average",
        "is_rate":       True,
        "sentiment":     "SentimentTypeUpIsGood",
        "singular_noun": "voluntary benefits opt-in",
        "plural_noun":   "voluntary benefits opt-ins",
        "description":   "Average % of employees opting into voluntary/supplemental benefit plans",
    },
    {
        "label":         "Medical Enrollment Rate",
        "field":         "medical_enrollment_rate",
        "agg":           "Average",
        "is_rate":       True,
        "sentiment":     "SentimentTypeUpIsGood",
        "singular_noun": "medical enrollment rate",
        "plural_noun":   "medical enrollment rates",
        "description":   "% of eligible employees enrolled in medical/health coverage — stays relatively stable even when overall enrollment drops",
    },
    {
        "label":         "Dental Enrollment Rate",
        "field":         "dental_enrollment_rate",
        "agg":           "Average",
        "is_rate":       True,
        "sentiment":     "SentimentTypeUpIsGood",
        "singular_noun": "dental enrollment rate",
        "plural_noun":   "dental enrollment rates",
        "description":   "% of eligible employees enrolled in dental coverage",
    },
    {
        "label":         "Voluntary Plan Enrollment Rate",
        "field":         "voluntary_plan_enrollment_rate",
        "agg":           "Average",
        "is_rate":       True,
        "sentiment":     "SentimentTypeUpIsGood",
        "singular_noun": "voluntary plan enrollment rate",
        "plural_noun":   "voluntary plan enrollment rates",
        "description":   "% of employees enrolled in voluntary/supplemental plans — drops fastest when costs rise; leading indicator of overall enrollment decline",
    },
    {
        "label":         "Benefits Utilization Rate",
        "field":         "benefits_utilization_rate",
        "agg":           "Average",
        "is_rate":       True,
        "sentiment":     "SentimentTypeUpIsGood",
        "singular_noun": "benefits utilization rate",
        "plural_noun":   "benefits utilization rates",
        "description":   "% of enrolled employees actively using their benefits",
    },
    {
        "label":         "Employee Satisfaction Score",
        "field":         "employee_satisfaction_score",
        "agg":           "Average",
        "is_rate":       False,  # out of 5.0, not a percentage
        "sentiment":     "SentimentTypeUpIsGood",
        "singular_noun": "employee satisfaction score",
        "plural_noun":   "employee satisfaction scores",
        "description":   "Average employee satisfaction with benefits offering (out of 5.0)",
    },
    {
        "label":         "Open Enrollment Completion Rate",
        "field":         "open_enrollment_completion_rate",
        "agg":           "Average",
        "is_rate":       True,
        "sentiment":     "SentimentTypeUpIsGood",
        "singular_noun": "open enrollment completion",
        "plural_noun":   "open enrollment completions",
        "description":   "% of employees who completed the open enrollment process",
    },
    {
        "label":         "Client Retention Rate",
        "field":         "client_retention_rate",
        "agg":           "Average",
        "is_rate":       True,
        "sentiment":     "SentimentTypeUpIsGood",
        "singular_noun": "client retention rate",
        "plural_noun":   "client retention rates",
        "description":   "% of SMB clients retained month over month",
    },
]

def delete_assets(apis, base_url, hdrs, label="asset"):
    for api in list(apis):
        r = requests.delete(f"{base_url}/{api}", headers=hdrs)
        print(f"  Deleted {label} {api}: {r.status_code}")

if cp.get("sdm_done"):
    print("Phase 4 — SDM already built, skipping.\n")
    ws_api  = cp["ws_api"]
    sdm_api = cp["sdm_api"]
    do_api  = cp["do_api"]
else:
    print("Phase 4 — Building workspace + SDM...")
    refresh_tokens()

    # Cleanup previous workspace/SDM attempts
    if cp.get("all_ws_apis"):
        print("  Cleaning up previous workspaces...")
        for w in cp["all_ws_apis"]:
            r = requests.delete(f"{sf_instance}/services/data/v65.0/tableau/workspaces/{w}", headers=SF_HDR)
            print(f"    Deleted workspace {w}: {r.status_code}")
        cp["all_ws_apis"] = []
        cp.pop("ws_api", None); cp.pop("sdm_api", None); cp.pop("do_api", None)
        save_cp(cp)

    if cp.get("all_sdm_apis"):
        print("  Cleaning up previous SDMs...")
        for s in cp["all_sdm_apis"]:
            r = requests.delete(f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{s}", headers=SF_HDR)
            print(f"    Deleted SDM {s}: {r.status_code}")
        cp["all_sdm_apis"] = []
        save_cp(cp)

    # 4a — Create workspace
    r = requests.post(f"{sf_instance}/services/data/v65.0/tableau/workspaces",
        headers=SF_HDR, json={"label": WORKSPACE_LABEL, "description": "TriNet Benefits demo"})
    assert r.status_code in (200, 201), f"Workspace create failed: {r.status_code} {r.text}"
    ws_api = r.json().get("apiName") or r.json().get("name")
    cp["ws_api"] = ws_api
    cp["all_ws_apis"].append(ws_api)
    save_cp(cp)
    print(f"  Workspace: {ws_api}")

    # 4b — Create SDM
    r = requests.post(f"{sf_instance}/services/data/v65.0/ssot/semantic/models",
        headers=SF_HDR,
        json={"label": SDM_LABEL, "dataspace": "default", "agentEnabled": True, "workspaceName": ws_api})
    assert r.status_code in (200, 201), f"SDM create failed: {r.status_code} {r.text}"
    sdm_api = r.json().get("apiName") or r.json().get("name")
    cp["sdm_api"] = sdm_api
    cp["all_sdm_apis"].append(sdm_api)
    save_cp(cp)
    print(f"  SDM: {sdm_api}")

    # 4c — Add fact DLO (denormalized — includes all client dim fields to avoid join issues)
    r = requests.post(
        f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects",
        headers=SF_HDR,
        json={"label": "Benefits Activity", "dataObjectType": "dlo",
              "dataLakeObjectName": fact_dlo, "dataObjectName": fact_dlo})
    assert r.status_code in (200, 201), f"DO create failed: {r.status_code} {r.text}"
    do_api = r.json().get("apiName") or r.json().get("name")
    cp["do_api"] = do_api
    save_cp(cp)
    print(f"  Data Object: {do_api}")

    # 4d — Get auto-detected measurements + dimensions (build field map)
    time.sleep(5)
    r = requests.get(
        f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects/{do_api}",
        headers=SF_HDR)
    do_body = r.json()
    # DC auto-detects fields with __c suffix; build lookup for both bare and __c names
    measurements = {}
    for m in do_body.get("semanticMeasurements", []):
        dofn = m["dataObjectFieldName"]
        measurements[dofn] = m["apiName"]
        measurements[dofn.replace("__c", "")] = m["apiName"]

    # Build dimension field map: bare name -> apiName
    dim_field_map = {}
    for d in do_body.get("semanticDimensions", []):
        dof = d.get("dataObjectFieldName", "")
        base = dof.replace("__c", "") if dof else d["apiName"]
        dim_field_map[base] = d["apiName"]

    print(f"  Auto-detected measurements: {[m['dataObjectFieldName'] for m in do_body.get('semanticMeasurements', [])]}")
    print(f"  Dimensions: {dim_field_map}")

    # 4e — Update aggregation for each metric field (requires label in PUT body)
    for mc in METRIC_CONFIG:
        field = mc["field"]
        if field not in measurements:
            print(f"  WARNING: field '{field}' not in auto-detected measurements, skipping PUT")
            continue
        m_api = measurements[field]
        r = requests.put(
            f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects/{do_api}/measurements/{m_api}",
            headers=SF_HDR,
            json={"apiName": m_api, "label": mc["label"], "dataObjectFieldName": f"{field}__c", "aggregationType": mc["agg"]})
        print(f"  Set agg for {field}: {r.status_code}")

    # 4f — Create calculated measurements (clc) at SDM level
    clc_map = {}  # field -> clc_api
    for mc in METRIC_CONFIG:
        field = mc["field"]
        if field not in measurements:
            continue
        m_api = measurements[field]
        clc_api_name = f"{field}_clc"
        clc_label    = f"{mc['label']} Calc"
        if mc.get("is_rate"):
            clc_expr = f"AVG([{do_api}].[{m_api}]) * 100"
        else:
            clc_expr = f"AVG([{do_api}].[{m_api}])"
        print(f"  CLC expr for {field}: {clc_expr}")
        r = requests.post(
            f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/calculated-measurements",
            headers=SF_HDR,
            json={
                "apiName": clc_api_name, "label": clc_label,
                "aggregationType": "UserAgg", "dataType": "Number", "decimalPlace": 4,
                "directionality": "Up", "displayCategory": "Continuous",
                "expression": clc_expr, "filters": [],
                "isOverrideBase": False, "isVisible": True,
                "level": "AggregateFunction", "overriddenProperties": [],
                "semanticDataType": "None",
            })
        if r.status_code in (200, 201):
            clc_api = r.json().get("apiName") or r.json().get("name")
            clc_map[field] = clc_api
            print(f"  CLC created for {field}: {clc_api}")
        else:
            print(f"  CLC failed for {field} ({r.status_code}): {r.text[:200]}")

    cp["clc_map"]       = clc_map
    cp["dim_field_map"] = dim_field_map
    cp["sdm_done"]      = True
    save_cp(cp)
    print("  Phase 4 complete.\n")

ws_api        = cp["ws_api"]
sdm_api       = cp["sdm_api"]
do_api        = cp["do_api"]
clc_map       = cp.get("clc_map", {})
dim_field_map = cp.get("dim_field_map", {})

# Rebuild measurements lookup if not in memory (sdm phase was skipped)
if not cp.get("sdm_done") or "measurements" not in dir():
    _r = requests.get(
        f"{sf_instance}/services/data/v65.0/ssot/semantic/models/{sdm_api}/data-objects/{do_api}",
        headers=SF_HDR)
    _do = _r.json()
    measurements = {}
    for m in _do.get("semanticMeasurements", []):
        dofn = m["dataObjectFieldName"]
        measurements[dofn] = m["apiName"]
        measurements[dofn.replace("__c", "")] = m["apiName"]
    if not dim_field_map:
        for d in _do.get("semanticDimensions", []):
            dof = d.get("dataObjectFieldName", "")
            base = dof.replace("__c", "") if dof else d["apiName"]
            dim_field_map[base] = d["apiName"]
        cp["dim_field_map"] = dim_field_map
        save_cp(cp)

# ── Phase 5 — Semantic metrics ────────────────────────────────────────────────
if cp.get("metrics_done"):
    print("Phase 5 — Metrics already created, skipping.\n")
    mtc_map = cp["mtc_map"]
else:
    print("Phase 5 — Creating semantic metrics...")
    refresh_tokens()
    mtc_map = {}

    for mc in METRIC_CONFIG:
        field = mc["field"]
        if field not in clc_map:
            print(f"  Skipping metric for {field} (no CLC available)")
            continue
        clc_api = clc_map[field]
        date_api = dim_field_map.get("date", "date1")
        dim_apis = [
            dim_field_map.get("vertical"),
            dim_field_map.get("size_band"),
            dim_field_map.get("region"),
            dim_field_map.get("state"),
            dim_field_map.get("plan_cost_tier"),
            dim_field_map.get("workforce_type"),
        ]
        dim_refs = [{"tableFieldReference": {"fieldApiName": a, "tableApiName": do_api}}
                    for a in dim_apis if a]
        payload = {
            "label":       mc["label"],
            "dataspace":   "default",
            "description": mc["description"],
            "aggregationType": "UserAgg",
            "measurementReference": {"calculatedFieldApiName": clc_api},
            "timeDimensionReference": {"tableFieldReference": {
                "fieldApiName": date_api, "tableApiName": do_api}},
            "timeGrains": ["Day", "Week", "Month", "Quarter", "Year"],
            "filters": [], "isCumulative": False, "isGoalEditingBlocked": False,
            "additionalDimensions": dim_refs,
            "insightsSettings": {
                "singularNoun": mc["singular_noun"],
                "pluralNoun":   mc["plural_noun"],
                "sentiment":    mc["sentiment"],
                "insightTypes": [
                    {"enabled": True,  "type": "TrendChangeAlert"},
                    {"enabled": True,  "type": "CurrentTrend"},
                    {"enabled": True,  "type": "TopContributors"},
                    {"enabled": True,  "type": "BottomContributors"},
                    {"enabled": False, "type": "ComparisonToExpectedRangeAlert"},
                ],
                "insightsDimensionsReferences": dim_refs,
            },
        }
        r = requests.post(
            f"{sf_instance}/services/data/v66.0/ssot/semantic/models/{sdm_api}/metrics?minorVersion=12",
            headers=SF_HDR, json=payload)
        if r.status_code in (200, 201):
            mtc_api = r.json().get("apiName") or r.json().get("name")
            mtc_map[field] = mtc_api
            print(f"  Metric created: {mtc_api}")
        else:
            print(f"  Metric failed for {field} ({r.status_code}): {r.text[:200]}")

    cp["mtc_map"]     = mtc_map
    cp["metrics_done"] = True
    save_cp(cp)
    print("  Phase 5 complete.\n")

mtc_map = cp.get("mtc_map", {})

# ── Phase 6 — Visualizations + Dashboard ─────────────────────────────────────
VIZ_API_BASE  = f"{sf_instance}/services/data/v66.0"
VIZ_PARAMS    = {"minorVersion": "12"}

FONTS = {
    "actionableHeaders": {"color": "#0250D9", "size": 13},
    "axisTickLabels":    {"color": "#2E2E2E", "size": 13},
    "fieldLabels":       {"color": "#2E2E2E", "size": 13},
    "headers":           {"color": "#2E2E2E", "size": 13},
    "legendLabels":      {"color": "#2E2E2E", "size": 13},
    "markLabels":        {"color": "#2E2E2E", "size": 13},
    "marks":             {"color": "#2E2E2E", "size": 13},
}
LINES = {
    "axisLine":              {"color": "#C9C9C9"},
    "fieldLabelDividerLine": {"color": "#C9C9C9"},
    "separatorLine":         {"color": "#C9C9C9"},
    "zeroLine":              {"color": "#C9C9C9"},
}

def _marks_headers_style():
    return {
        "color": {"color": ""}, "isAutomaticSize": True,
        "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
        "range": {"reverse": False},
        "size": {"isAutomatic": True, "type": "Pixel", "value": 13},
    }

def make_viz(name, label, measure_field, mark_type, suffix="%", decimal_places=1):
    """measure_field is the bare field name; uses apiNames from dim_field_map/measurements."""
    date_fapi = dim_field_map.get("date", "date1")
    meas_fapi = measurements.get(measure_field, f"{measure_field}__c")
    return {
        "name": name, "label": label,
        "dataSource": {"name": sdm_api, "label": label, "type": "SemanticModel"},
        "workspace":  {"name": ws_api, "label": ws_api},
        "interactions": [],
        "fields": {
            "F1": {"type": "Field", "displayCategory": "Discrete", "role": "Dimension",
                   "objectName": do_api, "fieldName": date_fapi, "function": "DatePartMonth"},
            "F2": {"type": "Field", "displayCategory": "Continuous", "role": "Measure",
                   "objectName": do_api, "fieldName": meas_fapi, "function": "Avg"},
        },
        "visualSpecification": {
            "layout": "Vizql", "columns": ["F1"], "rows": ["F2"],
            "forecasts": {}, "measureValues": [], "referenceLines": {},
            "legends": {},
            "marks": {
                "fields": {}, "headers": {"encodings": [], "isAutomatic": True,
                                          "stack": {"isAutomatic": True, "isStacked": False}, "type": "Text"},
                "panes": {"encodings": [], "isAutomatic": False, "type": mark_type,
                          "stack": {"isAutomatic": True, "isStacked": False}},
            },
            "style": {
                "axis": {"fields": {"F2": {
                    "isVisible": True, "isZeroLineVisible": True,
                    "range": {"includeZero": False, "type": "Auto"},
                    "scale": {"format": {"numberFormatInfo": {"decimalPlaces": decimal_places, "displayUnits": "Auto",
                        "includeThousandSeparator": False, "negativeValuesFormat": "Auto",
                        "prefix": "", "suffix": suffix, "type": "Number"}}},
                    "ticks": {"majorTicks": {"type": "Auto"}, "minorTicks": {"type": "Auto"}},
                }}},
                "encodings": {"fields": {"F2": {"defaults": {"format": {"numberFormatInfo": {
                    "decimalPlaces": decimal_places, "displayUnits": "Auto", "includeThousandSeparator": False,
                    "negativeValuesFormat": "Auto", "prefix": "", "suffix": suffix, "type": "Number",
                }}}}}},
                "fieldLabels": {"columns": {"showDividerLine": False, "showLabels": True},
                                "rows": {"showDividerLine": False, "showLabels": True}},
                "fit": "Entire", "fonts": FONTS,
                "headers": {
                    "columns": {"mergeRepeatedCells": True, "showIndex": False},
                    "rows":    {"mergeRepeatedCells": True, "showIndex": False},
                    "fields":  {"F1": {"hiddenValues": [], "isVisible": True, "showMissingValues": False}},
                },
                "lines": LINES,
                "marks": {
                    "fields": {}, "headers": _marks_headers_style(),
                    "panes": {"color": {"color": ""}, "isAutomaticSize": False,
                              "label": {"canOverlapLabels": False, "marksToLabel": {"type": "All"}, "showMarkLabels": False},
                              "range": {"reverse": False},
                              "size": {"isAutomatic": False, "type": "Pixel", "value": 3}},
                },
                "referenceLines": {},
                "shading": {"backgroundColor": "#FFFFFF", "banding": {}},
                "showDataPlaceholder": False, "title": {"isVisible": True},
            },
        },
        "view": {
            "label": "default", "name": f"{name}_default",
            "viewSpecification": {"sortOrders": {"columns": [], "fields": {}, "rows": []}},
        },
    }

VIZ_CONFIGS = [
    # (name, label, field, mark_type, suffix, decimal_places)
    # Row 1 — the primary story: overall enrollment trending down + voluntary (cost-sensitive) dropping hardest
    ("trinet_enrollment_trend",   "Overall Enrollment Rate Over Time",        "benefits_enrollment_rate",         "Line", "%", 1),
    ("trinet_voluntary_trend",    "Voluntary Opt-in Rate Over Time",          "voluntary_benefits_optin_rate",    "Line", "%", 1),
    # Row 2 — category breakdown: which benefit types are driving the drop?
    ("trinet_voluntary_plan_trend","Voluntary Plan Enrollment Over Time",     "voluntary_plan_enrollment_rate",   "Line", "%", 1),
    ("trinet_medical_trend",      "Medical vs Dental Enrollment Over Time",   "medical_enrollment_rate",          "Line", "%", 1),
    # Row 3 — root cause signals: satisfaction declining, utilization falling
    ("trinet_utilization_bar",    "Benefits Utilization Rate Over Time",      "benefits_utilization_rate",        "Line", "%", 1),
    ("trinet_satisfaction_trend", "Employee Satisfaction Score Trend",        "employee_satisfaction_score",      "Line", "",  2),
]

if cp.get("vizzes_done"):
    print("Phase 6 — Vizzes already created, skipping.\n")
    viz_apis = cp["viz_apis"]
else:
    print("Phase 6 — Creating visualizations...")
    refresh_tokens()

    # Cleanup previous vizzes
    if cp.get("all_viz_apis"):
        print("  Cleaning up previous vizzes...")
        for v in cp["all_viz_apis"]:
            r = requests.delete(
                f"{sf_instance}/services/data/v66.0/tableau/visualizations/{v}?minorVersion=12",
                headers=SF_HDR)
            print(f"    Deleted viz {v}: {r.status_code}")
        cp["all_viz_apis"] = []
        cp.pop("viz_apis", None)
        save_cp(cp)

    viz_apis = {}
    for (vname, vlabel, vfield, vmark, vsuffix, vdecimals) in VIZ_CONFIGS:
        payload = make_viz(vname, vlabel, vfield, vmark, suffix=vsuffix, decimal_places=vdecimals)
        r = requests.post(f"{VIZ_API_BASE}/tableau/visualizations",
                          headers=SF_HDR, params=VIZ_PARAMS, json=payload)
        if r.status_code in (200, 201):
            vapi = r.json().get("name") or r.json().get("apiName") or vname
            viz_apis[vname] = vapi
            cp["all_viz_apis"].append(vapi)
            save_cp(cp)
            print(f"  Viz created: {vapi}")
        else:
            print(f"  Viz FAILED {vname} ({r.status_code}): {r.text[:300]}")

    cp["viz_apis"]    = viz_apis
    cp["vizzes_done"] = True
    save_cp(cp)
    print("  Phase 6 complete.\n")

viz_apis = cp.get("viz_apis", {})

# ── Phase 7 — Dashboard ───────────────────────────────────────────────────────
if cp.get("dashboard_done"):
    print("Phase 7 — Dashboard already created, skipping.\n")
    dash_api = cp["dash_api"]
else:
    print("Phase 7 — Creating dashboard...")
    refresh_tokens()

    # Cleanup previous dashboards
    if cp.get("all_dash_apis"):
        for d_api in cp["all_dash_apis"]:
            r = requests.delete(f"{VIZ_API_BASE}/tableau/dashboards/{d_api}",
                                headers=SF_HDR, params=VIZ_PARAMS)
            print(f"    Deleted dashboard {d_api}: {r.status_code}")
        cp["all_dash_apis"] = []
        cp.pop("dash_api", None)
        save_cp(cp)

    COLS = 72
    VIZ_W = 35
    VIZ_H = 28

    # top-level widgets list (container + viz pairs) — matches working demo pattern
    top_widgets = []
    page_widgets = []

    # Row 0: metric tiles — 3 primary KPIs across
    metric_fields = ["benefits_enrollment_rate", "voluntary_benefits_optin_rate", "voluntary_plan_enrollment_rate"]
    metric_widget_w = COLS // 3
    for i, field in enumerate(metric_fields):
        mtc_api_val = mtc_map.get(field)
        if not mtc_api_val:
            continue
        wname = f"metric_{i+1}"
        page_widgets.append({
            "name": wname, "column": i * metric_widget_w, "row": 0,
            "colspan": metric_widget_w, "rowspan": 15,
        })

    # Row 15+: viz tiles (2 per row, 3 rows = 6 vizzes)
    viz_list = list(viz_apis.values())
    layout_row = 15
    for vi, vapi in enumerate(viz_list):
        col_idx   = vi % 2
        col_start = col_idx * (COLS // 2)
        if vi % 2 == 0 and vi > 0:
            layout_row += VIZ_H
        cname = f"container_{vi+1}"
        vname = f"visualization_{vi+1}"
        page_widgets.append({"name": cname, "column": col_start, "row": layout_row, "colspan": VIZ_W, "rowspan": VIZ_H})
        page_widgets.append({"name": vname, "column": col_start+1, "row": layout_row+1, "colspan": VIZ_W-2, "rowspan": VIZ_H-2})

    # Build widgets dict — every name referenced in page_widgets must have an entry here
    widgets_dict = {}
    for i, field in enumerate(metric_fields):
        mtc_api_val = mtc_map.get(field)
        if not mtc_api_val:
            continue
        k = f"metric_{i+1}"
        widgets_dict[k] = {
            "actions": [], "name": k, "type": "metric",
            "source": {"name": mtc_api_val},
            "parameters": {
                "metricOption": {
                    "sdmApiName": sdm_api,
                    "layout": {"componentVisibility": {
                        "title": True, "value": True, "comparison": True,
                        "chart": True, "insights": True, "details": True,
                    }},
                },
                "receiveFilterSource": {"filterMode": "all", "widgetIds": []},
                "widgetStyle": {"borderColor": "#C9C9C9", "borderEdges": ["all"], "borderRadius": 20},
            },
        }
    for vi, vapi in enumerate(viz_list):
        k = f"visualization_{vi+1}"
        ck = f"container_{vi+1}"
        widgets_dict[k] = {
            "actions": [], "name": k, "type": "visualization",
            "source": {"name": vapi},
            "parameters": {
                "receiveFilterSource": {"filterMode": "all", "widgetIds": []},
                "widgetStyle": {"borderColor": "#C9C9C9", "borderEdges": [], "borderRadius": 16},
            },
        }
        widgets_dict[ck] = {
            "actions": [], "name": ck, "type": "container",
            "parameters": {"widgetStyle": {"borderColor": "#c9c9c9", "borderEdges": ["all"], "borderRadius": 16}},
        }

    dash_payload = {
        "name":  "trinet_benefits_dashboard",
        "label": "TriNet Benefits Enrollment Dashboard",
        "workspaceIdOrApiName": ws_api,
        "widgets": widgets_dict,
        "layouts": [{
            "name": "default", "columnCount": COLS, "rowHeight": 10, "maxWidth": 1200,
            "style": {"backgroundColor": "#F3F3F3", "cellSpacingX": 8, "cellSpacingY": 8, "gutterColor": "#F3F3F3"},
            "pages": [{"name": str(uuid.uuid4()), "label": "Overview", "widgets": page_widgets}],
        }],
    }

    r = requests.post(f"{VIZ_API_BASE}/tableau/dashboards",
                      headers=SF_HDR, params=VIZ_PARAMS, json=dash_payload)
    if r.status_code in (200, 201):
        dash_api = r.json().get("name") or r.json().get("apiName") or "trinet_benefits_dashboard"
        cp["dash_api"] = dash_api
        cp["all_dash_apis"].append(dash_api)
        cp["dashboard_done"] = True
        save_cp(cp)
        print(f"  Dashboard created: {dash_api}")
    else:
        print(f"  Dashboard FAILED ({r.status_code}): {r.text[:400]}")
        dash_api = "FAILED"

    print("  Phase 7 complete.\n")

dash_api = cp.get("dash_api", "UNKNOWN")

# ── Phase 8 — Business preferences + docs ────────────────────────────────────
BUSINESS_PREFS = """
# TriNet Benefits Enrollment Analytics — Business Preferences

# Context: This SDM tracks daily benefits enrollment activity across TriNet's SMB client base.
# Each row represents one client's enrollment metrics on a given day.
# Clients are small-to-mid-market employers (3-500 employees) across 5 US regions.

# Leading indicators (early warning): Benefits Enrollment Rate, Open Enrollment Completion Rate
# Lagging indicators (outcome): Client Retention Rate, Employee Satisfaction Score

# Most diagnostic dimensions for root-cause analysis: Vertical, Size Band, Region
# When enrollment drops, first filter by Vertical (Tech and Life Sciences show fastest volatility),
# then by Size Band (Micro clients are highest churn risk when enrollment drops below 55%).

# Terminology:
# - "Benefits Enrollment Rate" = % of all eligible employees actively enrolled in at least one core benefit plan
# - "Voluntary Benefits Opt-in Rate" = % choosing supplemental/voluntary plans beyond core medical
# - "Open Enrollment Completion Rate" = % of employees who completed the annual enrollment workflow end-to-end
# - "SMB client" = employer with 3-500 employees on the TriNet platform

# Default time comparison: last 3 months vs prior 3 months (highlights the recent step-change decline)
# For quarterly business reviews, use last 6 months vs prior 6 months.

# Metric hierarchy: Benefits Enrollment Rate is the primary KPI.
# Voluntary Benefits Opt-in Rate is the secondary KPI.
# All other metrics are supporting context — do not surface them above the primary two in executive summaries.

# Alert threshold: flag any client vertical or region where Benefits Enrollment Rate drops below 0.60 (60%).
# Critical threshold: below 0.50 indicates serious client health risk and potential churn.
""".strip()

cp["business_preferences"] = BUSINESS_PREFS
save_cp(cp)

# Write guide
guide_path = os.path.join(SCRIPT_DIR, f"{SLUG}_{USE_CASE}_guide.md")
with open(guide_path, "w") as f:
    f.write(f"""# TriNet Benefits Enrollment Demo Guide

## Overview
This demo tells the story of **benefits enrollment rates dropping among SMB clients** — a signal
that directly impacts client retention and TriNet's revenue. The primary audience is a **VP of Benefits**.

## Story arc
1. **Open with the problem** — Benefits Enrollment Rate sparkline shows a clear step-down ~3 months ago
2. **Confirm with voluntary opt-in** — Voluntary Benefits Opt-in Rate shows the same pattern
3. **Dig into why** — filter by Vertical → Technology and Life Sciences clients are driving the decline
4. **Size matters** — filter by Size Band → Micro clients (3-25 employees) are highest risk
5. **The business impact** — Client Retention Rate is beginning to drift as a lagging consequence

## Key metrics
| Metric | Type | Healthy range | Current story |
|--------|------|--------------|---------------|
| Benefits Enrollment Rate | Primary | 68–82% | Dropped ~25% from baseline |
| Voluntary Benefits Opt-in Rate | Primary | 48–64% | Dropped ~25% from baseline |
| Benefits Utilization Rate | Supporting | 55–72% | Soft ~12% decline |
| Employee Satisfaction Score | Supporting | 4.1–4.5 | Soft ~12% decline |
| Open Enrollment Completion Rate | Supporting | 72–88% | Soft ~12% decline |
| Client Retention Rate | Supporting | 88–96% | Early drift visible |

## Demo click path (Tableau Next)
1. Open **TriNet Benefits Enrollment Dashboard**
2. Point to the Benefits Enrollment Rate metric tile — "something changed about 3 months ago"
3. Click through to the trend viz — confirm the step change
4. Filter by **Vertical = Technology** — the decline is concentrated here
5. Filter by **Size Band = Micro (3-25)** — highest severity
6. Switch to Voluntary Opt-in Rate — same pattern confirms it's systemic
7. Show Client Retention Rate beginning to move — "this is the business consequence"

## Concierge prompts
- "Which client segment has the biggest drop in benefits enrollment?"
- "What's driving the decline in voluntary opt-in rates over the last 3 months?"
- "Show me clients at risk of churning based on their enrollment trends"
- "Compare benefits utilization between Technology and Professional Services clients"

## Assets created
- Workspace: `{ws_api}`
- SDM: `{sdm_api}`
- Data Object: `{do_api}`
- Dashboard: `{dash_api}`

## Post-build checklist
- [ ] Enable Analytics Agent Readiness: Data 360 → Semantic Model → Settings → Analytics Agent Readiness → ON
- [ ] Paste Business Preferences into the SDM (see walkthrough .docx)
- [ ] Verify dashboard loads in your Tableau Next workspace
""")

print(f"  Guide written: {guide_path}")

# Write walkthrough docx
try:
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    doc = Document()
    doc.add_heading("TriNet Benefits Enrollment — Demo Walkthrough", 0)
    doc.add_paragraph(f"Generated: {TODAY.strftime('%B %d, %Y')}")

    doc.add_heading("Demo Story", 1)
    doc.add_paragraph(
        "Benefits enrollment rates among TriNet's SMB clients dropped sharply approximately "
        "3 months ago. The step-change decline is most visible in Technology vertical clients "
        "and in Micro-sized accounts (3-25 employees). This early signal, if left unaddressed, "
        "will surface as client churn within the next quarter."
    )

    doc.add_heading("Concierge Click Path", 1)
    steps = [
        "Open the TriNet Benefits Enrollment Dashboard in your Tableau Next workspace.",
        "Point to the Benefits Enrollment Rate metric tile — highlight the step-change ~3 months ago.",
        "Click into the Benefits Enrollment Rate Over Time visualization.",
        "Apply filter: Vertical = Technology. The decline is concentrated here.",
        "Apply filter: Size Band = Micro (3-25). This is the highest-risk segment.",
        "Switch to Voluntary Benefits Opt-in Rate — same pattern confirms systemic issue.",
        "Navigate to Client Retention Rate — early drift is beginning to show.",
        "Ask Concierge: 'Which client segment has the biggest drop in benefits enrollment?'",
        "Ask Concierge: 'What's driving the decline in voluntary opt-in rates over the last 3 months?'",
    ]
    for i, step in enumerate(steps, 1):
        doc.add_paragraph(f"{i}. {step}")

    doc.add_heading("Metric Reference", 1)
    table = doc.add_table(rows=1, cols=3)
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    hdr[0].text = "Metric"; hdr[1].text = "Signal"; hdr[2].text = "Healthy Range"
    for mc in METRIC_CONFIG:
        row = table.add_row().cells
        row[0].text = mc["label"]
        row[1].text = "Primary — 25% step drop" if mc["field"] in ("benefits_enrollment_rate","voluntary_benefits_optin_rate") else "Supporting — 12% drift"
        row[2].text = mc["description"]

    doc.add_heading("Business Preferences (SDM)", 1)
    doc.add_paragraph(
        "Paste the text below into: Data 360 → Semantic Model → "
        f"[{sdm_api}] → AI Optimization → Manage Business Preferences"
    )
    doc.add_paragraph()
    bp_para = doc.add_paragraph(BUSINESS_PREFS)
    bp_para.runs[0].font.name = "Courier New"
    bp_para.runs[0].font.size = Pt(9)

    docx_path = os.path.join(SCRIPT_DIR, f"{SLUG}_{USE_CASE}_concierge_walkthrough.docx")
    doc.save(docx_path)
    print(f"  Walkthrough written: {docx_path}")
except ImportError:
    docx_path = "(python-docx not installed — skipped)"
    print("  python-docx not installed, skipping .docx generation")

# ── Final summary ─────────────────────────────────────────────────────────────
SF_DOMAIN = sf_instance.replace("https://", "")
print(f"""
╔══════════════════════════════════════════════════════════════╗
  BUILD COMPLETE — TriNet Benefits Enrollment
╠══════════════════════════════════════════════════════════════╣

  Workspace : {ws_api}
  SDM       : {sdm_api}
  Dashboard : {dash_api}

  Tableau Next URL:
  {sf_instance}/analytics/wave/dashboard/{dash_api}

  Guide     : {guide_path}
  Walkthrough: {docx_path}

  Metrics created:
{chr(10).join(f"    • {mc['label']} → {mtc_map.get(mc['field'], 'MISSING')}" for mc in METRIC_CONFIG)}

╠══════════════════════════════════════════════════════════════╣
  BUSINESS PREFERENCES — paste into SDM AI Optimization:
  Data 360 → Semantic Model → [{sdm_api}]
    → AI Optimization → Manage Business Preferences
╠══════════════════════════════════════════════════════════════╣

{BUSINESS_PREFS}

╠══════════════════════════════════════════════════════════════╣
  POST-BUILD CHECKLIST:
  ☐  Enable Analytics Agent Readiness in SDM Settings
  ☐  Paste Business Preferences into SDM (see .docx)
  ☐  Verify dashboard loads in Tableau Next
╚══════════════════════════════════════════════════════════════╝
""")
